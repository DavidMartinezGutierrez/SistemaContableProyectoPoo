# GestionVeterinariaMVC

CRUD en Java Swing con patrón MVC, JPA (EclipseLink) y SQLite, para NetBeans (Java with Ant).
Sigue la guía de clase "CRUD con SQLite - SWING" (UTS, POO) y la página CRUDSQLiteSwing.

## Reparto de módulos (uno por estudiante)

| Módulo | Estudiante | Modelo | Persistencia | Vista | Controlador |
|---|---|---|---|---|---|
| 1. Clientes | ______ | `modelo/Cliente` | `persistencia/ClienteJpaController` | `vista/FrmCliente` | `controlador/ControladorCliente` |
| 2. Mascotas | ______ | `modelo/Mascota` | `persistencia/MascotaJpaController` | `vista/FrmMascota` | `controlador/ControladorMascota` |
| 3. Veterinarios | ______ | `modelo/Veterinario` | `persistencia/VeterinarioJpaController` | `vista/FrmVeterinario` | `controlador/ControladorVeterinario` |
| 4. Medicamentos | ______ | `modelo/Medicamento` | `persistencia/MedicamentoJpaController` | `vista/FrmMedicamento` | `controlador/ControladorMedicamento` |

Partes compartidas: `principal/Main`, `vista/FrmMenuPrincipal`, `controlador/ControladorMenu`,
`META-INF/persistence.xml`, `persistencia/SQLitePlatform` y `persistencia/exceptions`.

## Abrir y ejecutar en NetBeans

1. File > Open Project... y seleccionar la carpeta `GestionVeterinariaMVC`.
2. Si NetBeans marca librerías faltantes (Resolve Problems), verificar en Properties > Libraries:
   `lib/sqlite-jdbc-3.45.1.0.jar`, `lib/slf4j-api-1.7.36.jar` y la librería **EclipseLink (JPA 2.1)**.
3. Run (F6). La clase principal es `principal.Main`.

La base `bd_veterinaria.db` va en la raíz del proyecto (ruta relativa `jdbc:sqlite:bd_veterinaria.db`).
Para recrearla: `sqlite3 bd_veterinaria.db < bd_veterinaria.sql`.

## Notas técnicas

- `sqlite-jdbc` 3.45 necesita `slf4j-api`; sin ese jar aparece `NoClassDefFoundError: org/slf4j/LoggerFactory`.
- EclipseLink no trae plataforma para SQLite: `SQLitePlatform` le enseña a leer el id con
  `last_insert_rowid()`, necesario para `@GeneratedValue(strategy = GenerationType.IDENTITY)`.
- Todas las ventanas comparten una sola `EntityManagerFactory`, creada en `Main` y cerrada al salir del menú.
