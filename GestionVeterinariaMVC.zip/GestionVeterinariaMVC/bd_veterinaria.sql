-- Base de datos SQLite: bd_veterinaria.db
-- Crear desde la carpeta del proyecto con:  sqlite3 bd_veterinaria.db < bd_veterinaria.sql

-- MODULO 1: Clientes (duenos de las mascotas)
CREATE TABLE IF NOT EXISTS Cliente (
    id INTEGER,
    nombres TEXT,
    documento TEXT,
    telefono TEXT,
    correo TEXT,
    CONSTRAINT pk_cliente PRIMARY KEY(id AUTOINCREMENT)
);

-- MODULO 2: Mascotas
CREATE TABLE IF NOT EXISTS Mascota (
    id INTEGER,
    nombre TEXT,
    especie TEXT,
    raza TEXT,
    edad INTEGER,
    CONSTRAINT pk_mascota PRIMARY KEY(id AUTOINCREMENT)
);

-- MODULO 3: Veterinarios
CREATE TABLE IF NOT EXISTS Veterinario (
    id INTEGER,
    nombres TEXT,
    especialidad TEXT,
    telefono TEXT,
    correo TEXT,
    CONSTRAINT pk_veterinario PRIMARY KEY(id AUTOINCREMENT)
);

-- MODULO 4: Medicamentos
CREATE TABLE IF NOT EXISTS Medicamento (
    id INTEGER,
    nombre TEXT,
    laboratorio TEXT,
    precio REAL,
    stock INTEGER,
    CONSTRAINT pk_medicamento PRIMARY KEY(id AUTOINCREMENT)
);

INSERT INTO Cliente (nombres, documento, telefono, correo) VALUES
('Laura Gomez Rincon', '1098765432', '3104567890', 'laura.gomez@gmail.com'),
('Carlos Andres Pinto', '1095123456', '3159876543', 'carlos.pinto@hotmail.com'),
('Maria Fernanda Rojas', '1102345678', '3001234567', 'mafe.rojas@gmail.com'),
('Jorge Ivan Duarte', '91234567', '3176543210', 'jorge.duarte@uts.edu.co'),
('Valentina Suarez', '1098001122', '3125550011', 'vale.suarez@gmail.com'),
('Andres Felipe Mora', '1096443322', '3187776655', 'andres.mora@hotmail.com');

INSERT INTO Mascota (nombre, especie, raza, edad) VALUES
('Max', 'Perro', 'Labrador', 4),
('Luna', 'Gato', 'Siames', 2),
('Rocky', 'Perro', 'Bulldog', 6),
('Milo', 'Gato', 'Criollo', 1),
('Kiara', 'Perro', 'Golden Retriever', 3),
('Coco', 'Ave', 'Periquito', 2);

INSERT INTO Veterinario (nombres, especialidad, telefono, correo) VALUES
('Dra. Paola Castellanos', 'Medicina General', '3201112233', 'paola.castellanos@vet.com'),
('Dr. Ricardo Ardila', 'Cirugia', '3202223344', 'ricardo.ardila@vet.com'),
('Dra. Natalia Ortiz', 'Dermatologia', '3203334455', 'natalia.ortiz@vet.com'),
('Dr. Fabian Leal', 'Odontologia', '3204445566', 'fabian.leal@vet.com');

INSERT INTO Medicamento (nombre, laboratorio, precio, stock) VALUES
('Amoxicilina 250mg', 'Bayer', 18500, 40),
('Meloxicam 1.5mg/ml', 'Boehringer', 32000, 25),
('Ivermectina 1%', 'Zoetis', 21000, 30),
('Vacuna Rabia', 'MSD', 45000, 15),
('Desparasitante Drontal', 'Bayer', 27500, 50);
