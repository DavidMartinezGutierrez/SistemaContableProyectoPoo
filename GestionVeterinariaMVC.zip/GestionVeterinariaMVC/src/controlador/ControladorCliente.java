package controlador;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.util.List;
import javax.swing.JOptionPane;
import modelo.Cliente;
import persistencia.ClienteJpaController;
import persistencia.exceptions.NonexistentEntityException;
import vista.FrmCliente;

/**
 * MODULO 1 - Controlador MVC de Clientes. Une la vista FrmCliente con ClienteJpaController.
 */
public class ControladorCliente implements ActionListener {

    private final FrmCliente vista;
    private final ClienteJpaController jpaController;

    public ControladorCliente(FrmCliente vista, ClienteJpaController jpaController) {
        this.vista = vista;
        this.jpaController = jpaController;
        // Suscribir los botones de la vista a este controlador
        this.vista.btnGuardar.addActionListener(this);
        this.vista.btnActualizar.addActionListener(this);
        this.vista.btnEliminar.addActionListener(this);
        this.vista.btnLimpiar.addActionListener(this);
        // Clic sobre una fila: pasar los datos al formulario
        this.vista.tablaClientes.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                seleccionarFila();
            }
        });
        listarClientes();
    }

    public void iniciar() {
        vista.setVisible(true);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == vista.btnGuardar) {
            guardarCliente();
        } else if (e.getSource() == vista.btnActualizar) {
            actualizarCliente();
        } else if (e.getSource() == vista.btnEliminar) {
            eliminarCliente();
        } else if (e.getSource() == vista.btnLimpiar) {
            limpiarFormulario();
        }
    }

    private void listarClientes() {
        vista.modeloTabla.setRowCount(0);
        List<Cliente> lista = jpaController.findClienteEntities();
        for (Cliente c : lista) {
            Object[] fila = {c.getId(), c.getNombres(), c.getDocumento(), c.getTelefono(), c.getCorreo()};
            vista.modeloTabla.addRow(fila);
        }
    }

    private void guardarCliente() {
        if (validarCampos()) {
            try {
                Cliente nuevo = new Cliente();
                llenarDesdeFormulario(nuevo);
                jpaController.create(nuevo);
                JOptionPane.showMessageDialog(vista, "Cliente registrado exitosamente con ID: " + nuevo.getId());
                listarClientes();
                limpiarFormulario();
            } catch (Exception ex) {
                JOptionPane.showMessageDialog(vista, "Error al guardar: " + ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
            }
        }
    }

    private void actualizarCliente() {
        if (vista.txtId.getText().isEmpty()) {
            JOptionPane.showMessageDialog(vista, "Seleccione primero un registro de la tabla para actualizar.", "Advertencia", JOptionPane.WARNING_MESSAGE);
            return;
        }
        if (validarCampos()) {
            try {
                Cliente c = new Cliente(Integer.valueOf(vista.txtId.getText()));
                llenarDesdeFormulario(c);
                jpaController.edit(c);
                JOptionPane.showMessageDialog(vista, "Registro actualizado correctamente.");
                listarClientes();
                limpiarFormulario();
            } catch (NonexistentEntityException ex) {
                JOptionPane.showMessageDialog(vista, "El cliente con ese ID ya no existe en la BD.", "Error", JOptionPane.ERROR_MESSAGE);
            } catch (Exception ex) {
                JOptionPane.showMessageDialog(vista, "Error al actualizar: " + ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
            }
        }
    }

    private void eliminarCliente() {
        if (vista.txtId.getText().isEmpty()) {
            JOptionPane.showMessageDialog(vista, "Seleccione un registro de la tabla para eliminar.", "Advertencia", JOptionPane.WARNING_MESSAGE);
            return;
        }
        int confirmacion = JOptionPane.showConfirmDialog(vista,
                "¿Esta seguro de eliminar a " + vista.txtNombres.getText() + "?",
                "Confirmar Eliminacion", JOptionPane.YES_NO_OPTION);
        if (confirmacion == JOptionPane.YES_OPTION) {
            try {
                jpaController.destroy(Integer.valueOf(vista.txtId.getText()));
                JOptionPane.showMessageDialog(vista, "Registro eliminado correctamente.");
                listarClientes();
                limpiarFormulario();
            } catch (NonexistentEntityException ex) {
                JOptionPane.showMessageDialog(vista, "El registro no existe.", "Error", JOptionPane.ERROR_MESSAGE);
            }
        }
    }

    private void llenarDesdeFormulario(Cliente c) {
        c.setNombres(vista.txtNombres.getText().trim());
        c.setDocumento(vista.txtDocumento.getText().trim());
        c.setTelefono(vista.txtTelefono.getText().trim());
        c.setCorreo(vista.txtCorreo.getText().trim());
    }

    private void seleccionarFila() {
        int fila = vista.tablaClientes.getSelectedRow();
        if (fila >= 0) {
            vista.txtId.setText(String.valueOf(vista.tablaClientes.getValueAt(fila, 0)));
            vista.txtNombres.setText(String.valueOf(vista.tablaClientes.getValueAt(fila, 1)));
            vista.txtDocumento.setText(String.valueOf(vista.tablaClientes.getValueAt(fila, 2)));
            vista.txtTelefono.setText(String.valueOf(vista.tablaClientes.getValueAt(fila, 3)));
            vista.txtCorreo.setText(String.valueOf(vista.tablaClientes.getValueAt(fila, 4)));
        }
    }

    private void limpiarFormulario() {
        vista.txtId.setText("");
        vista.txtNombres.setText("");
        vista.txtDocumento.setText("");
        vista.txtTelefono.setText("");
        vista.txtCorreo.setText("");
        vista.tablaClientes.clearSelection();
    }

    private boolean validarCampos() {
        if (vista.txtNombres.getText().trim().isEmpty()
                || vista.txtDocumento.getText().trim().isEmpty()
                || vista.txtTelefono.getText().trim().isEmpty()
                || vista.txtCorreo.getText().trim().isEmpty()) {
            JOptionPane.showMessageDialog(vista, "Todos los campos son obligatorios.", "Validacion", JOptionPane.WARNING_MESSAGE);
            return false;
        }
        return true;
    }
}
