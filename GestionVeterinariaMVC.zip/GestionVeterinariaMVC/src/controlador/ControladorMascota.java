package controlador;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.util.List;
import javax.swing.JOptionPane;
import modelo.Mascota;
import persistencia.MascotaJpaController;
import persistencia.exceptions.NonexistentEntityException;
import vista.FrmMascota;

/**
 * MODULO 2 - Controlador MVC de Mascotas. Une la vista FrmMascota con MascotaJpaController.
 */
public class ControladorMascota implements ActionListener {

    private final FrmMascota vista;
    private final MascotaJpaController jpaController;

    public ControladorMascota(FrmMascota vista, MascotaJpaController jpaController) {
        this.vista = vista;
        this.jpaController = jpaController;
        this.vista.btnGuardar.addActionListener(this);
        this.vista.btnActualizar.addActionListener(this);
        this.vista.btnEliminar.addActionListener(this);
        this.vista.btnLimpiar.addActionListener(this);
        this.vista.tablaMascotas.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                seleccionarFila();
            }
        });
        listarMascotas();
    }

    public void iniciar() {
        vista.setVisible(true);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == vista.btnGuardar) {
            guardarMascota();
        } else if (e.getSource() == vista.btnActualizar) {
            actualizarMascota();
        } else if (e.getSource() == vista.btnEliminar) {
            eliminarMascota();
        } else if (e.getSource() == vista.btnLimpiar) {
            limpiarFormulario();
        }
    }

    private void listarMascotas() {
        vista.modeloTabla.setRowCount(0);
        List<Mascota> lista = jpaController.findMascotaEntities();
        for (Mascota m : lista) {
            Object[] fila = {m.getId(), m.getNombre(), m.getEspecie(), m.getRaza(), m.getEdad()};
            vista.modeloTabla.addRow(fila);
        }
    }

    private void guardarMascota() {
        if (validarCampos()) {
            try {
                Mascota nueva = new Mascota();
                llenarDesdeFormulario(nueva);
                jpaController.create(nueva);
                JOptionPane.showMessageDialog(vista, "Mascota registrada exitosamente con ID: " + nueva.getId());
                listarMascotas();
                limpiarFormulario();
            } catch (Exception ex) {
                JOptionPane.showMessageDialog(vista, "Error al guardar: " + ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
            }
        }
    }

    private void actualizarMascota() {
        if (vista.txtId.getText().isEmpty()) {
            JOptionPane.showMessageDialog(vista, "Seleccione primero un registro de la tabla para actualizar.", "Advertencia", JOptionPane.WARNING_MESSAGE);
            return;
        }
        if (validarCampos()) {
            try {
                Mascota m = new Mascota(Integer.valueOf(vista.txtId.getText()));
                llenarDesdeFormulario(m);
                jpaController.edit(m);
                JOptionPane.showMessageDialog(vista, "Registro actualizado correctamente.");
                listarMascotas();
                limpiarFormulario();
            } catch (NonexistentEntityException ex) {
                JOptionPane.showMessageDialog(vista, "La mascota con ese ID ya no existe en la BD.", "Error", JOptionPane.ERROR_MESSAGE);
            } catch (Exception ex) {
                JOptionPane.showMessageDialog(vista, "Error al actualizar: " + ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
            }
        }
    }

    private void eliminarMascota() {
        if (vista.txtId.getText().isEmpty()) {
            JOptionPane.showMessageDialog(vista, "Seleccione un registro de la tabla para eliminar.", "Advertencia", JOptionPane.WARNING_MESSAGE);
            return;
        }
        int confirmacion = JOptionPane.showConfirmDialog(vista,
                "¿Esta seguro de eliminar a " + vista.txtNombre.getText() + "?",
                "Confirmar Eliminacion", JOptionPane.YES_NO_OPTION);
        if (confirmacion == JOptionPane.YES_OPTION) {
            try {
                jpaController.destroy(Integer.valueOf(vista.txtId.getText()));
                JOptionPane.showMessageDialog(vista, "Registro eliminado correctamente.");
                listarMascotas();
                limpiarFormulario();
            } catch (NonexistentEntityException ex) {
                JOptionPane.showMessageDialog(vista, "El registro no existe.", "Error", JOptionPane.ERROR_MESSAGE);
            }
        }
    }

    private void llenarDesdeFormulario(Mascota m) {
        m.setNombre(vista.txtNombre.getText().trim());
        m.setEspecie((String) vista.cboEspecie.getSelectedItem());
        m.setRaza(vista.txtRaza.getText().trim());
        m.setEdad(Integer.valueOf(vista.txtEdad.getText().trim()));
    }

    private void seleccionarFila() {
        int fila = vista.tablaMascotas.getSelectedRow();
        if (fila >= 0) {
            vista.txtId.setText(String.valueOf(vista.tablaMascotas.getValueAt(fila, 0)));
            vista.txtNombre.setText(String.valueOf(vista.tablaMascotas.getValueAt(fila, 1)));
            vista.cboEspecie.setSelectedItem(String.valueOf(vista.tablaMascotas.getValueAt(fila, 2)));
            vista.txtRaza.setText(String.valueOf(vista.tablaMascotas.getValueAt(fila, 3)));
            vista.txtEdad.setText(String.valueOf(vista.tablaMascotas.getValueAt(fila, 4)));
        }
    }

    private void limpiarFormulario() {
        vista.txtId.setText("");
        vista.txtNombre.setText("");
        vista.cboEspecie.setSelectedIndex(0);
        vista.txtRaza.setText("");
        vista.txtEdad.setText("");
        vista.tablaMascotas.clearSelection();
    }

    private boolean validarCampos() {
        if (vista.txtNombre.getText().trim().isEmpty()
                || vista.txtRaza.getText().trim().isEmpty()
                || vista.txtEdad.getText().trim().isEmpty()) {
            JOptionPane.showMessageDialog(vista, "Nombre, Raza y Edad son obligatorios.", "Validacion", JOptionPane.WARNING_MESSAGE);
            return false;
        }
        try {
            int edad = Integer.parseInt(vista.txtEdad.getText().trim());
            if (edad < 0 || edad > 40) {
                throw new NumberFormatException();
            }
        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(vista, "La edad debe ser un numero entero entre 0 y 40.", "Validacion", JOptionPane.WARNING_MESSAGE);
            return false;
        }
        return true;
    }
}
