package controlador;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.util.List;
import javax.swing.JOptionPane;
import modelo.Medicamento;
import persistencia.MedicamentoJpaController;
import persistencia.exceptions.NonexistentEntityException;
import vista.FrmMedicamento;

/**
 * MODULO 4 - Controlador MVC de Medicamentos. Une la vista FrmMedicamento con MedicamentoJpaController.
 */
public class ControladorMedicamento implements ActionListener {

    private final FrmMedicamento vista;
    private final MedicamentoJpaController jpaController;

    public ControladorMedicamento(FrmMedicamento vista, MedicamentoJpaController jpaController) {
        this.vista = vista;
        this.jpaController = jpaController;
        this.vista.btnGuardar.addActionListener(this);
        this.vista.btnActualizar.addActionListener(this);
        this.vista.btnEliminar.addActionListener(this);
        this.vista.btnLimpiar.addActionListener(this);
        this.vista.tablaMedicamentos.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                seleccionarFila();
            }
        });
        listarMedicamentos();
    }

    public void iniciar() {
        vista.setVisible(true);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == vista.btnGuardar) {
            guardarMedicamento();
        } else if (e.getSource() == vista.btnActualizar) {
            actualizarMedicamento();
        } else if (e.getSource() == vista.btnEliminar) {
            eliminarMedicamento();
        } else if (e.getSource() == vista.btnLimpiar) {
            limpiarFormulario();
        }
    }

    private void listarMedicamentos() {
        vista.modeloTabla.setRowCount(0);
        List<Medicamento> lista = jpaController.findMedicamentoEntities();
        for (Medicamento m : lista) {
            Object[] fila = {m.getId(), m.getNombre(), m.getLaboratorio(), m.getPrecio(), m.getStock()};
            vista.modeloTabla.addRow(fila);
        }
    }

    private void guardarMedicamento() {
        if (validarCampos()) {
            try {
                Medicamento nuevo = new Medicamento();
                llenarDesdeFormulario(nuevo);
                jpaController.create(nuevo);
                JOptionPane.showMessageDialog(vista, "Medicamento registrado exitosamente con ID: " + nuevo.getId());
                listarMedicamentos();
                limpiarFormulario();
            } catch (Exception ex) {
                JOptionPane.showMessageDialog(vista, "Error al guardar: " + ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
            }
        }
    }

    private void actualizarMedicamento() {
        if (vista.txtId.getText().isEmpty()) {
            JOptionPane.showMessageDialog(vista, "Seleccione primero un registro de la tabla para actualizar.", "Advertencia", JOptionPane.WARNING_MESSAGE);
            return;
        }
        if (validarCampos()) {
            try {
                Medicamento m = new Medicamento(Integer.valueOf(vista.txtId.getText()));
                llenarDesdeFormulario(m);
                jpaController.edit(m);
                JOptionPane.showMessageDialog(vista, "Registro actualizado correctamente.");
                listarMedicamentos();
                limpiarFormulario();
            } catch (NonexistentEntityException ex) {
                JOptionPane.showMessageDialog(vista, "El medicamento con ese ID ya no existe en la BD.", "Error", JOptionPane.ERROR_MESSAGE);
            } catch (Exception ex) {
                JOptionPane.showMessageDialog(vista, "Error al actualizar: " + ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
            }
        }
    }

    private void eliminarMedicamento() {
        if (vista.txtId.getText().isEmpty()) {
            JOptionPane.showMessageDialog(vista, "Seleccione un registro de la tabla para eliminar.", "Advertencia", JOptionPane.WARNING_MESSAGE);
            return;
        }
        int confirmacion = JOptionPane.showConfirmDialog(vista,
                "¿Esta seguro de eliminar " + vista.txtNombre.getText() + "?",
                "Confirmar Eliminacion", JOptionPane.YES_NO_OPTION);
        if (confirmacion == JOptionPane.YES_OPTION) {
            try {
                jpaController.destroy(Integer.valueOf(vista.txtId.getText()));
                JOptionPane.showMessageDialog(vista, "Registro eliminado correctamente.");
                listarMedicamentos();
                limpiarFormulario();
            } catch (NonexistentEntityException ex) {
                JOptionPane.showMessageDialog(vista, "El registro no existe.", "Error", JOptionPane.ERROR_MESSAGE);
            }
        }
    }

    private void llenarDesdeFormulario(Medicamento m) {
        m.setNombre(vista.txtNombre.getText().trim());
        m.setLaboratorio(vista.txtLaboratorio.getText().trim());
        m.setPrecio(Double.valueOf(vista.txtPrecio.getText().trim()));
        m.setStock(Integer.valueOf(vista.txtStock.getText().trim()));
    }

    private void seleccionarFila() {
        int fila = vista.tablaMedicamentos.getSelectedRow();
        if (fila >= 0) {
            vista.txtId.setText(String.valueOf(vista.tablaMedicamentos.getValueAt(fila, 0)));
            vista.txtNombre.setText(String.valueOf(vista.tablaMedicamentos.getValueAt(fila, 1)));
            vista.txtLaboratorio.setText(String.valueOf(vista.tablaMedicamentos.getValueAt(fila, 2)));
            vista.txtPrecio.setText(String.valueOf(vista.tablaMedicamentos.getValueAt(fila, 3)));
            vista.txtStock.setText(String.valueOf(vista.tablaMedicamentos.getValueAt(fila, 4)));
        }
    }

    private void limpiarFormulario() {
        vista.txtId.setText("");
        vista.txtNombre.setText("");
        vista.txtLaboratorio.setText("");
        vista.txtPrecio.setText("");
        vista.txtStock.setText("");
        vista.tablaMedicamentos.clearSelection();
    }

    private boolean validarCampos() {
        if (vista.txtNombre.getText().trim().isEmpty()
                || vista.txtLaboratorio.getText().trim().isEmpty()
                || vista.txtPrecio.getText().trim().isEmpty()
                || vista.txtStock.getText().trim().isEmpty()) {
            JOptionPane.showMessageDialog(vista, "Todos los campos son obligatorios.", "Validacion", JOptionPane.WARNING_MESSAGE);
            return false;
        }
        try {
            if (Double.parseDouble(vista.txtPrecio.getText().trim()) < 0) {
                throw new NumberFormatException();
            }
        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(vista, "El precio debe ser un numero mayor o igual a 0 (use punto para decimales).", "Validacion", JOptionPane.WARNING_MESSAGE);
            return false;
        }
        try {
            if (Integer.parseInt(vista.txtStock.getText().trim()) < 0) {
                throw new NumberFormatException();
            }
        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(vista, "El stock debe ser un numero entero mayor o igual a 0.", "Validacion", JOptionPane.WARNING_MESSAGE);
            return false;
        }
        return true;
    }
}
