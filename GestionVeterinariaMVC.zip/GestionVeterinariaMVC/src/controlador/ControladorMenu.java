package controlador;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import javax.persistence.EntityManagerFactory;
import persistencia.ClienteJpaController;
import persistencia.MascotaJpaController;
import persistencia.MedicamentoJpaController;
import persistencia.VeterinarioJpaController;
import vista.FrmCliente;
import vista.FrmMascota;
import vista.FrmMedicamento;
import vista.FrmMenuPrincipal;
import vista.FrmVeterinario;

/**
 * Controlador del menu principal: abre cada modulo con su propio MVC.
 * Todos los modulos comparten una sola EntityManagerFactory (una conexion a bd_veterinaria.db).
 */
public class ControladorMenu implements ActionListener {

    private final FrmMenuPrincipal vista;
    private final EntityManagerFactory emf;

    public ControladorMenu(FrmMenuPrincipal vista, EntityManagerFactory emf) {
        this.vista = vista;
        this.emf = emf;
        this.vista.btnClientes.addActionListener(this);
        this.vista.btnMascotas.addActionListener(this);
        this.vista.btnVeterinarios.addActionListener(this);
        this.vista.btnMedicamentos.addActionListener(this);
        this.vista.btnSalir.addActionListener(this);
        this.vista.addWindowListener(new WindowAdapter() {
            @Override
            public void windowClosing(WindowEvent e) {
                salir();
            }
        });
    }

    public void iniciar() {
        vista.setVisible(true);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == vista.btnClientes) {
            new ControladorCliente(new FrmCliente(), new ClienteJpaController(emf)).iniciar();
        } else if (e.getSource() == vista.btnMascotas) {
            new ControladorMascota(new FrmMascota(), new MascotaJpaController(emf)).iniciar();
        } else if (e.getSource() == vista.btnVeterinarios) {
            new ControladorVeterinario(new FrmVeterinario(), new VeterinarioJpaController(emf)).iniciar();
        } else if (e.getSource() == vista.btnMedicamentos) {
            new ControladorMedicamento(new FrmMedicamento(), new MedicamentoJpaController(emf)).iniciar();
        } else if (e.getSource() == vista.btnSalir) {
            salir();
        }
    }

    private void salir() {
        if (emf.isOpen()) {
            emf.close();
        }
        System.exit(0);
    }
}
