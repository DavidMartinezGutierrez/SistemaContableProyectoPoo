package controlador;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.util.List;
import javax.swing.JOptionPane;
import modelo.Veterinario;
import persistencia.VeterinarioJpaController;
import persistencia.exceptions.NonexistentEntityException;
import vista.FrmVeterinario;

/**
 * MODULO 3 - Controlador MVC de Veterinarios. Une la vista FrmVeterinario con VeterinarioJpaController.
 */
public class ControladorVeterinario implements ActionListener {

    private final FrmVeterinario vista;
    private final VeterinarioJpaController jpaController;

    public ControladorVeterinario(FrmVeterinario vista, VeterinarioJpaController jpaController) {
        this.vista = vista;
        this.jpaController = jpaController;
        // Suscribir los botones de la vista a este controlador
        this.vista.btnGuardar.addActionListener(this);
        this.vista.btnActualizar.addActionListener(this);
        this.vista.btnEliminar.addActionListener(this);
        this.vista.btnLimpiar.addActionListener(this);
        // Clic sobre una fila: pasar los datos al formulario
        this.vista.tablaVeterinarios.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                seleccionarFila();
            }
        });
        listarVeterinarios();
    }

    public void iniciar() {
        vista.setVisible(true);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == vista.btnGuardar) {
            guardarVeterinario();
        } else if (e.getSource() == vista.btnActualizar) {
            actualizarVeterinario();
        } else if (e.getSource() == vista.btnEliminar) {
            eliminarVeterinario();
        } else if (e.getSource() == vista.btnLimpiar) {
            limpiarFormulario();
        }
    }

    private void listarVeterinarios() {
        vista.modeloTabla.setRowCount(0);
        List<Veterinario> lista = jpaController.findVeterinarioEntities();
        for (Veterinario c : lista) {
            Object[] fila = {c.getId(), c.getNombres(), c.getEspecialidad(), c.getTelefono(), c.getCorreo()};
            vista.modeloTabla.addRow(fila);
        }
    }

    private void guardarVeterinario() {
        if (validarCampos()) {
            try {
                Veterinario nuevo = new Veterinario();
                llenarDesdeFormulario(nuevo);
                jpaController.create(nuevo);
                JOptionPane.showMessageDialog(vista, "Veterinario registrado exitosamente con ID: " + nuevo.getId());
                listarVeterinarios();
                limpiarFormulario();
            } catch (Exception ex) {
                JOptionPane.showMessageDialog(vista, "Error al guardar: " + ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
            }
        }
    }

    private void actualizarVeterinario() {
        if (vista.txtId.getText().isEmpty()) {
            JOptionPane.showMessageDialog(vista, "Seleccione primero un registro de la tabla para actualizar.", "Advertencia", JOptionPane.WARNING_MESSAGE);
            return;
        }
        if (validarCampos()) {
            try {
                Veterinario c = new Veterinario(Integer.valueOf(vista.txtId.getText()));
                llenarDesdeFormulario(c);
                jpaController.edit(c);
                JOptionPane.showMessageDialog(vista, "Registro actualizado correctamente.");
                listarVeterinarios();
                limpiarFormulario();
            } catch (NonexistentEntityException ex) {
                JOptionPane.showMessageDialog(vista, "El veterinario con ese ID ya no existe en la BD.", "Error", JOptionPane.ERROR_MESSAGE);
            } catch (Exception ex) {
                JOptionPane.showMessageDialog(vista, "Error al actualizar: " + ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
            }
        }
    }

    private void eliminarVeterinario() {
        if (vista.txtId.getText().isEmpty()) {
            JOptionPane.showMessageDialog(vista, "Seleccione un registro de la tabla para eliminar.", "Advertencia", JOptionPane.WARNING_MESSAGE);
            return;
        }
        int confirmacion = JOptionPane.showConfirmDialog(vista,
                "¿Esta seguro de eliminar a " + vista.txtNombres.getText() + "?",
                "Confirmar Eliminacion", JOptionPane.YES_NO_OPTION);
        if (confirmacion == JOptionPane.YES_OPTION) {
            try {
                jpaController.destroy(Integer.valueOf(vista.txtId.getText()));
                JOptionPane.showMessageDialog(vista, "Registro eliminado correctamente.");
                listarVeterinarios();
                limpiarFormulario();
            } catch (NonexistentEntityException ex) {
                JOptionPane.showMessageDialog(vista, "El registro no existe.", "Error", JOptionPane.ERROR_MESSAGE);
            }
        }
    }

    private void llenarDesdeFormulario(Veterinario c) {
        c.setNombres(vista.txtNombres.getText().trim());
        c.setEspecialidad(vista.txtEspecialidad.getText().trim());
        c.setTelefono(vista.txtTelefono.getText().trim());
        c.setCorreo(vista.txtCorreo.getText().trim());
    }

    private void seleccionarFila() {
        int fila = vista.tablaVeterinarios.getSelectedRow();
        if (fila >= 0) {
            vista.txtId.setText(String.valueOf(vista.tablaVeterinarios.getValueAt(fila, 0)));
            vista.txtNombres.setText(String.valueOf(vista.tablaVeterinarios.getValueAt(fila, 1)));
            vista.txtEspecialidad.setText(String.valueOf(vista.tablaVeterinarios.getValueAt(fila, 2)));
            vista.txtTelefono.setText(String.valueOf(vista.tablaVeterinarios.getValueAt(fila, 3)));
            vista.txtCorreo.setText(String.valueOf(vista.tablaVeterinarios.getValueAt(fila, 4)));
        }
    }

    private void limpiarFormulario() {
        vista.txtId.setText("");
        vista.txtNombres.setText("");
        vista.txtEspecialidad.setText("");
        vista.txtTelefono.setText("");
        vista.txtCorreo.setText("");
        vista.tablaVeterinarios.clearSelection();
    }

    private boolean validarCampos() {
        if (vista.txtNombres.getText().trim().isEmpty()
                || vista.txtEspecialidad.getText().trim().isEmpty()
                || vista.txtTelefono.getText().trim().isEmpty()
                || vista.txtCorreo.getText().trim().isEmpty()) {
            JOptionPane.showMessageDialog(vista, "Todos los campos son obligatorios.", "Validacion", JOptionPane.WARNING_MESSAGE);
            return false;
        }
        return true;
    }
}
