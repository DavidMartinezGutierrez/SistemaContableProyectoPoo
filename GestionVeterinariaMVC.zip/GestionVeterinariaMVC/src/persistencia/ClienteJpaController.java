package persistencia;

import java.io.Serializable;
import java.util.List;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityNotFoundException;
import javax.persistence.Persistence;
import javax.persistence.TypedQuery;
import javax.persistence.criteria.CriteriaQuery;
import modelo.Cliente;
import persistencia.exceptions.NonexistentEntityException;

/**
 * MODULO 1 - Operaciones CRUD de Cliente con JPA (EclipseLink).
 */
public class ClienteJpaController implements Serializable {

    private EntityManagerFactory emf = null;

    // Constructor con EntityManagerFactory (estilo NetBeans), permite compartir una sola fabrica
    public ClienteJpaController(EntityManagerFactory emf) {
        this.emf = emf;
    }

    // Constructor por defecto que crea su propia Unidad de Persistencia
    public ClienteJpaController() {
        this.emf = Persistence.createEntityManagerFactory("GestionVeterinariaMVCPU");
    }

    public EntityManager getEntityManager() {
        return emf.createEntityManager();
    }

    // CREATE: Inserta un nuevo cliente
    public void create(Cliente cliente) {
        EntityManager em = null;
        try {
            em = getEntityManager();
            em.getTransaction().begin();
            em.persist(cliente);
            em.getTransaction().commit();
        } finally {
            if (em != null) {
                em.close();
            }
        }
    }

    // UPDATE: Actualiza un cliente existente usando merge()
    public void edit(Cliente cliente) throws NonexistentEntityException, Exception {
        EntityManager em = null;
        try {
            em = getEntityManager();
            em.getTransaction().begin();
            cliente = em.merge(cliente);
            em.getTransaction().commit();
        } catch (Exception ex) {
            String msg = ex.getLocalizedMessage();
            if (msg == null || msg.length() == 0) {
                Integer id = cliente.getId();
                if (findCliente(id) == null) {
                    throw new NonexistentEntityException("El cliente con id " + id + " ya no existe.");
                }
            }
            throw ex;
        } finally {
            if (em != null) {
                em.close();
            }
        }
    }

    // DELETE: Elimina un cliente por su id
    public void destroy(Integer id) throws NonexistentEntityException {
        EntityManager em = null;
        try {
            em = getEntityManager();
            em.getTransaction().begin();
            Cliente cliente;
            try {
                cliente = em.getReference(Cliente.class, id);
                cliente.getId();
            } catch (EntityNotFoundException enfe) {
                throw new NonexistentEntityException("El cliente con id " + id + " ya no existe.", enfe);
            }
            em.remove(cliente);
            em.getTransaction().commit();
        } finally {
            if (em != null) {
                em.close();
            }
        }
    }

    // READ ALL: Obtiene todos los clientes
    public List<Cliente> findClienteEntities() {
        EntityManager em = getEntityManager();
        try {
            CriteriaQuery<Cliente> cq = em.getCriteriaBuilder().createQuery(Cliente.class);
            cq.select(cq.from(Cliente.class));
            TypedQuery<Cliente> q = em.createQuery(cq);
            return q.getResultList();
        } finally {
            em.close();
        }
    }

    // READ ONE: Busca un cliente por id
    public Cliente findCliente(Integer id) {
        EntityManager em = getEntityManager();
        try {
            return em.find(Cliente.class, id);
        } finally {
            em.close();
        }
    }
}
