package persistencia;

import java.io.Serializable;
import java.util.List;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityNotFoundException;
import javax.persistence.Persistence;
import javax.persistence.TypedQuery;
import javax.persistence.criteria.CriteriaQuery;
import modelo.Medicamento;
import persistencia.exceptions.NonexistentEntityException;

/**
 * MODULO 4 - Operaciones CRUD de Medicamento con JPA (EclipseLink).
 */
public class MedicamentoJpaController implements Serializable {

    private EntityManagerFactory emf = null;

    public MedicamentoJpaController(EntityManagerFactory emf) {
        this.emf = emf;
    }

    public MedicamentoJpaController() {
        this.emf = Persistence.createEntityManagerFactory("GestionVeterinariaMVCPU");
    }

    public EntityManager getEntityManager() {
        return emf.createEntityManager();
    }

    // CREATE
    public void create(Medicamento medicamento) {
        EntityManager em = null;
        try {
            em = getEntityManager();
            em.getTransaction().begin();
            em.persist(medicamento);
            em.getTransaction().commit();
        } finally {
            if (em != null) {
                em.close();
            }
        }
    }

    // UPDATE
    public void edit(Medicamento medicamento) throws NonexistentEntityException, Exception {
        EntityManager em = null;
        try {
            em = getEntityManager();
            em.getTransaction().begin();
            medicamento = em.merge(medicamento);
            em.getTransaction().commit();
        } catch (Exception ex) {
            String msg = ex.getLocalizedMessage();
            if (msg == null || msg.length() == 0) {
                Integer id = medicamento.getId();
                if (findMedicamento(id) == null) {
                    throw new NonexistentEntityException("El medicamento con id " + id + " ya no existe.");
                }
            }
            throw ex;
        } finally {
            if (em != null) {
                em.close();
            }
        }
    }

    // DELETE
    public void destroy(Integer id) throws NonexistentEntityException {
        EntityManager em = null;
        try {
            em = getEntityManager();
            em.getTransaction().begin();
            Medicamento medicamento;
            try {
                medicamento = em.getReference(Medicamento.class, id);
                medicamento.getId();
            } catch (EntityNotFoundException enfe) {
                throw new NonexistentEntityException("El medicamento con id " + id + " ya no existe.", enfe);
            }
            em.remove(medicamento);
            em.getTransaction().commit();
        } finally {
            if (em != null) {
                em.close();
            }
        }
    }

    // READ ALL
    public List<Medicamento> findMedicamentoEntities() {
        EntityManager em = getEntityManager();
        try {
            CriteriaQuery<Medicamento> cq = em.getCriteriaBuilder().createQuery(Medicamento.class);
            cq.select(cq.from(Medicamento.class));
            TypedQuery<Medicamento> q = em.createQuery(cq);
            return q.getResultList();
        } finally {
            em.close();
        }
    }

    // READ ONE
    public Medicamento findMedicamento(Integer id) {
        EntityManager em = getEntityManager();
        try {
            return em.find(Medicamento.class, id);
        } finally {
            em.close();
        }
    }
}
