package persistencia;

import org.eclipse.persistence.platform.database.DatabasePlatform;
import org.eclipse.persistence.queries.ValueReadQuery;

/**
 * EclipseLink no trae una plataforma para SQLite. Esta clase le indica como
 * recuperar el id generado por AUTOINCREMENT despues de un INSERT, para que
 * funcione @GeneratedValue(strategy = GenerationType.IDENTITY).
 */
public class SQLitePlatform extends DatabasePlatform {

    @Override
    public boolean supportsIdentity() {
        return true;
    }

    @Override
    public ValueReadQuery buildSelectQueryForIdentity() {
        return new ValueReadQuery("SELECT last_insert_rowid()");
    }
}
