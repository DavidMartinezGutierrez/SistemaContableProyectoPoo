package persistencia;

import java.io.Serializable;
import java.util.List;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityNotFoundException;
import javax.persistence.Persistence;
import javax.persistence.TypedQuery;
import javax.persistence.criteria.CriteriaQuery;
import modelo.Veterinario;
import persistencia.exceptions.NonexistentEntityException;

/**
 * MODULO 3 - Operaciones CRUD de Veterinario con JPA (EclipseLink).
 */
public class VeterinarioJpaController implements Serializable {

    private EntityManagerFactory emf = null;

    // Constructor con EntityManagerFactory (estilo NetBeans), permite compartir una sola fabrica
    public VeterinarioJpaController(EntityManagerFactory emf) {
        this.emf = emf;
    }

    // Constructor por defecto que crea su propia Unidad de Persistencia
    public VeterinarioJpaController() {
        this.emf = Persistence.createEntityManagerFactory("GestionVeterinariaMVCPU");
    }

    public EntityManager getEntityManager() {
        return emf.createEntityManager();
    }

    // CREATE: Inserta un nuevo veterinario
    public void create(Veterinario veterinario) {
        EntityManager em = null;
        try {
            em = getEntityManager();
            em.getTransaction().begin();
            em.persist(veterinario);
            em.getTransaction().commit();
        } finally {
            if (em != null) {
                em.close();
            }
        }
    }

    // UPDATE: Actualiza un veterinario existente usando merge()
    public void edit(Veterinario veterinario) throws NonexistentEntityException, Exception {
        EntityManager em = null;
        try {
            em = getEntityManager();
            em.getTransaction().begin();
            veterinario = em.merge(veterinario);
            em.getTransaction().commit();
        } catch (Exception ex) {
            String msg = ex.getLocalizedMessage();
            if (msg == null || msg.length() == 0) {
                Integer id = veterinario.getId();
                if (findVeterinario(id) == null) {
                    throw new NonexistentEntityException("El veterinario con id " + id + " ya no existe.");
                }
            }
            throw ex;
        } finally {
            if (em != null) {
                em.close();
            }
        }
    }

    // DELETE: Elimina un veterinario por su id
    public void destroy(Integer id) throws NonexistentEntityException {
        EntityManager em = null;
        try {
            em = getEntityManager();
            em.getTransaction().begin();
            Veterinario veterinario;
            try {
                veterinario = em.getReference(Veterinario.class, id);
                veterinario.getId();
            } catch (EntityNotFoundException enfe) {
                throw new NonexistentEntityException("El veterinario con id " + id + " ya no existe.", enfe);
            }
            em.remove(veterinario);
            em.getTransaction().commit();
        } finally {
            if (em != null) {
                em.close();
            }
        }
    }

    // READ ALL: Obtiene todos los veterinarios
    public List<Veterinario> findVeterinarioEntities() {
        EntityManager em = getEntityManager();
        try {
            CriteriaQuery<Veterinario> cq = em.getCriteriaBuilder().createQuery(Veterinario.class);
            cq.select(cq.from(Veterinario.class));
            TypedQuery<Veterinario> q = em.createQuery(cq);
            return q.getResultList();
        } finally {
            em.close();
        }
    }

    // READ ONE: Busca un veterinario por id
    public Veterinario findVeterinario(Integer id) {
        EntityManager em = getEntityManager();
        try {
            return em.find(Veterinario.class, id);
        } finally {
            em.close();
        }
    }
}
