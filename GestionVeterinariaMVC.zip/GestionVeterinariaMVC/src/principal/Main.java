package principal;

import controlador.ControladorMenu;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.swing.JOptionPane;
import javax.swing.SwingUtilities;
import javax.swing.UIManager;
import vista.FrmMenuPrincipal;

public class Main {

    public static void main(String[] args) {
        // Aplicar el estilo visual nativo del sistema operativo
        try {
            UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
        } catch (Exception e) {
            System.err.println("No se pudo aplicar el LookAndFeel: " + e.getMessage());
        }
        // Iniciar la aplicacion dentro del Event Dispatch Thread (EDT) de Swing
        SwingUtilities.invokeLater(() -> {
            try {
                EntityManagerFactory emf = Persistence.createEntityManagerFactory("GestionVeterinariaMVCPU");
                ControladorMenu controlador = new ControladorMenu(new FrmMenuPrincipal(), emf);
                controlador.iniciar();
            } catch (Exception ex) {
                JOptionPane.showMessageDialog(null, "No se pudo iniciar la unidad de persistencia: " + ex.getMessage(),
                        "Error", JOptionPane.ERROR_MESSAGE);
            }
        });
    }
}
