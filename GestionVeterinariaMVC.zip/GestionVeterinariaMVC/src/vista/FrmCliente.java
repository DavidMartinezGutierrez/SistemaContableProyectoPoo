package vista;

import java.awt.BorderLayout;
import java.awt.FlowLayout;
import java.awt.GridLayout;
import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.table.DefaultTableModel;

/**
 * MODULO 1 - Vista de Clientes. Solo construye la ventana: no conoce JPA ni SQLite.
 */
public class FrmCliente extends JFrame {

    // Campos de texto expuestos para el Controlador MVC
    public JTextField txtId = new JTextField(10);
    public JTextField txtNombres = new JTextField(25);
    public JTextField txtDocumento = new JTextField(15);
    public JTextField txtTelefono = new JTextField(15);
    public JTextField txtCorreo = new JTextField(25);
    // Botones de accion CRUD
    public JButton btnGuardar = new JButton("Guardar (Crear)");
    public JButton btnActualizar = new JButton("Actualizar");
    public JButton btnEliminar = new JButton("Eliminar");
    public JButton btnLimpiar = new JButton("Limpiar / Nuevo");
    // Tabla con los registros
    public JTable tablaClientes = new JTable();
    public DefaultTableModel modeloTabla;

    public FrmCliente() {
        setTitle("Modulo 1 - Gestion de Clientes");
        setSize(820, 540);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLocationRelativeTo(null);
        setLayout(new BorderLayout(10, 10));

        // 1. Panel superior: formulario
        JPanel panelFormulario = new JPanel(new GridLayout(5, 2, 8, 8));
        panelFormulario.setBorder(BorderFactory.createTitledBorder("Datos del Cliente"));
        txtId.setEditable(false); // SQLite lo calcula con AUTOINCREMENT
        panelFormulario.add(new JLabel("ID (Autoincremental):"));
        panelFormulario.add(txtId);
        panelFormulario.add(new JLabel("Nombres Completos:"));
        panelFormulario.add(txtNombres);
        panelFormulario.add(new JLabel("Documento:"));
        panelFormulario.add(txtDocumento);
        panelFormulario.add(new JLabel("Telefono:"));
        panelFormulario.add(txtTelefono);
        panelFormulario.add(new JLabel("Correo Electronico:"));
        panelFormulario.add(txtCorreo);

        // 2. Botonera CRUD
        JPanel panelBotones = new JPanel(new FlowLayout(FlowLayout.CENTER, 15, 10));
        panelBotones.add(btnGuardar);
        panelBotones.add(btnActualizar);
        panelBotones.add(btnEliminar);
        panelBotones.add(btnLimpiar);

        JPanel panelNorte = new JPanel(new BorderLayout());
        panelNorte.setBorder(BorderFactory.createEmptyBorder(10, 10, 5, 10));
        panelNorte.add(panelFormulario, BorderLayout.CENTER);
        panelNorte.add(panelBotones, BorderLayout.SOUTH);

        // 3. Tabla de solo lectura
        String[] columnas = {"ID", "Nombres", "Documento", "Telefono", "Correo"};
        modeloTabla = new DefaultTableModel(null, columnas) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };
        tablaClientes.setModel(modeloTabla);
        JScrollPane scrollTabla = new JScrollPane(tablaClientes);
        scrollTabla.setBorder(BorderFactory.createTitledBorder("Listado de Clientes (bd_veterinaria.db)"));

        add(panelNorte, BorderLayout.NORTH);
        add(scrollTabla, BorderLayout.CENTER);
    }
}
