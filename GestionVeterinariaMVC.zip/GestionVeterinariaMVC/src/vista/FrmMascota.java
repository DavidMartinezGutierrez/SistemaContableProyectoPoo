package vista;

import java.awt.BorderLayout;
import java.awt.FlowLayout;
import java.awt.GridLayout;
import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.table.DefaultTableModel;

/**
 * MODULO 2 - Vista de Mascotas. Solo construye la ventana: no conoce JPA ni SQLite.
 */
public class FrmMascota extends JFrame {

    public JTextField txtId = new JTextField(10);
    public JTextField txtNombre = new JTextField(20);
    public JComboBox<String> cboEspecie = new JComboBox<>(new String[]{"Perro", "Gato", "Ave", "Conejo", "Otro"});
    public JTextField txtRaza = new JTextField(20);
    public JTextField txtEdad = new JTextField(5);

    public JButton btnGuardar = new JButton("Guardar (Crear)");
    public JButton btnActualizar = new JButton("Actualizar");
    public JButton btnEliminar = new JButton("Eliminar");
    public JButton btnLimpiar = new JButton("Limpiar / Nuevo");

    public JTable tablaMascotas = new JTable();
    public DefaultTableModel modeloTabla;

    public FrmMascota() {
        setTitle("Modulo 2 - Gestion de Mascotas");
        setSize(820, 540);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLocationRelativeTo(null);
        setLayout(new BorderLayout(10, 10));

        JPanel panelFormulario = new JPanel(new GridLayout(5, 2, 8, 8));
        panelFormulario.setBorder(BorderFactory.createTitledBorder("Datos de la Mascota"));
        txtId.setEditable(false);
        panelFormulario.add(new JLabel("ID (Autoincremental):"));
        panelFormulario.add(txtId);
        panelFormulario.add(new JLabel("Nombre:"));
        panelFormulario.add(txtNombre);
        panelFormulario.add(new JLabel("Especie:"));
        panelFormulario.add(cboEspecie);
        panelFormulario.add(new JLabel("Raza:"));
        panelFormulario.add(txtRaza);
        panelFormulario.add(new JLabel("Edad (anios):"));
        panelFormulario.add(txtEdad);

        JPanel panelBotones = new JPanel(new FlowLayout(FlowLayout.CENTER, 15, 10));
        panelBotones.add(btnGuardar);
        panelBotones.add(btnActualizar);
        panelBotones.add(btnEliminar);
        panelBotones.add(btnLimpiar);

        JPanel panelNorte = new JPanel(new BorderLayout());
        panelNorte.setBorder(BorderFactory.createEmptyBorder(10, 10, 5, 10));
        panelNorte.add(panelFormulario, BorderLayout.CENTER);
        panelNorte.add(panelBotones, BorderLayout.SOUTH);

        String[] columnas = {"ID", "Nombre", "Especie", "Raza", "Edad"};
        modeloTabla = new DefaultTableModel(null, columnas) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };
        tablaMascotas.setModel(modeloTabla);
        JScrollPane scrollTabla = new JScrollPane(tablaMascotas);
        scrollTabla.setBorder(BorderFactory.createTitledBorder("Listado de Mascotas (bd_veterinaria.db)"));

        add(panelNorte, BorderLayout.NORTH);
        add(scrollTabla, BorderLayout.CENTER);
    }
}
