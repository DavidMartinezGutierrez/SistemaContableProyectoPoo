package vista;

import java.awt.BorderLayout;
import java.awt.FlowLayout;
import java.awt.GridLayout;
import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.table.DefaultTableModel;

/**
 * MODULO 4 - Vista de Medicamentos. Solo construye la ventana: no conoce JPA ni SQLite.
 */
public class FrmMedicamento extends JFrame {

    public JTextField txtId = new JTextField(10);
    public JTextField txtNombre = new JTextField(25);
    public JTextField txtLaboratorio = new JTextField(20);
    public JTextField txtPrecio = new JTextField(10);
    public JTextField txtStock = new JTextField(6);

    public JButton btnGuardar = new JButton("Guardar (Crear)");
    public JButton btnActualizar = new JButton("Actualizar");
    public JButton btnEliminar = new JButton("Eliminar");
    public JButton btnLimpiar = new JButton("Limpiar / Nuevo");

    public JTable tablaMedicamentos = new JTable();
    public DefaultTableModel modeloTabla;

    public FrmMedicamento() {
        setTitle("Modulo 4 - Inventario de Medicamentos");
        setSize(820, 540);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLocationRelativeTo(null);
        setLayout(new BorderLayout(10, 10));

        JPanel panelFormulario = new JPanel(new GridLayout(5, 2, 8, 8));
        panelFormulario.setBorder(BorderFactory.createTitledBorder("Datos del Medicamento"));
        txtId.setEditable(false);
        panelFormulario.add(new JLabel("ID (Autoincremental):"));
        panelFormulario.add(txtId);
        panelFormulario.add(new JLabel("Nombre:"));
        panelFormulario.add(txtNombre);
        panelFormulario.add(new JLabel("Laboratorio:"));
        panelFormulario.add(txtLaboratorio);
        panelFormulario.add(new JLabel("Precio ($):"));
        panelFormulario.add(txtPrecio);
        panelFormulario.add(new JLabel("Stock (unidades):"));
        panelFormulario.add(txtStock);

        JPanel panelBotones = new JPanel(new FlowLayout(FlowLayout.CENTER, 15, 10));
        panelBotones.add(btnGuardar);
        panelBotones.add(btnActualizar);
        panelBotones.add(btnEliminar);
        panelBotones.add(btnLimpiar);

        JPanel panelNorte = new JPanel(new BorderLayout());
        panelNorte.setBorder(BorderFactory.createEmptyBorder(10, 10, 5, 10));
        panelNorte.add(panelFormulario, BorderLayout.CENTER);
        panelNorte.add(panelBotones, BorderLayout.SOUTH);

        String[] columnas = {"ID", "Nombre", "Laboratorio", "Precio", "Stock"};
        modeloTabla = new DefaultTableModel(null, columnas) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };
        tablaMedicamentos.setModel(modeloTabla);
        JScrollPane scrollTabla = new JScrollPane(tablaMedicamentos);
        scrollTabla.setBorder(BorderFactory.createTitledBorder("Listado de Medicamentos (bd_veterinaria.db)"));

        add(panelNorte, BorderLayout.NORTH);
        add(scrollTabla, BorderLayout.CENTER);
    }
}
