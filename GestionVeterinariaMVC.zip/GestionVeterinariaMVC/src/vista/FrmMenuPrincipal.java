package vista;

import java.awt.BorderLayout;
import java.awt.Font;
import java.awt.GridLayout;
import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.SwingConstants;

/**
 * Menu principal: un boton por cada modulo (un modulo por estudiante).
 */
public class FrmMenuPrincipal extends JFrame {

    public JButton btnClientes = new JButton("1. Clientes");
    public JButton btnMascotas = new JButton("2. Mascotas");
    public JButton btnVeterinarios = new JButton("3. Veterinarios");
    public JButton btnMedicamentos = new JButton("4. Medicamentos");
    public JButton btnSalir = new JButton("Salir");

    public FrmMenuPrincipal() {
        setTitle("Veterinaria - MVC + JPA (EclipseLink) + SQLite");
        setSize(420, 380);
        setDefaultCloseOperation(JFrame.DO_NOTHING_ON_CLOSE); // El controlador cierra la BD al salir
        setLocationRelativeTo(null);
        setLayout(new BorderLayout(10, 10));

        JLabel lblTitulo = new JLabel("Gestion Veterinaria", SwingConstants.CENTER);
        lblTitulo.setFont(lblTitulo.getFont().deriveFont(Font.BOLD, 20f));
        lblTitulo.setBorder(BorderFactory.createEmptyBorder(15, 10, 0, 10));

        JPanel panelBotones = new JPanel(new GridLayout(5, 1, 10, 10));
        panelBotones.setBorder(BorderFactory.createEmptyBorder(10, 40, 20, 40));
        panelBotones.add(btnClientes);
        panelBotones.add(btnMascotas);
        panelBotones.add(btnVeterinarios);
        panelBotones.add(btnMedicamentos);
        panelBotones.add(btnSalir);

        add(lblTitulo, BorderLayout.NORTH);
        add(panelBotones, BorderLayout.CENTER);
    }
}
