-- ============================================================================
-- PROYECTO: SISTEMA ACADÉMICO CON CONTROL DE ACCESO BASADO EN ROLES (RBAC)
-- INSTITUCIÓN: UNIDADES TECNOLÓGICAS DE SANTANDER (UTS)
-- MATERIAS: PROGRAMACIÓN ORIENTADA A OBJETOS & MOTORES DE BASES DE DATOS
-- MOTOR: PostgreSQL 14+ / pgAdmin 4
-- DATOS: 100% FICTICIOS - PENSUM COMPLETO 1° A 6° SEMESTRE Y HORARIO REAL UTS
-- ============================================================================

SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;

-- ----------------------------------------------------------------------------
-- 0. LIMPIEZA EN CASCADA
-- ----------------------------------------------------------------------------
DROP TRIGGER IF EXISTS trg_auditoria_asistencias ON asistencias;
DROP TRIGGER IF EXISTS trg_auditoria_calificaciones ON calificaciones;
DROP TRIGGER IF EXISTS trg_validar_rango_nota ON calificaciones;

DROP FUNCTION IF EXISTS fn_trg_auditoria_asistencias() CASCADE;
DROP FUNCTION IF EXISTS fn_trg_auditoria_calificaciones() CASCADE;
DROP FUNCTION IF EXISTS fn_trg_validar_rango_nota() CASCADE;

DROP PROCEDURE IF EXISTS sp_matricular_estudiante(INT, INT);
DROP PROCEDURE IF EXISTS sp_registrar_o_actualizar_nota(INT, NUMERIC, NUMERIC, NUMERIC);
DROP PROCEDURE IF EXISTS sp_registrar_asistencia(INT, INT, DATE, VARCHAR, VARCHAR);

DROP FUNCTION IF EXISTS fn_porcentaje_asistencia(INT, INT);
DROP FUNCTION IF EXISTS fn_porcentaje_creditos(INT);
DROP FUNCTION IF EXISTS fn_calcular_promedio_estudiante(INT);

DROP TABLE IF EXISTS auditoria_academica CASCADE;
DROP TABLE IF EXISTS asistencias CASCADE;
DROP TABLE IF EXISTS calificaciones CASCADE;
DROP TABLE IF EXISTS matriculas CASCADE;
DROP TABLE IF EXISTS horarios CASCADE;
DROP TABLE IF EXISTS grupos CASCADE;
DROP TABLE IF EXISTS asignaturas CASCADE;
DROP TABLE IF EXISTS estudiantes_detalle CASCADE;
DROP TABLE IF EXISTS usuarios CASCADE;
DROP TABLE IF EXISTS programas CASCADE;

-- ----------------------------------------------------------------------------
-- 1. TABLAS NORMALIZADAS
-- ----------------------------------------------------------------------------

-- 1.1. Programas Académicos y Pensum
CREATE TABLE programas (
    id SERIAL PRIMARY KEY,
    codigo VARCHAR(20) NOT NULL UNIQUE,
    nombre VARCHAR(150) NOT NULL,
    sede VARCHAR(60) NOT NULL DEFAULT 'SEDE PRINCIPAL',
    pensum VARCHAR(30) NOT NULL,
    total_creditos INT NOT NULL CHECK (total_creditos > 0),
    activo BOOLEAN NOT NULL DEFAULT TRUE,
    fecha_creacion TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
);

-- 1.2. Usuarios (RBAC)
CREATE TABLE usuarios (
    id SERIAL PRIMARY KEY,
    documento VARCHAR(20) NOT NULL UNIQUE,
    nombre_completo VARCHAR(150) NOT NULL,
    correo_institucional VARCHAR(120) NOT NULL UNIQUE,
    password_hash VARCHAR(255) NOT NULL,
    rol VARCHAR(20) NOT NULL CHECK (rol IN ('ADMIN', 'DOCENTE', 'ESTUDIANTE')),
    activo BOOLEAN NOT NULL DEFAULT TRUE,
    fecha_creacion TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT chk_correo_valido CHECK (correo_institucional ~* '^[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}$')
);

-- 1.3. Detalle Académico del Estudiante
CREATE TABLE estudiantes_detalle (
    id SERIAL PRIMARY KEY,
    usuario_id INT NOT NULL UNIQUE REFERENCES usuarios(id) ON DELETE CASCADE,
    programa_id INT NOT NULL REFERENCES programas(id) ON DELETE RESTRICT,
    jornada VARCHAR(20) NOT NULL CHECK (jornada IN ('DIURNA', 'NOCTURNA', 'VIRTUAL')),
    situacion VARCHAR(20) NOT NULL DEFAULT 'ACTIVO' CHECK (situacion IN ('ACTIVO', 'INACTIVO', 'GRADUADO', 'SUSPENDIDO')),
    categoria VARCHAR(20) NOT NULL DEFAULT 'NUEVO' CHECK (categoria IN ('NUEVO', 'ANTIGUO', 'REINGRESO', 'TRANSFERENCIA')),
    creditos_aprobados INT NOT NULL DEFAULT 0 CHECK (creditos_aprobados >= 0),
    promedio_acumulado NUMERIC(3,2) NOT NULL DEFAULT 0.00 CHECK (promedio_acumulado >= 0.00 AND promedio_acumulado <= 5.00)
);

-- 1.4. Asignaturas Curriculares del Plan de Estudios
CREATE TABLE asignaturas (
    id SERIAL PRIMARY KEY,
    programa_id INT NOT NULL REFERENCES programas(id) ON DELETE RESTRICT,
    codigo VARCHAR(20) NOT NULL UNIQUE,
    nombre VARCHAR(120) NOT NULL,
    creditos INT NOT NULL CHECK (creditos > 0 AND creditos <= 10),
    semestre INT NOT NULL CHECK (semestre >= 1 AND semestre <= 6),
    activo BOOLEAN NOT NULL DEFAULT TRUE
);

-- 1.5. Grupos de Clases
CREATE TABLE grupos (
    id SERIAL PRIMARY KEY,
    asignatura_id INT NOT NULL REFERENCES asignaturas(id) ON DELETE RESTRICT,
    docente_id INT NOT NULL REFERENCES usuarios(id) ON DELETE RESTRICT,
    codigo_grupo VARCHAR(20) NOT NULL,
    periodo_academico VARCHAR(10) NOT NULL,
    cupo_maximo INT NOT NULL DEFAULT 35 CHECK (cupo_maximo > 0),
    activo BOOLEAN NOT NULL DEFAULT TRUE,
    CONSTRAINT uq_grupo_periodo UNIQUE (asignatura_id, codigo_grupo, periodo_academico)
);

-- 1.6. Horarios Semanales y Salones / Espacios Físicos (Formato Oficial UTS)
CREATE TABLE horarios (
    id SERIAL PRIMARY KEY,
    grupo_id INT NOT NULL REFERENCES grupos(id) ON DELETE CASCADE,
    dia_semana VARCHAR(15) NOT NULL CHECK (dia_semana IN ('LUNES', 'MARTES', 'MIERCOLES', 'JUEVES', 'VIERNES', 'SABADO')),
    hora_inicio TIME NOT NULL,
    hora_fin TIME NOT NULL,
    aula VARCHAR(50) NOT NULL,
    CONSTRAINT chk_rango_horario CHECK (hora_fin > hora_inicio)
);

-- 1.7. Matrículas Académicas
CREATE TABLE matriculas (
    id SERIAL PRIMARY KEY,
    estudiante_id INT NOT NULL REFERENCES usuarios(id) ON DELETE RESTRICT,
    grupo_id INT NOT NULL REFERENCES grupos(id) ON DELETE RESTRICT,
    fecha_matricula TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    estado VARCHAR(20) NOT NULL DEFAULT 'MATRICULADA' CHECK (estado IN ('MATRICULADA', 'CANCELADA', 'APROBADA', 'REPROBADA')),
    CONSTRAINT uq_matricula_estudiante_grupo UNIQUE (estudiante_id, grupo_id)
);

-- 1.8. Calificaciones (30% - 30% - 40%)
CREATE TABLE calificaciones (
    id SERIAL PRIMARY KEY,
    matricula_id INT NOT NULL UNIQUE REFERENCES matriculas(id) ON DELETE CASCADE,
    corte1 NUMERIC(3,2) CHECK (corte1 IS NULL OR (corte1 >= 0.00 AND corte1 <= 5.00)),
    corte2 NUMERIC(3,2) CHECK (corte2 IS NULL OR (corte2 >= 0.00 AND corte2 <= 5.00)),
    corte3 NUMERIC(3,2) CHECK (corte3 IS NULL OR (corte3 >= 0.00 AND corte3 <= 5.00)),
    definitiva NUMERIC(3,2) CHECK (definitiva IS NULL OR (definitiva >= 0.00 AND definitiva <= 5.00)),
    fecha_actualizacion TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
);

-- 1.9. Control Diario de Asistencias
CREATE TABLE asistencias (
    id SERIAL PRIMARY KEY,
    matricula_id INT NOT NULL REFERENCES matriculas(id) ON DELETE CASCADE,
    fecha DATE NOT NULL DEFAULT CURRENT_DATE,
    estado VARCHAR(20) NOT NULL CHECK (estado IN ('PRESENTE', 'AUSENTE', 'JUSTIFICADO')),
    observaciones VARCHAR(255),
    fecha_registro TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT uq_asistencia_dia UNIQUE (matricula_id, fecha)
);

-- 1.10. Auditoría Académica con JSONB
CREATE TABLE auditoria_academica (
    id SERIAL PRIMARY KEY,
    tabla_afectada VARCHAR(50) NOT NULL,
    operacion VARCHAR(20) NOT NULL CHECK (operacion IN ('INSERT', 'UPDATE', 'DELETE')),
    registro_id INT NOT NULL,
    usuario_db VARCHAR(100) NOT NULL DEFAULT CURRENT_USER,
    valores_anteriores JSONB,
    valores_nuevos JSONB,
    fecha_hora TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
);

-- Índices
CREATE INDEX idx_usuarios_rol ON usuarios(rol);
CREATE INDEX idx_estudiantes_detalle_prog ON estudiantes_detalle(programa_id);
CREATE INDEX idx_asignaturas_semestre ON asignaturas(semestre);
CREATE INDEX idx_grupos_docente ON grupos(docente_id);
CREATE INDEX idx_matriculas_estudiante ON matriculas(estudiante_id);
CREATE INDEX idx_calificaciones_matricula ON calificaciones(matricula_id);
CREATE INDEX idx_asistencias_matricula ON asistencias(matricula_id);
CREATE INDEX idx_auditoria_tabla ON auditoria_academica(tabla_afectada, fecha_hora);

-- ----------------------------------------------------------------------------
-- 2. FUNCIONES DE NEGOCIO (CREATE OR REPLACE FUNCTION)
-- ----------------------------------------------------------------------------

-- 2.1. Promedio Ponderado Acumulado
CREATE OR REPLACE FUNCTION fn_calcular_promedio_estudiante(p_estudiante_id INT)
RETURNS NUMERIC AS $$
DECLARE
    v_promedio NUMERIC(3,2);
    v_total_creditos INT;
    v_suma_ponderada NUMERIC(10,2);
BEGIN
    SELECT 
        SUM(c.definitiva * a.creditos),
        SUM(a.creditos)
    INTO v_suma_ponderada, v_total_creditos
    FROM matriculas m
    INNER JOIN grupos g ON m.grupo_id = g.id
    INNER JOIN asignaturas a ON g.asignatura_id = a.id
    INNER JOIN calificaciones c ON c.matricula_id = m.id
    WHERE m.estudiante_id = p_estudiante_id
      AND c.definitiva IS NOT NULL;

    IF v_total_creditos IS NOT NULL AND v_total_creditos > 0 THEN
        v_promedio := ROUND((v_suma_ponderada / v_total_creditos), 2);
    ELSE
        SELECT COALESCE(promedio_acumulado, 0.00)
        INTO v_promedio
        FROM estudiantes_detalle
        WHERE usuario_id = p_estudiante_id;
    END IF;

    RETURN COALESCE(v_promedio, 0.00);
END;
$$ LANGUAGE plpgsql;

-- 2.2. Porcentaje de Créditos Aprobados Respecto al Pensum
CREATE OR REPLACE FUNCTION fn_porcentaje_creditos(p_estudiante_id INT)
RETURNS NUMERIC AS $$
DECLARE
    v_creditos_aprobados INT;
    v_total_creditos_pensum INT;
    v_porcentaje NUMERIC(5,2);
BEGIN
    SELECT ed.creditos_aprobados, p.total_creditos
    INTO v_creditos_aprobados, v_total_creditos_pensum
    FROM estudiantes_detalle ed
    INNER JOIN programas p ON ed.programa_id = p.id
    WHERE ed.usuario_id = p_estudiante_id;

    IF NOT FOUND OR v_total_creditos_pensum IS NULL OR v_total_creditos_pensum = 0 THEN
        RETURN 0.00;
    END IF;

    v_porcentaje := ROUND(((v_creditos_aprobados::NUMERIC / v_total_creditos_pensum::NUMERIC) * 100.0), 2);
    RETURN v_porcentaje;
END;
$$ LANGUAGE plpgsql;

-- 2.3. Porcentaje de Asistencia en una Asignatura
CREATE OR REPLACE FUNCTION fn_porcentaje_asistencia(p_estudiante_id INT, p_asignatura_id INT)
RETURNS NUMERIC AS $$
DECLARE
    v_total_sesiones INT;
    v_asistencias_validas INT;
    v_porcentaje NUMERIC(5,2);
BEGIN
    SELECT 
        COUNT(asi.id),
        COUNT(CASE WHEN asi.estado IN ('PRESENTE', 'JUSTIFICADO') THEN 1 END)
    INTO v_total_sesiones, v_asistencias_validas
    FROM matriculas m
    INNER JOIN grupos g ON m.grupo_id = g.id
    INNER JOIN asistencias asi ON asi.matricula_id = m.id
    WHERE m.estudiante_id = p_estudiante_id
      AND g.asignatura_id = p_asignatura_id;

    IF v_total_sesiones IS NULL OR v_total_sesiones = 0 THEN
        RETURN 100.00;
    END IF;

    v_porcentaje := ROUND(((v_asistencias_validas::NUMERIC / v_total_sesiones::NUMERIC) * 100.0), 2);
    RETURN v_porcentaje;
END;
$$ LANGUAGE plpgsql;

-- ----------------------------------------------------------------------------
-- 3. PROCEDIMIENTOS ALMACENADOS (CREATE OR REPLACE PROCEDURE)
-- ----------------------------------------------------------------------------

-- 3.1. Registrar o Actualizar Asistencia
CREATE OR REPLACE PROCEDURE sp_registrar_asistencia(
    IN p_estudiante_id INT,
    IN p_grupo_id INT,
    IN p_fecha DATE,
    IN p_estado VARCHAR,
    IN p_observaciones VARCHAR DEFAULT NULL
)
LANGUAGE plpgsql
AS $$
DECLARE
    v_matricula_id INT;
BEGIN
    SELECT id INTO v_matricula_id
    FROM matriculas
    WHERE estudiante_id = p_estudiante_id
      AND grupo_id = p_grupo_id
      AND estado = 'MATRICULADA';

    IF v_matricula_id IS NULL THEN
        RAISE EXCEPTION 'No se encontró matrícula activa para el estudiante % en el grupo %.', p_estudiante_id, p_grupo_id;
    END IF;

    IF p_estado NOT IN ('PRESENTE', 'AUSENTE', 'JUSTIFICADO') THEN
        RAISE EXCEPTION 'Estado de asistencia inválido: %. Valores permitidos: PRESENTE, AUSENTE, JUSTIFICADO.', p_estado;
    END IF;

    INSERT INTO asistencias (matricula_id, fecha, estado, observaciones, fecha_registro)
    VALUES (v_matricula_id, p_fecha, p_estado, p_observaciones, CURRENT_TIMESTAMP)
    ON CONFLICT (matricula_id, fecha)
    DO UPDATE SET
        estado = EXCLUDED.estado,
        observaciones = EXCLUDED.observaciones,
        fecha_registro = CURRENT_TIMESTAMP;
END;
$$;

-- 3.2. Registrar o Actualizar Nota por Corte (30% - 30% - 40%)
CREATE OR REPLACE PROCEDURE sp_registrar_o_actualizar_nota(
    IN p_matricula_id INT,
    IN p_corte1 NUMERIC DEFAULT NULL,
    IN p_corte2 NUMERIC DEFAULT NULL,
    IN p_corte3 NUMERIC DEFAULT NULL
)
LANGUAGE plpgsql
AS $$
DECLARE
    v_definitiva NUMERIC(3,2);
    v_estudiante_id INT;
    v_promedio_nuevo NUMERIC(3,2);
BEGIN
    SELECT m.estudiante_id INTO v_estudiante_id
    FROM matriculas m
    WHERE m.id = p_matricula_id;

    IF NOT FOUND THEN
        RAISE EXCEPTION 'Matrícula con ID % no encontrada.', p_matricula_id;
    END IF;

    -- Ponderación UTS: 30% Corte 1 + 30% Corte 2 + 40% Corte 3
    IF p_corte1 IS NOT NULL AND p_corte2 IS NOT NULL AND p_corte3 IS NOT NULL THEN
        v_definitiva := ROUND((p_corte1 * 0.30) + (p_corte2 * 0.30) + (p_corte3 * 0.40), 2);
    ELSE
        v_definitiva := NULL;
    END IF;

    INSERT INTO calificaciones (matricula_id, corte1, corte2, corte3, definitiva, fecha_actualizacion)
    VALUES (p_matricula_id, p_corte1, p_corte2, p_corte3, v_definitiva, CURRENT_TIMESTAMP)
    ON CONFLICT (matricula_id)
    DO UPDATE SET
        corte1 = EXCLUDED.corte1,
        corte2 = EXCLUDED.corte2,
        corte3 = EXCLUDED.corte3,
        definitiva = EXCLUDED.definitiva,
        fecha_actualizacion = CURRENT_TIMESTAMP;

    IF v_definitiva IS NOT NULL THEN
        IF v_definitiva >= 3.00 THEN
            UPDATE matriculas SET estado = 'APROBADA' WHERE id = p_matricula_id;
        ELSE
            UPDATE matriculas SET estado = 'REPROBADA' WHERE id = p_matricula_id;
        END IF;

        v_promedio_nuevo := fn_calcular_promedio_estudiante(v_estudiante_id);
        UPDATE estudiantes_detalle
        SET promedio_acumulado = v_promedio_nuevo
        WHERE usuario_id = v_estudiante_id;
    END IF;
END;
$$;

-- 3.3. Matricular Estudiante
CREATE OR REPLACE PROCEDURE sp_matricular_estudiante(
    IN p_estudiante_id INT,
    IN p_grupo_id INT
)
LANGUAGE plpgsql
AS $$
DECLARE
    v_es_estudiante BOOLEAN;
    v_esta_activo BOOLEAN;
    v_cupo_max INT;
    v_matriculados INT;
    v_asignatura_id INT;
    v_periodo VARCHAR(10);
    v_materia_ya_matriculada INT;
    v_nueva_matricula_id INT;
BEGIN
    SELECT (rol = 'ESTUDIANTE'), activo
    INTO v_es_estudiante, v_esta_activo
    FROM usuarios WHERE id = p_estudiante_id;

    IF NOT FOUND THEN
        RAISE EXCEPTION 'El usuario con ID % no existe.', p_estudiante_id;
    END IF;
    IF NOT v_es_estudiante THEN
        RAISE EXCEPTION 'El usuario con ID % no tiene rol de ESTUDIANTE.', p_estudiante_id;
    END IF;
    IF NOT v_esta_activo THEN
        RAISE EXCEPTION 'El estudiante con ID % está inactivo.', p_estudiante_id;
    END IF;

    SELECT cupo_maximo, asignatura_id, periodo_academico
    INTO v_cupo_max, v_asignatura_id, v_periodo
    FROM grupos WHERE id = p_grupo_id AND activo = TRUE;

    IF NOT FOUND THEN
        RAISE EXCEPTION 'El grupo con ID % no existe o está inactivo.', p_grupo_id;
    END IF;

    IF EXISTS (SELECT 1 FROM matriculas WHERE estudiante_id = p_estudiante_id AND grupo_id = p_grupo_id) THEN
        RAISE EXCEPTION 'El estudiante % ya está matriculado en este grupo.', p_estudiante_id;
    END IF;

    SELECT m.id INTO v_materia_ya_matriculada
    FROM matriculas m
    INNER JOIN grupos g ON m.grupo_id = g.id
    WHERE m.estudiante_id = p_estudiante_id
      AND g.asignatura_id = v_asignatura_id
      AND g.periodo_academico = v_periodo
      AND m.estado = 'MATRICULADA';

    IF v_materia_ya_matriculada IS NOT NULL THEN
        RAISE EXCEPTION 'El estudiante ya tiene matriculada esta materia en el período %.', v_periodo;
    END IF;

    SELECT COUNT(*) INTO v_matriculados
    FROM matriculas WHERE grupo_id = p_grupo_id AND estado = 'MATRICULADA';

    IF v_matriculados >= v_cupo_max THEN
        RAISE EXCEPTION 'Sin cupo disponible (Límite: %, Inscritos: %).', v_cupo_max, v_matriculados;
    END IF;

    INSERT INTO matriculas (estudiante_id, grupo_id, fecha_matricula, estado)
    VALUES (p_estudiante_id, p_grupo_id, CURRENT_TIMESTAMP, 'MATRICULADA')
    RETURNING id INTO v_nueva_matricula_id;

    INSERT INTO calificaciones (matricula_id, corte1, corte2, corte3, definitiva, fecha_actualizacion)
    VALUES (v_nueva_matricula_id, NULL, NULL, NULL, NULL, CURRENT_TIMESTAMP);
END;
$$;

-- ----------------------------------------------------------------------------
-- 4. TRIGGERS
-- ----------------------------------------------------------------------------

-- 4.1. Validación de Rango de Nota [0.00, 5.00]
CREATE OR REPLACE FUNCTION fn_trg_validar_rango_nota()
RETURNS TRIGGER AS $$
BEGIN
    IF NEW.corte1 IS NOT NULL AND (NEW.corte1 < 0.00 OR NEW.corte1 > 5.00) THEN
        RAISE EXCEPTION 'Calificación de Corte 1 (%) inválida. Debe estar en el rango [0.00, 5.00].', NEW.corte1;
    END IF;
    IF NEW.corte2 IS NOT NULL AND (NEW.corte2 < 0.00 OR NEW.corte2 > 5.00) THEN
        RAISE EXCEPTION 'Calificación de Corte 2 (%) inválida. Debe estar en el rango [0.00, 5.00].', NEW.corte2;
    END IF;
    IF NEW.corte3 IS NOT NULL AND (NEW.corte3 < 0.00 OR NEW.corte3 > 5.00) THEN
        RAISE EXCEPTION 'Calificación de Corte 3 (%) inválida. Debe estar en el rango [0.00, 5.00].', NEW.corte3;
    END IF;
    IF NEW.definitiva IS NOT NULL AND (NEW.definitiva < 0.00 OR NEW.definitiva > 5.00) THEN
        RAISE EXCEPTION 'Calificación Definitiva (%) inválida. Debe estar en el rango [0.00, 5.00].', NEW.definitiva;
    END IF;
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER trg_validar_rango_nota
BEFORE INSERT OR UPDATE ON calificaciones
FOR EACH ROW EXECUTE FUNCTION fn_trg_validar_rango_nota();

-- 4.2. Auditoría Calificaciones (JSONB)
CREATE OR REPLACE FUNCTION fn_trg_auditoria_calificaciones()
RETURNS TRIGGER AS $$
BEGIN
    IF TG_OP = 'INSERT' THEN
        INSERT INTO auditoria_academica (tabla_afectada, operacion, registro_id, usuario_db, valores_anteriores, valores_nuevos, fecha_hora)
        VALUES ('calificaciones', TG_OP, NEW.id, CURRENT_USER, NULL, to_jsonb(NEW), CURRENT_TIMESTAMP);
        RETURN NEW;
    ELSIF TG_OP = 'UPDATE' THEN
        INSERT INTO auditoria_academica (tabla_afectada, operacion, registro_id, usuario_db, valores_anteriores, valores_nuevos, fecha_hora)
        VALUES ('calificaciones', TG_OP, NEW.id, CURRENT_USER, to_jsonb(OLD), to_jsonb(NEW), CURRENT_TIMESTAMP);
        RETURN NEW;
    ELSIF TG_OP = 'DELETE' THEN
        INSERT INTO auditoria_academica (tabla_afectada, operacion, registro_id, usuario_db, valores_anteriores, valores_nuevos, fecha_hora)
        VALUES ('calificaciones', TG_OP, OLD.id, CURRENT_USER, to_jsonb(OLD), NULL, CURRENT_TIMESTAMP);
        RETURN OLD;
    END IF;
    RETURN NULL;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER trg_auditoria_calificaciones
AFTER INSERT OR UPDATE OR DELETE ON calificaciones
FOR EACH ROW EXECUTE FUNCTION fn_trg_auditoria_calificaciones();

-- 4.3. Auditoría Asistencias (JSONB)
CREATE OR REPLACE FUNCTION fn_trg_auditoria_asistencias()
RETURNS TRIGGER AS $$
BEGIN
    IF TG_OP = 'INSERT' THEN
        INSERT INTO auditoria_academica (tabla_afectada, operacion, registro_id, usuario_db, valores_anteriores, valores_nuevos, fecha_hora)
        VALUES ('asistencias', TG_OP, NEW.id, CURRENT_USER, NULL, to_jsonb(NEW), CURRENT_TIMESTAMP);
        RETURN NEW;
    ELSIF TG_OP = 'UPDATE' THEN
        INSERT INTO auditoria_academica (tabla_afectada, operacion, registro_id, usuario_db, valores_anteriores, valores_nuevos, fecha_hora)
        VALUES ('asistencias', TG_OP, NEW.id, CURRENT_USER, to_jsonb(OLD), to_jsonb(NEW), CURRENT_TIMESTAMP);
        RETURN NEW;
    END IF;
    RETURN NULL;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER trg_auditoria_asistencias
AFTER INSERT OR UPDATE ON asistencias
FOR EACH ROW EXECUTE FUNCTION fn_trg_auditoria_asistencias();

-- ----------------------------------------------------------------------------
-- 5. DATOS SEMILLA 100% FICTICIOS Y PENSUM OFICIAL UTS
-- ----------------------------------------------------------------------------

-- 5.1. Programa Académico
INSERT INTO programas (id, codigo, nombre, sede, pensum, total_creditos, activo)
VALUES (1, 'TSI', 'TECNOLOGIA EN DESARROLLO DE SISTEMAS INFORMATICOS', 'SEDE PRINCIPAL', 'TSI2019-2', 108, TRUE);
SELECT setval('programas_id_seq', (SELECT MAX(id) FROM programas));

-- 5.2. Usuarios Ficticios (Password para todos: 'Uts2026*')
INSERT INTO usuarios (id, documento, nombre_completo, correo_institucional, password_hash, rol, activo)
VALUES 
-- Administrador
(1, '1098112233', 'Ing. Germán Darío Pinzón Blanco', 'gpinzonblanco@uts.edu.co', '$2a$12$e8p4F6v9J12K6w1gq2gC6.oRk5Jq.LdF7V.P2l3oH6e8kX4lq1t9G', 'ADMIN', TRUE),

-- Docentes
(2, '91456789', 'Ing. Ricardo Morales Sandoval', 'rmoraless@uts.edu.co', '$2a$12$e8p4F6v9J12K6w1gq2gC6.oRk5Jq.LdF7V.P2l3oH6e8kX4lq1t9G', 'DOCENTE', TRUE),
(3, '63234567', 'Ing. Claudia Patricia Peña Suárez', 'cpenasuarez@uts.edu.co', '$2a$12$e8p4F6v9J12K6w1gq2gC6.oRk5Jq.LdF7V.P2l3oH6e8kX4lq1t9G', 'DOCENTE', TRUE),

-- Estudiantes Ficticios
(4, '1095334455', 'Andrés Felipe Vargas Rojas', 'afvargasrojas@uts.edu.co', '$2a$12$e8p4F6v9J12K6w1gq2gC6.oRk5Jq.LdF7V.P2l3oH6e8kX4lq1t9G', 'ESTUDIANTE', TRUE),
(5, '1096123456', 'Camila Andrea Pardo Méndez', 'capardomendez@uts.edu.co', '$2a$12$e8p4F6v9J12K6w1gq2gC6.oRk5Jq.LdF7V.P2l3oH6e8kX4lq1t9G', 'ESTUDIANTE', TRUE),
(6, '1097234567', 'Santiago Gómez Villamizar', 'sgomezvillamizar@uts.edu.co', '$2a$12$e8p4F6v9J12K6w1gq2gC6.oRk5Jq.LdF7V.P2l3oH6e8kX4lq1t9G', 'ESTUDIANTE', TRUE);
SELECT setval('usuarios_id_seq', (SELECT MAX(id) FROM usuarios));

-- 5.3. Detalles Académicos Ficticios
INSERT INTO estudiantes_detalle (id, usuario_id, programa_id, jornada, situacion, categoria, creditos_aprobados, promedio_acumulado)
VALUES 
(1, 4, 1, 'DIURNA', 'ACTIVO', 'ANTIGUO', 54, 3.84),  -- Andrés Felipe (50.0% de avance)
(2, 5, 1, 'DIURNA', 'ACTIVO', 'ANTIGUO', 48, 3.92),  -- Camila Andrea
(3, 6, 1, 'DIURNA', 'ACTIVO', 'NUEVO',   18, 3.65);  -- Santiago Gómez
SELECT setval('estudiantes_detalle_id_seq', (SELECT MAX(id) FROM estudiantes_detalle));

-- 5.4. Catálogo de Asignaturas Completo de 1° a 6° Semestre (Fiel a la malla UTS)
INSERT INTO asignaturas (id, programa_id, codigo, nombre, creditos, semestre, activo)
VALUES 
-- 1° SEMESTRE
(1,  1, 'TSI101', 'CALCULO DIFERENCIAL', 3, 1, TRUE),
(2,  1, 'TSI102', 'ALGEBRA SUPERIOR', 3, 1, TRUE),
(3,  1, 'TSI103', 'FUNDAMENTOS DE PROGRAMACION', 4, 1, TRUE),
(4,  1, 'TSI104', 'BASES DE DATOS I', 3, 1, TRUE),
(5,  1, 'TSI105', 'CULTURA FISICA', 2, 1, TRUE),
(6,  1, 'TSI106', 'PROCESOS DE LECTURA Y ESCRITURA', 2, 1, TRUE),

-- 2° SEMESTRE
(7,  1, 'TSI201', 'CALCULO INTEGRAL', 3, 2, TRUE),
(8,  1, 'TSI202', 'MECANICA', 3, 2, TRUE),
(9,  1, 'TSI203', 'LENGUAJES DE PROGRAMACION', 4, 2, TRUE),
(10, 1, 'TSI204', 'BASES DE DATOS II', 3, 2, TRUE),
(11, 1, 'TSI205', 'MATEMATICAS DISCRETAS', 3, 2, TRUE),
(12, 1, 'TSI206', 'HARDWARE Y SOFTWARE DE COMPUTADORES', 3, 2, TRUE),

-- 3° SEMESTRE
(13, 1, 'TSI301', 'MOTORES DE BASES DE DATOS', 3, 3, TRUE),
(14, 1, 'TSI302', 'PROGRAMACION ORIENTADA A OBJETOS', 4, 3, TRUE),
(15, 1, 'TSI303', 'SISTEMAS OPERATIVOS', 3, 3, TRUE),
(16, 1, 'TSI304', 'PLANEACION DE SISTEMAS INFORMATICOS', 3, 3, TRUE),
(17, 1, 'DDI009', 'INGLES I', 2, 3, TRUE),
(18, 1, 'TSI305', 'ESTRUCTURA DE DATOS', 3, 3, TRUE),
(19, 1, 'TSI306', 'SISTEMAS DIGITALES', 3, 3, TRUE),
(20, 1, 'TSI307', 'REDES DE COMUNICACIONES', 3, 3, TRUE),
(21, 1, 'TSI308', 'OPTATIVA I', 2, 3, TRUE),
(22, 1, 'TSI309', 'EPISTEMOLOGIA', 2, 3, TRUE),

-- 4° SEMESTRE
(23, 1, 'DCB010', 'ELECTROMAGNETISMO', 3, 4, TRUE),
(24, 1, 'TSI401', 'DESARROLLO DE FRONTEND', 4, 4, TRUE),
(25, 1, 'TSI402', 'INTERNET DE LAS COSAS', 3, 4, TRUE),
(26, 1, 'TSI403', 'INFRAESTRUCTURA TECNOLOGICA', 3, 4, TRUE),
(27, 1, 'DDI010', 'INGLES II', 2, 4, TRUE),
(28, 1, 'TSI404', 'ETICA', 2, 4, TRUE),

-- 5° SEMESTRE
(29, 1, 'TSI501', 'DESARROLLO BACKEND', 4, 5, TRUE),
(30, 1, 'TSI502', 'APLICACIONES MOVILES', 4, 5, TRUE),
(31, 1, 'TSI503', 'SEMINARIO DE GRADO I', 2, 5, TRUE),
(32, 1, 'TSI504', 'SEGURIDAD EN LOS SISTEMAS INFORMATICOS', 3, 5, TRUE),
(33, 1, 'TSI505', 'ELECTIVA DE PROFUNDIZACION I', 3, 5, TRUE),
(34, 1, 'DHI009', 'PROGRAMACION NEUROLINGUISTICA (OPTATIVA II)', 2, 5, TRUE),

-- 6° SEMESTRE
(35, 1, 'TSI601', 'CALCULO MULTIVARIABLE', 3, 6, TRUE),
(36, 1, 'TSI602', 'INTRODUCCION A LA INGENIERIA', 2, 6, TRUE),
(37, 1, 'TSI603', 'SELECCION Y EVALUACION DE NUEVAS TECNOLOGIAS', 3, 6, TRUE),
(38, 1, 'TSI604', 'DESARROLLO FULL STACK', 4, 6, TRUE),
(39, 1, 'TSI605', 'SEMINARIO DE GRADO II', 2, 6, TRUE),
(40, 1, 'TSI606', 'ELECTIVA DE PROFUNDIZACION II', 3, 6, TRUE);
SELECT setval('asignaturas_id_seq', (SELECT MAX(id) FROM asignaturas));

-- 5.5. Grupos de Clases Ofertados (con Nomenclatura Real UTS: B191, D191, A251, B193, B253)
INSERT INTO grupos (id, asignatura_id, docente_id, codigo_grupo, periodo_academico, cupo_maximo, activo)
VALUES 
(1, 13, 2, 'B191', '2026-1', 35, TRUE), -- TSI301 Motores de Bases de Datos
(2, 14, 2, 'B191', '2026-1', 35, TRUE), -- TSI302 Programación Orientada a Objetos
(3, 15, 2, 'B191', '2026-1', 35, TRUE), -- TSI303 Sistemas Operativos
(4, 16, 3, 'D191', '2026-1', 30, TRUE), -- TSI304 Planeación de Sistemas Informáticos
(5, 23, 3, 'A251', '2026-1', 35, TRUE), -- DCB010 Electromagnetismo
(6, 17, 3, 'B193', '2026-1', 30, TRUE), -- DDI009 Inglés I
(7, 34, 3, 'B253', '2026-1', 30, TRUE), -- DHI009 PNL (Optativa II)
(8, 18, 2, 'B191', '2026-1', 30, TRUE); -- TSI305 Estructura de Datos
SELECT setval('grupos_id_seq', (SELECT MAX(id) FROM grupos));

-- 5.6. Horarios Semanales Oficiales por Franjas y Espacios Físicos Reales (Idéntico a la captura UTS)
INSERT INTO horarios (grupo_id, dia_semana, hora_inicio, hora_fin, aula)
VALUES 
-- TSI301 Motores de Bases de Datos (B191)
(1, 'MARTES',   '09:00:00', '10:29:00', '312 C'),
(1, 'VIERNES',  '10:30:00', '11:59:00', 'SINF 315 A'),

-- TSI302 Programación Orientada a Objetos (B191)
(2, 'JUEVES',   '09:00:00', '10:29:00', 'SINF 315 A'),
(2, 'VIERNES',  '09:00:00', '10:29:00', 'SINF 315 A'),

-- TSI303 Sistemas Operativos (B191)
(3, 'MARTES',   '07:30:00', '08:59:00', '415 A'),
(3, 'MIERCOLES', '07:30:00', '08:59:00', 'SINF 315 A'),

-- TSI304 Planeación de Sistemas Informáticos (D191)
(4, 'LUNES',    '13:30:00', '14:59:00', '202 C'),
(4, 'SABADO',   '13:30:00', '14:59:00', '213 A'),

-- DCB010 Electromagnetismo (A251)
(5, 'MARTES',   '10:30:00', '11:59:00', '407 C'),
(5, 'MIERCOLES', '10:30:00', '11:59:00', '410 C'),

-- DDI009 Inglés I (B193)
(6, 'LUNES',    '10:30:00', '11:59:00', '308 C'),
(6, 'JUEVES',   '07:30:00', '08:59:00', '312 C'),

-- DHI009 PNL - Optativa II (B253)
(7, 'MIERCOLES', '09:00:00', '10:29:00', '411 C');

-- 5.7. Matrículas de Estudiantes Ficticios en el Período 2026-1
INSERT INTO matriculas (id, estudiante_id, grupo_id, fecha_matricula, estado)
VALUES 
-- Andrés Felipe Vargas Rojas (Horario Completo 7 materias)
(1, 4, 1, '2026-02-02 08:00:00', 'MATRICULADA'), -- Motores BD
(2, 4, 2, '2026-02-02 08:05:00', 'MATRICULADA'), -- POO
(3, 4, 3, '2026-02-02 08:10:00', 'MATRICULADA'), -- Sistemas Operativos
(4, 4, 4, '2026-02-02 08:15:00', 'MATRICULADA'), -- Planeación
(5, 4, 5, '2026-02-02 08:20:00', 'MATRICULADA'), -- Electromagnetismo
(6, 4, 6, '2026-02-02 08:25:00', 'MATRICULADA'), -- Inglés I
(7, 4, 7, '2026-02-02 08:30:00', 'MATRICULADA'), -- PNL Optativa II

-- Camila Andrea Pardo Méndez
(8, 5, 1, '2026-02-02 09:00:00', 'MATRICULADA'), -- Motores BD
(9, 5, 2, '2026-02-02 09:05:00', 'MATRICULADA'), -- POO

-- Santiago Gómez Villamizar
(10, 6, 1, '2026-02-02 10:00:00', 'MATRICULADA'); -- Motores BD
SELECT setval('matriculas_id_seq', (SELECT MAX(id) FROM matriculas));

-- 5.8. Calificaciones Iniciales Ficticias
INSERT INTO calificaciones (id, matricula_id, corte1, corte2, corte3, definitiva, fecha_actualizacion)
VALUES 
-- Andrés Felipe Vargas Rojas
(1, 1, 4.10, 3.90, NULL, NULL, CURRENT_TIMESTAMP), -- Motores BD
(2, 2, 4.00, 4.30, NULL, NULL, CURRENT_TIMESTAMP), -- POO
(3, 3, 3.70, 3.80, NULL, NULL, CURRENT_TIMESTAMP), -- Sistemas Operativos
(4, 4, 4.20, 4.00, NULL, NULL, CURRENT_TIMESTAMP), -- Planeación
(5, 5, 3.50, 3.60, NULL, NULL, CURRENT_TIMESTAMP), -- Electromagnetismo
(6, 6, 4.80, 4.50, NULL, NULL, CURRENT_TIMESTAMP), -- Inglés I
(7, 7, 4.40, 4.20, NULL, NULL, CURRENT_TIMESTAMP), -- PNL

-- Camila Andrea Pardo Méndez
(8, 8, 4.50, 4.20, NULL, NULL, CURRENT_TIMESTAMP), -- Motores BD
(9, 9, 4.30, 4.60, NULL, NULL, CURRENT_TIMESTAMP), -- POO

-- Santiago Gómez Villamizar
(10, 10, 3.40, 3.60, NULL, NULL, CURRENT_TIMESTAMP); -- Motores BD
SELECT setval('calificaciones_id_seq', (SELECT MAX(id) FROM calificaciones));

-- 5.9. Asistencias Iniciales Ficticias (Cobertura Completa para Todas las Materias Matriculadas)
INSERT INTO asistencias (matricula_id, fecha, estado, observaciones)
VALUES 
-- Matrícula 1: TSI301 Motores de Bases de Datos (Andrés Felipe)
(1, '2026-02-10', 'PRESENTE',    'Instalación PostgreSQL'),
(1, '2026-02-13', 'PRESENTE',    'Taller DDL y Constraints'),
(1, '2026-02-17', 'JUSTIFICADO', 'Certificación médica'),
(1, '2026-02-20', 'PRESENTE',    'Laboratorio Procedimientos y Triggers'),

-- Matrícula 2: TSI302 Programación Orientada a Objetos (Andrés Felipe)
(2, '2026-02-12', 'PRESENTE',    'Conceptos POO y Clases'),
(2, '2026-02-13', 'PRESENTE',    'Encapsulamiento y Modificadores'),
(2, '2026-02-19', 'PRESENTE',    'Herencia y Polimorfismo Dinámico'),
(2, '2026-02-20', 'PRESENTE',    'Interfaces y Segregación (ISP)'),

-- Matrícula 3: TSI303 Sistemas Operativos (Andrés Felipe)
(3, '2026-02-10', 'PRESENTE',    'Arquitectura del Núcleo y Kernel'),
(3, '2026-02-11', 'PRESENTE',    'Gestión de Procesos y Señales'),
(3, '2026-02-17', 'AUSENTE',     'Inasistencia no justificada'),
(3, '2026-02-18', 'PRESENTE',    'Planificación de CPU y Memoria'),

-- Matrícula 4: TSI304 Planeación de Sistemas Informáticos (Andrés Felipe)
(4, '2026-02-09', 'PRESENTE',    'Ciclo de vida del software'),
(4, '2026-02-14', 'PRESENTE',    'Metodologías ágiles y Scrum'),
(4, '2026-02-16', 'PRESENTE',    'Levantamiento de Historias de Usuario'),
(4, '2026-02-21', 'PRESENTE',    'Planificación del Sprint Backlog'),

-- Matrícula 5: DCB010 Electromagnetismo (Andrés Felipe)
(5, '2026-02-10', 'PRESENTE',    'Campos electrostáticos'),
(5, '2026-02-11', 'PRESENTE',    'Ley de Coulomb y Cargas'),
(5, '2026-02-17', 'JUSTIFICADO', 'Representación deportiva institucional UTS'),
(5, '2026-02-18', 'PRESENTE',    'Potencial y Energía Eléctrica'),

-- Matrícula 6: DDI009 Inglés I (Andrés Felipe)
(6, '2026-02-09', 'PRESENTE',    'Diagnostic test & personal introductions'),
(6, '2026-02-12', 'PRESENTE',    'Technical vocabulary: Hardware & Software'),
(6, '2026-02-16', 'PRESENTE',    'Present simple in tech context'),
(6, '2026-02-19', 'PRESENTE',    'Reading comprehension: Data structures'),

-- Matrícula 7: DHI009 PNL - Optativa II (Andrés Felipe)
(7, '2026-02-11', 'PRESENTE',    'Principios de comunicación asertiva'),
(7, '2026-02-18', 'PRESENTE',    'Modelos de empatía y liderazgo'),
(7, '2026-02-25', 'PRESENTE',    'Negociación en equipos de desarrollo'),

-- Matrícula 8: TSI301 Motores de Bases de Datos (Camila Andrea)
(8, '2026-02-10', 'PRESENTE',    'Puntual'),
(8, '2026-02-13', 'PRESENTE',    'Taller DDL'),
(8, '2026-02-17', 'PRESENTE',    'Normalización'),
(8, '2026-02-20', 'PRESENTE',    'Laboratorio'),

-- Matrícula 9: TSI302 Programación Orientada a Objetos (Camila Andrea)
(9, '2026-02-12', 'PRESENTE',    'Puntual'),
(9, '2026-02-13', 'PRESENTE',    'Taller POO'),
(9, '2026-02-19', 'PRESENTE',    'Laboratorio Polimorfismo'),
(9, '2026-02-20', 'PRESENTE',    'Taller Interfaces'),

-- Matrícula 10: TSI301 Motores de Bases de Datos (Santiago Gómez)
(10, '2026-02-10', 'PRESENTE',   'Puntual'),
(10, '2026-02-13', 'AUSENTE',    'Falla sin excusa'),
(10, '2026-02-17', 'PRESENTE',   'Taller SQL'),
(10, '2026-02-20', 'PRESENTE',   'Laboratorio Triggers');

