package uts.academico;

import uts.academico.ui.LoginFrame;
import uts.academico.util.ConexionBD;

import javax.swing.*;
import java.sql.Connection;

/**
 * Punto de entrada principal de la aplicación Sistema Académico UTS.
 * Proyecto de Aula para Programación Orientada a Objetos y Motores de Bases de Datos.
 */
public class Main {

    public static void main(String[] args) {
        // Configurar Look & Feel moderno
        try {
            for (UIManager.LookAndFeelInfo info : UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (Exception ignored) {
            try {
                UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
            } catch (Exception ignored2) {}
        }

        System.out.println("=================================================================");
        System.out.println("  SISTEMA ACADÉMICO CON CONTROL DE ACCESO BASADO EN ROLES (RBAC)");
        System.out.println("  Unidades Tecnológicas de Santander (UTS) - JDK 17+");
        System.out.println("=================================================================");

        // Comprobación inicial no bloqueante de conexión a PostgreSQL
        new Thread(() -> {
            try {
                Connection conn = ConexionBD.getConexion();
                if (conn != null && !conn.isClosed()) {
                    System.out.println("✔ Conexión JDBC establecida con éxito a PostgreSQL: " + ConexionBD.getBaseDatos());
                }
            } catch (Exception e) {
                System.err.println("⚠ Advertencia de Conexión Inicial JDBC: " + e.getMessage());
                System.err.println("  (Puede configurar el usuario/clave desde la pantalla de login)");
            }
        }).start();

        // Lanzar interfaz gráfica en el Event Dispatch Thread (EDT)
        SwingUtilities.invokeLater(() -> {
            LoginFrame loginFrame = new LoginFrame();
            loginFrame.setVisible(true);
        });
    }
}
