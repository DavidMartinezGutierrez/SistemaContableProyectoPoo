package uts.academico.dao;

import uts.academico.model.*;
import uts.academico.util.ConexionBD;

import java.sql.*;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.util.ArrayList;
import java.util.List;

/**
 * Data Access Object para operaciones académicas.
 * Invoca las Funciones (SELECT fn_...), Procedimientos (CALL sp_...)
 * y captura las excepciones de Triggers y Procedimientos de PostgreSQL.
 */
public class AcademicoDAO {

    // =========================================================================
    // 1. INVOCACIÓN DE FUNCIONES ALMACENADAS DE POSTGRESQL (SELECT fn_...)
    // =========================================================================

    /**
     * Invoca la función PostgreSQL fn_calcular_promedio_estudiante(p_estudiante_id).
     * Retorna el promedio ponderado acumulado del estudiante.
     */
    public double fnCalcularPromedioEstudiante(int estudianteId) throws SQLException {
        String sql = "SELECT fn_calcular_promedio_estudiante(?)";
        Connection conn = null;
        PreparedStatement ps = null;
        ResultSet rs = null;

        try {
            conn = ConexionBD.getConexion();
            ps = conn.prepareStatement(sql);
            ps.setInt(1, estudianteId);
            rs = ps.executeQuery();
            if (rs.next()) {
                return rs.getDouble(1);
            }
            return 0.00;
        } finally {
            ConexionBD.cerrar(ps, rs);
        }
    }

    /**
     * Invoca la función PostgreSQL fn_porcentaje_creditos(p_estudiante_id).
     * Retorna el porcentaje de avance de créditos respecto al total del pensum.
     */
    public double fnPorcentajeCreditos(int estudianteId) throws SQLException {
        String sql = "SELECT fn_porcentaje_creditos(?)";
        Connection conn = null;
        PreparedStatement ps = null;
        ResultSet rs = null;

        try {
            conn = ConexionBD.getConexion();
            ps = conn.prepareStatement(sql);
            ps.setInt(1, estudianteId);
            rs = ps.executeQuery();
            if (rs.next()) {
                return rs.getDouble(1);
            }
            return 0.00;
        } finally {
            ConexionBD.cerrar(ps, rs);
        }
    }

    /**
     * Invoca la función PostgreSQL fn_porcentaje_asistencia(p_estudiante_id, p_asignatura_id).
     * Retorna el porcentaje de asistencia acumulada para una materia.
     */
    public double fnPorcentajeAsistencia(int estudianteId, int asignaturaId) throws SQLException {
        String sql = "SELECT fn_porcentaje_asistencia(?, ?)";
        Connection conn = null;
        PreparedStatement ps = null;
        ResultSet rs = null;

        try {
            conn = ConexionBD.getConexion();
            ps = conn.prepareStatement(sql);
            ps.setInt(1, estudianteId);
            ps.setInt(2, asignaturaId);
            rs = ps.executeQuery();
            if (rs.next()) {
                return rs.getDouble(1);
            }
            return 100.00;
        } finally {
            ConexionBD.cerrar(ps, rs);
        }
    }

    // =========================================================================
    // 2. INVOCACIÓN DE PROCEDIMIENTOS ALMACENADOS (CALL sp_...)
    // =========================================================================

    /**
     * Invoca el procedimiento PostgreSQL sp_registrar_asistencia.
     * CALL sp_registrar_asistencia(p_estudiante_id, p_grupo_id, p_fecha, p_estado, p_observaciones)
     * Dispara automáticamente el Trigger trg_auditoria_asistencias.
     */
    public void spRegistrarAsistencia(int estudianteId, int grupoId, LocalDate fecha, String estado, String observaciones) throws SQLException {
        String sql = "CALL sp_registrar_asistencia(?, ?, ?, ?, ?)";
        Connection conn = null;
        CallableStatement cs = null;

        try {
            conn = ConexionBD.getConexion();
            cs = conn.prepareCall(sql);
            cs.setInt(1, estudianteId);
            cs.setInt(2, grupoId);
            cs.setDate(3, Date.valueOf(fecha));
            cs.setString(4, estado);
            if (observaciones != null && !observaciones.trim().isEmpty()) {
                cs.setString(5, observaciones.trim());
            } else {
                cs.setNull(5, Types.VARCHAR);
            }
            cs.execute();
        } catch (SQLException e) {
            throw new SQLException(extraerMensajePostgres(e), e.getSQLState(), e);
        } finally {
            ConexionBD.cerrar(cs);
        }
    }

    /**
     * Invoca el procedimiento PostgreSQL sp_registrar_o_actualizar_nota.
     * CALL sp_registrar_o_actualizar_nota(p_matricula_id, p_corte1, p_corte2, p_corte3)
     * Dispara el Trigger trg_validar_rango_nota (validando 0.0 - 5.0)
     * y trg_auditoria_calificaciones (registrando en auditoria_academica).
     */
    public void spRegistrarOActualizarNota(int matriculaId, Double corte1, Double corte2, Double corte3) throws SQLException {
        String sql = "CALL sp_registrar_o_actualizar_nota(?, ?, ?, ?)";
        Connection conn = null;
        CallableStatement cs = null;

        try {
            conn = ConexionBD.getConexion();
            cs = conn.prepareCall(sql);
            cs.setInt(1, matriculaId);

            if (corte1 != null) cs.setDouble(2, corte1); else cs.setNull(2, Types.NUMERIC);
            if (corte2 != null) cs.setDouble(3, corte2); else cs.setNull(3, Types.NUMERIC);
            if (corte3 != null) cs.setDouble(4, corte3); else cs.setNull(4, Types.NUMERIC);

            cs.execute();
        } catch (SQLException e) {
            // Captura las excepciones lanzadas por el Trigger trg_validar_rango_nota o SP
            throw new SQLException(extraerMensajePostgres(e), e.getSQLState(), e);
        } finally {
            ConexionBD.cerrar(cs);
        }
    }

    /**
     * Invoca el procedimiento PostgreSQL sp_matricular_estudiante.
     * CALL sp_matricular_estudiante(p_estudiante_id, p_grupo_id)
     */
    public void spMatricularEstudiante(int estudianteId, int grupoId) throws SQLException {
        String sql = "CALL sp_matricular_estudiante(?, ?)";
        Connection conn = null;
        CallableStatement cs = null;

        try {
            conn = ConexionBD.getConexion();
            cs = conn.prepareCall(sql);
            cs.setInt(1, estudianteId);
            cs.setInt(2, grupoId);
            cs.execute();
        } catch (SQLException e) {
            throw new SQLException(extraerMensajePostgres(e), e.getSQLState(), e);
        } finally {
            ConexionBD.cerrar(cs);
        }
    }

    // =========================================================================
    // 3. CONSULTAS SQL PARA VISTAS Y REPORTES DE LA UI
    // =========================================================================

    /**
     * Consulta el horario matriculado por un estudiante o asignado a un docente.
     */
    public List<Horario> listarHorarioPorEstudiante(int estudianteId) throws SQLException {
        List<Horario> lista = new ArrayList<>();
        String sql = "SELECT h.id, h.grupo_id, g.codigo_grupo, a.codigo AS asignatura_codigo, " +
                     "a.nombre AS asignatura_nombre, u.nombre_completo AS docente_nombre, " +
                     "h.dia_semana, h.hora_inicio, h.hora_fin, h.aula " +
                     "FROM matriculas m " +
                     "INNER JOIN grupos g ON m.grupo_id = g.id " +
                     "INNER JOIN asignaturas a ON g.asignatura_id = a.id " +
                     "INNER JOIN usuarios u ON g.docente_id = u.id " +
                     "INNER JOIN horarios h ON h.grupo_id = g.id " +
                     "WHERE m.estudiante_id = ? " +
                     "ORDER BY a.codigo ASC, CASE h.dia_semana " +
                     "  WHEN 'LUNES' THEN 1 WHEN 'MARTES' THEN 2 WHEN 'MIERCOLES' THEN 3 " +
                     "  WHEN 'JUEVES' THEN 4 WHEN 'VIERNES' THEN 5 WHEN 'SABADO' THEN 6 ELSE 7 END, " +
                     "h.hora_inicio ASC";

        Connection conn = null;
        PreparedStatement ps = null;
        ResultSet rs = null;

        try {
            conn = ConexionBD.getConexion();
            ps = conn.prepareStatement(sql);
            ps.setInt(1, estudianteId);
            rs = ps.executeQuery();

            while (rs.next()) {
                lista.add(new Horario(
                    rs.getInt("id"),
                    rs.getInt("grupo_id"),
                    rs.getString("codigo_grupo"),
                    rs.getString("asignatura_codigo"),
                    rs.getString("asignatura_nombre"),
                    rs.getString("docente_nombre"),
                    rs.getString("dia_semana"),
                    rs.getTime("hora_inicio").toLocalTime(),
                    rs.getTime("hora_fin").toLocalTime(),
                    rs.getString("aula")
                ));
            }
        } finally {
            ConexionBD.cerrar(ps, rs);
        }
        return lista;
    }

    /**
     * Consulta de calificaciones filtradas según el rol del usuario:
     * - Si estudianteId != null: solo calificaciones de ese estudiante.
     * - Si docenteId != null: calificaciones de grupos impartidos por ese docente.
     * - Si ambos son null (Administrador): todas las calificaciones registradas.
     */
    public List<Calificacion> listarCalificaciones(Integer estudianteId, Integer docenteId) throws SQLException {
        List<Calificacion> lista = new ArrayList<>();
        StringBuilder sql = new StringBuilder(
            "SELECT c.id, c.matricula_id, m.estudiante_id, u.nombre_completo AS estudiante_nombre, " +
            "a.nombre AS asignatura_nombre, g.codigo_grupo, c.corte1, c.corte2, c.corte3, " +
            "c.definitiva, m.estado AS estado_matricula, c.fecha_actualizacion " +
            "FROM calificaciones c " +
            "INNER JOIN matriculas m ON c.matricula_id = m.id " +
            "INNER JOIN usuarios u ON m.estudiante_id = u.id " +
            "INNER JOIN grupos g ON m.grupo_id = g.id " +
            "INNER JOIN asignaturas a ON g.asignatura_id = a.id " +
            "WHERE 1=1 "
        );

        if (estudianteId != null) {
            sql.append("AND m.estudiante_id = ? ");
        }
        if (docenteId != null) {
            sql.append("AND g.docente_id = ? ");
        }
        sql.append("ORDER BY a.nombre ASC, u.nombre_completo ASC");

        Connection conn = null;
        PreparedStatement ps = null;
        ResultSet rs = null;

        try {
            conn = ConexionBD.getConexion();
            ps = conn.prepareStatement(sql.toString());

            int paramIndex = 1;
            if (estudianteId != null) {
                ps.setInt(paramIndex++, estudianteId);
            }
            if (docenteId != null) {
                ps.setInt(paramIndex++, docenteId);
            }

            rs = ps.executeQuery();
            while (rs.next()) {
                Double c1 = rs.getObject("corte1") != null ? rs.getDouble("corte1") : null;
                Double c2 = rs.getObject("corte2") != null ? rs.getDouble("corte2") : null;
                Double c3 = rs.getObject("corte3") != null ? rs.getDouble("corte3") : null;
                Double def = rs.getObject("definitiva") != null ? rs.getDouble("definitiva") : null;
                Timestamp ts = rs.getTimestamp("fecha_actualizacion");

                lista.add(new Calificacion(
                    rs.getInt("id"),
                    rs.getInt("matricula_id"),
                    rs.getInt("estudiante_id"),
                    rs.getString("estudiante_nombre"),
                    rs.getString("asignatura_nombre"),
                    rs.getString("codigo_grupo"),
                    c1, c2, c3, def,
                    rs.getString("estado_matricula"),
                    ts != null ? ts.toLocalDateTime() : null
                ));
            }
        } finally {
            ConexionBD.cerrar(ps, rs);
        }
        return lista;
    }

    /**
     * Consulta el historial de asistencias (filtrado por estudiante o general).
     */
    public List<Asistencia> listarAsistencias(Integer estudianteId) throws SQLException {
        List<Asistencia> lista = new ArrayList<>();
        StringBuilder sql = new StringBuilder(
            "SELECT asi.id, asi.matricula_id, m.estudiante_id, u.nombre_completo AS estudiante_nombre, " +
            "(a.codigo || ' - ' || a.nombre) AS asignatura_nombre, asi.fecha, asi.estado, asi.observaciones, asi.fecha_registro " +
            "FROM asistencias asi " +
            "INNER JOIN matriculas m ON asi.matricula_id = m.id " +
            "INNER JOIN usuarios u ON m.estudiante_id = u.id " +
            "INNER JOIN grupos g ON m.grupo_id = g.id " +
            "INNER JOIN asignaturas a ON g.asignatura_id = a.id "
        );

        if (estudianteId != null) {
            sql.append("WHERE m.estudiante_id = ? ");
        }
        sql.append("ORDER BY asi.fecha DESC, a.codigo ASC");

        Connection conn = null;
        PreparedStatement ps = null;
        ResultSet rs = null;

        try {
            conn = ConexionBD.getConexion();
            ps = conn.prepareStatement(sql.toString());
            if (estudianteId != null) {
                ps.setInt(1, estudianteId);
            }
            rs = ps.executeQuery();

            while (rs.next()) {
                Timestamp ts = rs.getTimestamp("fecha_registro");
                lista.add(new Asistencia(
                    rs.getInt("id"),
                    rs.getInt("matricula_id"),
                    rs.getInt("estudiante_id"),
                    rs.getString("estudiante_nombre"),
                    rs.getString("asignatura_nombre"),
                    rs.getDate("fecha").toLocalDate(),
                    rs.getString("estado"),
                    rs.getString("observaciones"),
                    ts != null ? ts.toLocalDateTime() : null
                ));
            }
        } finally {
            ConexionBD.cerrar(ps, rs);
        }
        return lista;
    }

    /**
     * Consulta el consolidado de asistencia por cada asignatura matriculada del estudiante
     * calculando sesiones totales, asistidas, fallas, porcentaje e indicador de riesgo (<80%).
     */
    public List<String[]> consultarResumenAsistenciaEstudiante(int estudianteId) throws SQLException {
        List<String[]> resumen = new ArrayList<>();
        String sql = "SELECT a.codigo, a.nombre, g.codigo_grupo, " +
                     "COUNT(asi.id) AS total_sesiones, " +
                     "COUNT(CASE WHEN asi.estado = 'PRESENTE' THEN 1 END) AS presentes, " +
                     "COUNT(CASE WHEN asi.estado = 'JUSTIFICADO' THEN 1 END) AS justificadas, " +
                     "COUNT(CASE WHEN asi.estado = 'AUSENTE' THEN 1 END) AS ausentes, " +
                     "ROUND(COUNT(CASE WHEN asi.estado IN ('PRESENTE', 'JUSTIFICADO') THEN 1 END)::NUMERIC * 100.0 / NULLIF(COUNT(asi.id), 0), 2) AS pct " +
                     "FROM matriculas m " +
                     "INNER JOIN grupos g ON m.grupo_id = g.id " +
                     "INNER JOIN asignaturas a ON g.asignatura_id = a.id " +
                     "LEFT JOIN asistencias asi ON asi.matricula_id = m.id " +
                     "WHERE m.estudiante_id = ? " +
                     "GROUP BY a.codigo, a.nombre, g.codigo_grupo " +
                     "ORDER BY a.codigo ASC";

        Connection conn = null;
        PreparedStatement ps = null;
        ResultSet rs = null;

        try {
            conn = ConexionBD.getConexion();
            ps = conn.prepareStatement(sql);
            ps.setInt(1, estudianteId);
            rs = ps.executeQuery();

            while (rs.next()) {
                String cod = rs.getString("codigo");
                String nom = rs.getString("nombre");
                String grupo = rs.getString("codigo_grupo");
                int tot = rs.getInt("total_sesiones");
                int pres = rs.getInt("presentes");
                int just = rs.getInt("justificadas");
                int aus = rs.getInt("ausentes");
                double pct = rs.getObject("pct") != null ? rs.getDouble("pct") : 100.00;
                String estadoReglamento = pct >= 80.00 ? "Normal" : "En Riesgo (<80%)";

                resumen.add(new String[] {
                    cod + " - " + nom + " (" + grupo + ")",
                    String.valueOf(tot),
                    String.valueOf(pres + just),
                    String.valueOf(aus),
                    String.format("%.1f%%", pct),
                    estadoReglamento
                });
            }
        } finally {
            ConexionBD.cerrar(ps, rs);
        }
        return resumen;
    }

    /**
     * Consulta los registros de auditoría generados automáticamente por los Triggers.
     * Módulo reservado para el Administrador.
     */
    public List<Auditoria> listarAuditoria() throws SQLException {
        List<Auditoria> lista = new ArrayList<>();
        String sql = "SELECT id, tabla_afectada, operacion, registro_id, usuario_db, " +
                     "valores_anteriores, valores_nuevos, fecha_hora " +
                     "FROM auditoria_academica ORDER BY id DESC LIMIT 100";

        Connection conn = null;
        PreparedStatement ps = null;
        ResultSet rs = null;

        try {
            conn = ConexionBD.getConexion();
            ps = conn.prepareStatement(sql);
            rs = ps.executeQuery();

            while (rs.next()) {
                Timestamp ts = rs.getTimestamp("fecha_hora");
                lista.add(new Auditoria(
                    rs.getInt("id"),
                    rs.getString("tabla_afectada"),
                    rs.getString("operacion"),
                    rs.getInt("registro_id"),
                    rs.getString("usuario_db"),
                    rs.getString("valores_anteriores"),
                    rs.getString("valores_nuevos"),
                    ts != null ? ts.toLocalDateTime() : null
                ));
            }
        } finally {
            ConexionBD.cerrar(ps, rs);
        }
        return lista;
    }

    /**
     * Consulta las asignaturas activas de la institución.
     */
    public List<Asignatura> listarAsignaturas() throws SQLException {
        List<Asignatura> lista = new ArrayList<>();
        String sql = "SELECT id, programa_id, codigo, nombre, creditos, semestre, activo " +
                     "FROM asignaturas WHERE activo = TRUE ORDER BY semestre ASC, nombre ASC";

        Connection conn = null;
        PreparedStatement ps = null;
        ResultSet rs = null;

        try {
            conn = ConexionBD.getConexion();
            ps = conn.prepareStatement(sql);
            rs = ps.executeQuery();

            while (rs.next()) {
                lista.add(new Asignatura(
                    rs.getInt("id"),
                    rs.getInt("programa_id"),
                    rs.getString("codigo"),
                    rs.getString("nombre"),
                    rs.getInt("creditos"),
                    rs.getInt("semestre"),
                    rs.getBoolean("activo")
                ));
            }
        } finally {
            ConexionBD.cerrar(ps, rs);
        }
        return lista;
    }

    /**
     * Retorna lista de grupos disponibles para matrícula o gestión.
     */
    public List<String[]> listarGruposDisponibles() throws SQLException {
        List<String[]> lista = new ArrayList<>();
        String sql = "SELECT g.id, g.codigo_grupo, a.nombre AS asignatura, u.nombre_completo AS docente, " +
                     "g.periodo_academico, g.cupo_maximo, " +
                     "(SELECT COUNT(*) FROM matriculas m WHERE m.grupo_id = g.id AND m.estado = 'MATRICULADA') AS inscritos " +
                     "FROM grupos g " +
                     "INNER JOIN asignaturas a ON g.asignatura_id = a.id " +
                     "INNER JOIN usuarios u ON g.docente_id = u.id " +
                     "WHERE g.activo = TRUE ORDER BY a.nombre ASC";

        Connection conn = null;
        PreparedStatement ps = null;
        ResultSet rs = null;

        try {
            conn = ConexionBD.getConexion();
            ps = conn.prepareStatement(sql);
            rs = ps.executeQuery();

            while (rs.next()) {
                lista.add(new String[] {
                    String.valueOf(rs.getInt("id")),
                    rs.getString("codigo_grupo"),
                    rs.getString("asignatura"),
                    rs.getString("docente"),
                    rs.getString("periodo_academico"),
                    rs.getString("cupo_maximo"),
                    rs.getString("inscritos")
                });
            }
        } finally {
            ConexionBD.cerrar(ps, rs);
        }
        return lista;
    }

    /**
     * Extrae de forma limpia el mensaje de negocio emitido por PostgreSQL
     * (elimina el prefijo 'ERROR: ' y los detalles de PL/pgSQL).
     */
    private String extraerMensajePostgres(SQLException e) {
        String msg = e.getMessage();
        if (msg != null) {
            if (msg.contains("ERROR:")) {
                msg = msg.substring(msg.indexOf("ERROR:") + 6);
            }
            if (msg.contains("\n")) {
                msg = msg.substring(0, msg.indexOf("\n"));
            }
            return msg.trim();
        }
        return "Error en motor de base de datos PostgreSQL";
    }
}
