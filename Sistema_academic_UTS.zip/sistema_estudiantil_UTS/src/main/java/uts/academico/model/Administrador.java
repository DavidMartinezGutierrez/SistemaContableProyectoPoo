package uts.academico.model;

import java.time.LocalDateTime;
import java.util.Arrays;
import java.util.List;

/**
 * Subclase concreta que representa al Administrador del sistema.
 * Posee privilegios totales CRUD y consulta de auditoría.
 */
public class Administrador extends Usuario {

    public Administrador(int id, String documento, String nombreCompleto, String correoInstitucional,
                         String passwordHash, boolean activo, LocalDateTime fechaCreacion) {
        super(id, documento, nombreCompleto, correoInstitucional, passwordHash, Rol.ADMIN, activo, fechaCreacion);
    }

    @Override
    public List<String> obtenerPermisos() {
        return Arrays.asList(
            "CRUD_USUARIOS",
            "CRUD_PROGRAMAS",
            "CRUD_ASIGNATURAS",
            "CRUD_HORARIOS",
            "GESTIONAR_MATRICULAS",
            "GESTIONAR_CALIFICACIONES",
            "GESTIONAR_ASISTENCIAS",
            "CONSULTAR_AUDITORIA",
            "RECALCULAR_PROMEDIOS"
        );
    }

    @Override
    public String mostrarDashboard() {
        return "Dashboard Administrador: Panel de Control Maestro, Gestión Académica y Auditoría";
    }
}
