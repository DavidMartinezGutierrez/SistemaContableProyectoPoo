package uts.academico.model;

/**
 * Representa una asignatura académica curricular.
 */
public class Asignatura {

    private int id;
    private int programaId;
    private String codigo;
    private String nombre;
    private int creditos;
    private int semestre;
    private boolean activo;

    public Asignatura() {}

    public Asignatura(int id, int programaId, String codigo, String nombre, int creditos, int semestre, boolean activo) {
        this.id = id;
        this.programaId = programaId;
        this.codigo = codigo;
        this.nombre = nombre;
        this.creditos = creditos;
        this.semestre = semestre;
        this.activo = activo;
    }

    public int getId() { return id; }
    public void setId(int id) { this.id = id; }

    public int getProgramaId() { return programaId; }
    public void setProgramaId(int programaId) { this.programaId = programaId; }

    public String getCodigo() { return codigo; }
    public void setCodigo(String codigo) { this.codigo = codigo; }

    public String getNombre() { return nombre; }
    public void setNombre(String nombre) { this.nombre = nombre; }

    public int getCreditos() { return creditos; }
    public void setCreditos(int creditos) { this.creditos = creditos; }

    public int getSemestre() { return semestre; }
    public void setSemestre(int semestre) { this.semestre = semestre; }

    public boolean isActivo() { return activo; }
    public void setActivo(boolean activo) { this.activo = activo; }

    @Override
    public String toString() {
        return codigo + " - " + nombre + " (" + creditos + " Créditos)";
    }
}
