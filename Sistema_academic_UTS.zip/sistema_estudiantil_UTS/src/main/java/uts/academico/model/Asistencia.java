package uts.academico.model;

import java.time.LocalDate;
import java.time.LocalDateTime;

/**
 * Representa una sesión de asistencia para una matrícula.
 */
public class Asistencia {

    private int id;
    private int matriculaId;
    private int estudianteId;
    private String estudianteNombre;
    private String asignaturaNombre;
    private LocalDate fecha;
    private String estado;
    private String observaciones;
    private LocalDateTime fechaRegistro;

    public Asistencia() {}

    public Asistencia(int id, int matriculaId, int estudianteId, String estudianteNombre,
                      String asignaturaNombre, LocalDate fecha, String estado,
                      String observaciones, LocalDateTime fechaRegistro) {
        this.id = id;
        this.matriculaId = matriculaId;
        this.estudianteId = estudianteId;
        this.estudianteNombre = estudianteNombre;
        this.asignaturaNombre = asignaturaNombre;
        this.fecha = fecha;
        this.estado = estado;
        this.observaciones = observaciones;
        this.fechaRegistro = fechaRegistro;
    }

    public int getId() { return id; }
    public void setId(int id) { this.id = id; }

    public int getMatriculaId() { return matriculaId; }
    public void setMatriculaId(int matriculaId) { this.matriculaId = matriculaId; }

    public int getEstudianteId() { return estudianteId; }
    public void setEstudianteId(int estudianteId) { this.estudianteId = estudianteId; }

    public String getEstudianteNombre() { return estudianteNombre; }
    public void setEstudianteNombre(String estudianteNombre) { this.estudianteNombre = estudianteNombre; }

    public String getAsignaturaNombre() { return asignaturaNombre; }
    public void setAsignaturaNombre(String asignaturaNombre) { this.asignaturaNombre = asignaturaNombre; }

    public LocalDate getFecha() { return fecha; }
    public void setFecha(LocalDate fecha) { this.fecha = fecha; }

    public String getEstado() { return estado; }
    public void setEstado(String estado) { this.estado = estado; }

    public String getObservaciones() { return observaciones; }
    public void setObservaciones(String observaciones) { this.observaciones = observaciones; }

    public LocalDateTime getFechaRegistro() { return fechaRegistro; }
    public void setFechaRegistro(LocalDateTime fechaRegistro) { this.fechaRegistro = fechaRegistro; }
}
