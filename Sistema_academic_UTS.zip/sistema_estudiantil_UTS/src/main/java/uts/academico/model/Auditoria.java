package uts.academico.model;

import java.time.LocalDateTime;

/**
 * Representa un registro de auditoría académica generado por los Triggers de PostgreSQL.
 */
public class Auditoria {

    private int id;
    private String tablaAfectada;
    private String operacion;
    private int registroId;
    private String usuarioDb;
    private String valoresAnteriores;
    private String valoresNuevos;
    private LocalDateTime fechaHora;

    public Auditoria() {}

    public Auditoria(int id, String tablaAfectada, String operacion, int registroId,
                     String usuarioDb, String valoresAnteriores, String valoresNuevos,
                     LocalDateTime fechaHora) {
        this.id = id;
        this.tablaAfectada = tablaAfectada;
        this.operacion = operacion;
        this.registroId = registroId;
        this.usuarioDb = usuarioDb;
        this.valoresAnteriores = valoresAnteriores;
        this.valoresNuevos = valoresNuevos;
        this.fechaHora = fechaHora;
    }

    public int getId() { return id; }
    public void setId(int id) { this.id = id; }

    public String getTablaAfectada() { return tablaAfectada; }
    public void setTablaAfectada(String tablaAfectada) { this.tablaAfectada = tablaAfectada; }

    public String getOperacion() { return operacion; }
    public void setOperacion(String operacion) { this.operacion = operacion; }

    public int getRegistroId() { return registroId; }
    public void setRegistroId(int registroId) { this.registroId = registroId; }

    public String getUsuarioDb() { return usuarioDb; }
    public void setUsuarioDb(String usuarioDb) { this.usuarioDb = usuarioDb; }

    public String getValoresAnteriores() { return valoresAnteriores; }
    public void setValoresAnteriores(String valoresAnteriores) { this.valoresAnteriores = valoresAnteriores; }

    public String getValoresNuevos() { return valoresNuevos; }
    public void setValoresNuevos(String valoresNuevos) { this.valoresNuevos = valoresNuevos; }

    public LocalDateTime getFechaHora() { return fechaHora; }
    public void setFechaHora(LocalDateTime fechaHora) { this.fechaHora = fechaHora; }
}
