package uts.academico.model;

import java.time.LocalDateTime;

/**
 * Representa las calificaciones de un estudiante por cortes en una matrícula.
 */
public class Calificacion {

    private int id;
    private int matriculaId;
    private int estudianteId;
    private String estudianteNombre;
    private String asignaturaNombre;
    private String codigoGrupo;
    private Double corte1;
    private Double corte2;
    private Double corte3;
    private Double definitiva;
    private String estadoMatricula;
    private LocalDateTime fechaActualizacion;

    public Calificacion() {}

    public Calificacion(int id, int matriculaId, int estudianteId, String estudianteNombre,
                        String asignaturaNombre, String codigoGrupo, Double corte1,
                        Double corte2, Double corte3, Double definitiva,
                        String estadoMatricula, LocalDateTime fechaActualizacion) {
        this.id = id;
        this.matriculaId = matriculaId;
        this.estudianteId = estudianteId;
        this.estudianteNombre = estudianteNombre;
        this.asignaturaNombre = asignaturaNombre;
        this.codigoGrupo = codigoGrupo;
        this.corte1 = corte1;
        this.corte2 = corte2;
        this.corte3 = corte3;
        this.definitiva = definitiva;
        this.estadoMatricula = estadoMatricula;
        this.fechaActualizacion = fechaActualizacion;
    }

    public int getId() { return id; }
    public void setId(int id) { this.id = id; }

    public int getMatriculaId() { return matriculaId; }
    public void setMatriculaId(int matriculaId) { this.matriculaId = matriculaId; }

    public int getEstudianteId() { return estudianteId; }
    public void setEstudianteId(int estudianteId) { this.estudianteId = estudianteId; }

    public String getEstudianteNombre() { return estudianteNombre; }
    public void setEstudianteNombre(String estudianteNombre) { this.estudianteNombre = estudianteNombre; }

    public String getAsignaturaNombre() { return asignaturaNombre; }
    public void setAsignaturaNombre(String asignaturaNombre) { this.asignaturaNombre = asignaturaNombre; }

    public String getCodigoGrupo() { return codigoGrupo; }
    public void setCodigoGrupo(String codigoGrupo) { this.codigoGrupo = codigoGrupo; }

    public Double getCorte1() { return corte1; }
    public void setCorte1(Double corte1) { this.corte1 = corte1; }

    public Double getCorte2() { return corte2; }
    public void setCorte2(Double corte2) { this.corte2 = corte2; }

    public Double getCorte3() { return corte3; }
    public void setCorte3(Double corte3) { this.corte3 = corte3; }

    public Double getDefinitiva() { return definitiva; }
    public void setDefinitiva(Double definitiva) { this.definitiva = definitiva; }

    public String getEstadoMatricula() { return estadoMatricula; }
    public void setEstadoMatricula(String estadoMatricula) { this.estadoMatricula = estadoMatricula; }

    public LocalDateTime getFechaActualizacion() { return fechaActualizacion; }
    public void setFechaActualizacion(LocalDateTime fechaActualizacion) { this.fechaActualizacion = fechaActualizacion; }
}
