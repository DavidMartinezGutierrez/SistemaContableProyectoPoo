package uts.academico.model;

import java.time.LocalDateTime;
import java.util.Arrays;
import java.util.List;

/**
 * Subclase concreta que representa a un Docente.
 * Sus permisos de mutación se limitan a notas y asistencias de sus cursos.
 */
public class Docente extends Usuario {

    private String especialidad;

    public Docente(int id, String documento, String nombreCompleto, String correoInstitucional,
                   String passwordHash, boolean activo, LocalDateTime fechaCreacion, String especialidad) {
        super(id, documento, nombreCompleto, correoInstitucional, passwordHash, Rol.DOCENTE, activo, fechaCreacion);
        this.especialidad = especialidad;
    }

    public String getEspecialidad() { return especialidad; }
    public void setEspecialidad(String especialidad) { this.especialidad = especialidad; }

    @Override
    public List<String> obtenerPermisos() {
        return Arrays.asList(
            "GESTIONAR_CALIFICACIONES",
            "GESTIONAR_ASISTENCIAS",
            "CONSULTAR_HORARIO_DOCENTE",
            "CONSULTAR_GRUPOS_ASIGNADOS"
        );
    }

    @Override
    public String mostrarDashboard() {
        return "Dashboard Docente: Registro de Calificaciones por Corte y Control de Asistencia";
    }
}
