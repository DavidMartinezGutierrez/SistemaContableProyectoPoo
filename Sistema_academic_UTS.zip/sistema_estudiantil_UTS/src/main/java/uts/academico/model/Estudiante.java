package uts.academico.model;

import java.time.LocalDateTime;
import java.util.Arrays;
import java.util.List;

/**
 * Subclase concreta que representa a un Estudiante institucional.
 * Almacena el perfil académico detallado y permisos de solo lectura.
 */
public class Estudiante extends Usuario {

    private String jornada;
    private String situacion;
    private String categoria;
    private int creditosAprobados;
    private int creditosTotales;
    private double promedioAcumulado;
    private String programa;
    private String sede;
    private String pensum;

    public Estudiante(int id, String documento, String nombreCompleto, String correoInstitucional,
                      String passwordHash, boolean activo, LocalDateTime fechaCreacion) {
        super(id, documento, nombreCompleto, correoInstitucional, passwordHash, Rol.ESTUDIANTE, activo, fechaCreacion);
    }

    public Estudiante(int id, String documento, String nombreCompleto, String correoInstitucional,
                      String passwordHash, boolean activo, LocalDateTime fechaCreacion,
                      String jornada, String situacion, String categoria, int creditosAprobados,
                      int creditosTotales, double promedioAcumulado, String programa, String sede, String pensum) {
        super(id, documento, nombreCompleto, correoInstitucional, passwordHash, Rol.ESTUDIANTE, activo, fechaCreacion);
        this.jornada = jornada;
        this.situacion = situacion;
        this.categoria = categoria;
        this.creditosAprobados = creditosAprobados;
        this.creditosTotales = creditosTotales > 0 ? creditosTotales : 108;
        this.promedioAcumulado = promedioAcumulado;
        this.programa = programa;
        this.sede = sede;
        this.pensum = pensum;
    }

    public double getPorcentajeAvance() {
        if (creditosTotales <= 0) return 0.0;
        return (creditosAprobados * 100.0) / creditosTotales;
    }

    @Override
    public List<String> obtenerPermisos() {
        return Arrays.asList(
            "CONSULTAR_PERFIL_PROPIO",
            "CONSULTAR_HORARIO_PROPIO",
            "CONSULTAR_NOTAS_PROPIAS",
            "CONSULTAR_ASISTENCIA_PROPIA",
            "RECALCULAR_PROMEDIO_PROPIO"
        );
    }

    @Override
    public String mostrarDashboard() {
        return "Dashboard Estudiante: Consulta de Perfil Académico, Horario, Notas y Asistencias";
    }

    // Getters y Setters
    public String getJornada() { return jornada; }
    public void setJornada(String jornada) { this.jornada = jornada; }

    public String getSituacion() { return situacion; }
    public void setSituacion(String situacion) { this.situacion = situacion; }

    public String getCategoria() { return categoria; }
    public void setCategoria(String categoria) { this.categoria = categoria; }

    public int getCreditosAprobados() { return creditosAprobados; }
    public void setCreditosAprobados(int creditosAprobados) { this.creditosAprobados = creditosAprobados; }

    public int getCreditosTotales() { return creditosTotales; }
    public void setCreditosTotales(int creditosTotales) { this.creditosTotales = creditosTotales; }

    public double getPromedioAcumulado() { return promedioAcumulado; }
    public void setPromedioAcumulado(double promedioAcumulado) { this.promedioAcumulado = promedioAcumulado; }

    public String getPrograma() { return programa; }
    public void setPrograma(String programa) { this.programa = programa; }

    public String getSede() { return sede; }
    public void setSede(String sede) { this.sede = sede; }

    public String getPensum() { return pensum; }
    public void setPensum(String pensum) { this.pensum = pensum; }
}
