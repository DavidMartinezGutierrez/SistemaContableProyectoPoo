package uts.academico.model;

import java.time.LocalTime;
import java.time.format.DateTimeFormatter;

/**
 * Representa la franja horaria y aula de un grupo en la estructura oficial de las UTS.
 */
public class Horario {

    private int id;
    private int grupoId;
    private String codigoGrupo;
    private String asignaturaCodigo;
    private String asignaturaNombre;
    private String docenteNombre;
    private String diaSemana;
    private LocalTime horaInicio;
    private LocalTime horaFin;
    private String aula;

    private static final DateTimeFormatter HORA_FMT = DateTimeFormatter.ofPattern("HH:mm");

    public Horario() {}

    public Horario(int id, int grupoId, String codigoGrupo, String asignaturaCodigo,
                   String asignaturaNombre, String docenteNombre, String diaSemana,
                   LocalTime horaInicio, LocalTime horaFin, String aula) {
        this.id = id;
        this.grupoId = grupoId;
        this.codigoGrupo = codigoGrupo;
        this.asignaturaCodigo = asignaturaCodigo;
        this.asignaturaNombre = asignaturaNombre;
        this.docenteNombre = docenteNombre;
        this.diaSemana = diaSemana;
        this.horaInicio = horaInicio;
        this.horaFin = horaFin;
        this.aula = aula;
    }

    public int getId() { return id; }
    public void setId(int id) { this.id = id; }

    public int getGrupoId() { return grupoId; }
    public void setGrupoId(int grupoId) { this.grupoId = grupoId; }

    public String getCodigoGrupo() { return codigoGrupo; }
    public void setCodigoGrupo(String codigoGrupo) { this.codigoGrupo = codigoGrupo; }

    public String getAsignaturaCodigo() { return asignaturaCodigo; }
    public void setAsignaturaCodigo(String asignaturaCodigo) { this.asignaturaCodigo = asignaturaCodigo; }

    public String getAsignaturaNombre() { return asignaturaNombre; }
    public void setAsignaturaNombre(String asignaturaNombre) { this.asignaturaNombre = asignaturaNombre; }

    public String getDocenteNombre() { return docenteNombre; }
    public void setDocenteNombre(String docenteNombre) { this.docenteNombre = docenteNombre; }

    public String getDiaSemana() { return diaSemana; }
    public void setDiaSemana(String diaSemana) { this.diaSemana = diaSemana; }

    public LocalTime getHoraInicio() { return horaInicio; }
    public void setHoraInicio(LocalTime horaInicio) { this.horaInicio = horaInicio; }

    public LocalTime getHoraFin() { return horaFin; }
    public void setHoraFin(LocalTime horaFin) { this.horaFin = horaFin; }

    public String getAula() { return aula; }
    public void setAula(String aula) { this.aula = aula; }

    /**
     * Retorna la franja horaria en formato real UTS: ej. "09:00-10:29"
     */
    public String getFranjaFormateada() {
        if (horaInicio != null && horaFin != null) {
            return horaInicio.format(HORA_FMT) + "-" + horaFin.format(HORA_FMT);
        }
        return "";
    }

    /**
     * Etiqueta completa para el encabezado de fila en la grilla:
     * ej. "TSI301 - MOTORES DE BASES DE DATOS - Grupo: B191"
     */
    public String getMateriaGrupoEtiqueta() {
        return (asignaturaCodigo != null ? asignaturaCodigo + " - " : "") +
               asignaturaNombre + " (Grupo: " + codigoGrupo + ")";
    }
}
