package uts.academico.model;

/**
 * Enumeración que define los roles del sistema RBAC.
 */
public enum Rol {
    ADMIN("Administrador del Sistema"),
    DOCENTE("Docente"),
    ESTUDIANTE("Estudiante");

    private final String descripcion;

    Rol(String descripcion) {
        this.descripcion = descripcion;
    }

    public String getDescripcion() {
        return descripcion;
    }
}
