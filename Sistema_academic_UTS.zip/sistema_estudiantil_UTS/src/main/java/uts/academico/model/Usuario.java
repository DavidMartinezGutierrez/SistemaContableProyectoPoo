package uts.academico.model;

import java.time.LocalDateTime;
import java.util.List;

/**
 * Clase base abstracta que representa a cualquier usuario de la comunidad académica.
 * Aplica Abstracción, Encapsulamiento y Polimorfismo.
 */
public abstract class Usuario {

    private int id;
    private String documento;
    private String nombreCompleto;
    private String correoInstitucional;
    private String passwordHash;
    private Rol rol;
    private boolean activo;
    private LocalDateTime fechaCreacion;

    public Usuario(int id, String documento, String nombreCompleto, String correoInstitucional, 
                   String passwordHash, Rol rol, boolean activo, LocalDateTime fechaCreacion) {
        this.id = id;
        this.documento = documento;
        this.nombreCompleto = nombreCompleto;
        this.correoInstitucional = correoInstitucional;
        this.passwordHash = passwordHash;
        this.rol = rol;
        this.activo = activo;
        this.fechaCreacion = fechaCreacion != null ? fechaCreacion : LocalDateTime.now();
    }

    // Métodos polimórficos obligatorios para las subclases concretas
    public abstract List<String> obtenerPermisos();
    public abstract String mostrarDashboard();

    // Verificación de permisos RBAC
    public boolean tienePermiso(String permiso) {
        return obtenerPermisos().contains(permiso);
    }

    // Getters y Setters con encapsulamiento
    public int getId() { return id; }
    public void setId(int id) { this.id = id; }

    public String getDocumento() { return documento; }
    public void setDocumento(String documento) { this.documento = documento; }

    public String getNombreCompleto() { return nombreCompleto; }
    public void setNombreCompleto(String nombreCompleto) { this.nombreCompleto = nombreCompleto; }

    public String getCorreoInstitucional() { return correoInstitucional; }
    public void setCorreoInstitucional(String correoInstitucional) {
        if (correoInstitucional != null && correoInstitucional.contains("@")) {
            this.correoInstitucional = correoInstitucional;
        } else {
            throw new IllegalArgumentException("Formato de correo institucional inválido");
        }
    }

    public String getPasswordHash() { return passwordHash; }
    public void setPasswordHash(String passwordHash) { this.passwordHash = passwordHash; }

    public Rol getRol() { return rol; }
    protected void setRol(Rol rol) { this.rol = rol; }

    public boolean isActivo() { return activo; }
    public void setActivo(boolean activo) { this.activo = activo; }

    public LocalDateTime getFechaCreacion() { return fechaCreacion; }

    @Override
    public String toString() {
        return String.format("[%s] %s (%s)", rol, nombreCompleto, correoInstitucional);
    }
}
