package uts.academico.service;

import uts.academico.dao.AcademicoDAO;
import uts.academico.dao.UsuarioDAO;
import uts.academico.model.*;

import java.sql.SQLException;
import java.time.LocalDate;
import java.util.List;

/**
 * Capa de Lógica de Negocio que aplica las reglas de RBAC y orquesta las
 * operaciones sobre la capa DAO hacia PostgreSQL.
 */
public class AcademicoService {

    private final AcademicoDAO academicoDAO;
    private final UsuarioDAO usuarioDAO;
    private final AuthService authService;

    public AcademicoService() {
        this.academicoDAO = new AcademicoDAO();
        this.usuarioDAO = new UsuarioDAO();
        this.authService = AuthService.getInstancia();
    }

    /**
     * Recalcula el promedio acumulado invocando la función PostgreSQL fn_calcular_promedio_estudiante.
     */
    public double recalcularPromedio(int estudianteId) throws SQLException {
        // Estudiante puede recalcular su propio promedio; Administrador puede recalcular cualquiera
        Usuario u = authService.getUsuarioAutenticado();
        if (u instanceof Estudiante && u.getId() != estudianteId) {
            throw new SecurityException("Un estudiante solo puede consultar su propio promedio");
        }
        return academicoDAO.fnCalcularPromedioEstudiante(estudianteId);
    }

    /**
     * Obtiene el porcentaje de avance de créditos invocando la función PostgreSQL fn_porcentaje_creditos.
     */
    public double consultarPorcentajeCreditos(int estudianteId) throws SQLException {
        return academicoDAO.fnPorcentajeCreditos(estudianteId);
    }

    /**
     * Obtiene el porcentaje de asistencia invocando la función PostgreSQL fn_porcentaje_asistencia.
     */
    public double consultarPorcentajeAsistencia(int estudianteId, int asignaturaId) throws SQLException {
        return academicoDAO.fnPorcentajeAsistencia(estudianteId, asignaturaId);
    }

    /**
     * Obtiene el consolidado de asistencia por cada materia matriculada del estudiante.
     */
    public List<String[]> consultarResumenAsistencias(int estudianteId) throws SQLException {
        return academicoDAO.consultarResumenAsistenciaEstudiante(estudianteId);
    }

    /**
     * Registra o actualiza una calificación invocando el procedimiento PostgreSQL sp_registrar_o_actualizar_nota.
     * Valida permisos RBAC (Docente o Administrador).
     */
    public void registrarCalificacion(int matriculaId, Double corte1, Double corte2, Double corte3) throws SQLException {
        authService.validarPermiso("GESTIONAR_CALIFICACIONES");
        academicoDAO.spRegistrarOActualizarNota(matriculaId, corte1, corte2, corte3);
    }

    /**
     * Registra o actualiza una asistencia invocando el procedimiento PostgreSQL sp_registrar_asistencia.
     * Valida permisos RBAC (Docente o Administrador).
     */
    public void registrarAsistencia(int estudianteId, int grupoId, LocalDate fecha, String estado, String observaciones) throws SQLException {
        authService.validarPermiso("GESTIONAR_ASISTENCIAS");
        academicoDAO.spRegistrarAsistencia(estudianteId, grupoId, fecha, estado, observaciones);
    }

    /**
     * Matricula a un estudiante invocando el procedimiento PostgreSQL sp_matricular_estudiante.
     * Valida permisos RBAC (Solo Administrador).
     */
    public void matricularEstudiante(int estudianteId, int grupoId) throws SQLException {
        authService.validarPermiso("GESTIONAR_MATRICULAS");
        academicoDAO.spMatricularEstudiante(estudianteId, grupoId);
    }

    /**
     * Consulta el horario filtrado por el estudiante autenticado o por el que consulte un admin.
     */
    public List<Horario> obtenerHorarioEstudiante(int estudianteId) throws SQLException {
        return academicoDAO.listarHorarioPorEstudiante(estudianteId);
    }

    /**
     * Obtiene calificaciones adaptadas al contexto RBAC del usuario activo.
     */
    public List<Calificacion> obtenerCalificacionesSegunRol() throws SQLException {
        Usuario u = authService.getUsuarioAutenticado();
        if (u == null) return List.of();

        if (u instanceof Estudiante) {
            return academicoDAO.listarCalificaciones(u.getId(), null);
        } else if (u instanceof Docente) {
            return academicoDAO.listarCalificaciones(null, u.getId());
        } else {
            // Admin: ve todas
            return academicoDAO.listarCalificaciones(null, null);
        }
    }

    /**
     * Obtiene asistencias adaptadas al contexto RBAC del usuario activo.
     */
    public List<Asistencia> obtenerAsistenciasSegunRol() throws SQLException {
        Usuario u = authService.getUsuarioAutenticado();
        if (u == null) return List.of();

        if (u instanceof Estudiante) {
            return academicoDAO.listarAsistencias(u.getId());
        } else {
            return academicoDAO.listarAsistencias(null);
        }
    }

    /**
     * Consulta de auditoría exclusiva para Administrador.
     */
    public List<Auditoria> obtenerAuditoria() throws SQLException {
        authService.validarPermiso("CONSULTAR_AUDITORIA");
        return academicoDAO.listarAuditoria();
    }

    public List<Estudiante> listarEstudiantes() throws SQLException {
        return usuarioDAO.listarEstudiantes();
    }

    public List<Asignatura> listarAsignaturas() throws SQLException {
        return academicoDAO.listarAsignaturas();
    }

    public List<String[]> listarGrupos() throws SQLException {
        return academicoDAO.listarGruposDisponibles();
    }

    public void crearUsuario(Usuario u, String pass, int programaId, String jornada) throws SQLException {
        authService.validarPermiso("CRUD_USUARIOS");
        usuarioDAO.crearUsuario(u, pass, programaId, jornada);
    }
}
