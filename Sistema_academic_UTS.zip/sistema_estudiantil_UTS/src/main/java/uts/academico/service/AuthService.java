package uts.academico.service;

import uts.academico.dao.UsuarioDAO;
import uts.academico.model.Usuario;

import java.sql.SQLException;

/**
 * Servicio encargado de la autenticación y gestión del estado de la sesión activa.
 */
public class AuthService {

    private static AuthService instancia;
    private final UsuarioDAO usuarioDAO;
    private Usuario usuarioAutenticado;

    private AuthService() {
        this.usuarioDAO = new UsuarioDAO();
    }

    public static synchronized AuthService getInstancia() {
        if (instancia == null) {
            instancia = new AuthService();
        }
        return instancia;
    }

    /**
     * Inicia sesión validando credenciales contra PostgreSQL.
     * Almacena polimórficamente la instancia de Usuario.
     */
    public Usuario login(String correo, String password) throws SQLException {
        Usuario usuario = usuarioDAO.autenticar(correo, password);
        if (usuario != null) {
            this.usuarioAutenticado = usuario;
        }
        return usuario;
    }

    public void logout() {
        this.usuarioAutenticado = null;
    }

    public Usuario getUsuarioAutenticado() {
        return usuarioAutenticado;
    }

    public boolean estaAutenticado() {
        return usuarioAutenticado != null;
    }

    /**
     * Valida si el usuario actual posee un permiso RBAC específico.
     * Lanza SecurityException si no está autorizado.
     */
    public void validarPermiso(String permiso) {
        if (usuarioAutenticado == null) {
            throw new SecurityException("No hay una sesión activa en el sistema");
        }
        if (!usuarioAutenticado.tienePermiso(permiso)) {
            throw new SecurityException(String.format(
                "Acceso denegado: el rol %s no cuenta con el permiso '%s'",
                usuarioAutenticado.getRol(), permiso
            ));
        }
    }
}
