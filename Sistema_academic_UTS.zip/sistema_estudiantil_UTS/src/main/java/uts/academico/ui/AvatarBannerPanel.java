package uts.academico.ui;

import javax.swing.*;
import java.awt.*;
import java.awt.geom.Area;
import java.awt.geom.Ellipse2D;
import java.awt.geom.RoundRectangle2D;

/**
 * Panel visual que reproduce la cabecera de la captura móvil institucional:
 * - Banner azul superior (#224870)
 * - Fondo oscuro (#121212)
 * - Avatar circular superpuesto con silueta vectorial nítida
 * - Nombre institucional y correo
 */
public class AvatarBannerPanel extends JPanel {

    private String nombre;
    private String correo;
    private static final int AVATAR_SIZE = 110;
    private static final int BANNER_HEIGHT = 100;

    public AvatarBannerPanel(String nombre, String correo) {
        this.nombre = nombre;
        this.correo = correo;
        setPreferredSize(new Dimension(420, 240));
        setBackground(UITheme.COLOR_FONDO_OSCURO);
    }

    public void actualizarDatos(String nombre, String correo) {
        this.nombre = nombre;
        this.correo = correo;
        repaint();
    }

    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        Graphics2D g2 = (Graphics2D) g.create();
        g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);

        int width = getWidth();

        // 1. Banner azul superior
        g2.setColor(UITheme.COLOR_BANNER_AZUL);
        g2.fillRect(0, 0, width, BANNER_HEIGHT);

        // 2. Fondo oscuro inferior
        g2.setColor(UITheme.COLOR_FONDO_OSCURO);
        g2.fillRect(0, BANNER_HEIGHT, width, getHeight() - BANNER_HEIGHT);

        // 3. Avatar circular centrado sobre la frontera del banner
        int avatarX = (width - AVATAR_SIZE) / 2;
        int avatarY = BANNER_HEIGHT - (AVATAR_SIZE / 2);

        // Círculo blanco de fondo
        g2.setColor(new Color(230, 230, 230));
        g2.fillOval(avatarX, avatarY, AVATAR_SIZE, AVATAR_SIZE);

        // Borde blanco sutil
        g2.setColor(Color.WHITE);
        g2.setStroke(new BasicStroke(3f));
        g2.drawOval(avatarX, avatarY, AVATAR_SIZE, AVATAR_SIZE);

        // Dibujar silueta de usuario en gris medio dentro del círculo recortado
        Shape clipAnterior = g2.getClip();
        g2.setClip(new Ellipse2D.Double(avatarX, avatarY, AVATAR_SIZE, AVATAR_SIZE));

        g2.setColor(new Color(175, 175, 175));
        // Cabeza
        int headSize = 42;
        int headX = avatarX + (AVATAR_SIZE - headSize) / 2;
        int headY = avatarY + 18;
        g2.fillOval(headX, headY, headSize, headSize);

        // Hombros / Torso
        int torsoWidth = 74;
        int torsoHeight = 52;
        int torsoX = avatarX + (AVATAR_SIZE - torsoWidth) / 2;
        int torsoY = avatarY + 62;
        g2.fillOval(torsoX, torsoY, torsoWidth, torsoHeight);

        g2.setClip(clipAnterior);

        // 4. Nombre institucional (Blanco, centrado)
        g2.setFont(new Font("Segoe UI", Font.BOLD, 19));
        g2.setColor(UITheme.COLOR_TEXTO_BLANCO);
        FontMetrics fmNom = g2.getFontMetrics();
        int nomY = avatarY + AVATAR_SIZE + 28;
        int nomX = (width - fmNom.stringWidth(nombre)) / 2;
        g2.drawString(nombre, nomX, nomY);

        // 5. Correo institucional (con ícono simulado de sobre)
        g2.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        g2.setColor(new Color(200, 225, 200));
        FontMetrics fmCorreo = g2.getFontMetrics();
        int correoY = nomY + 22;
        String textoCorreo = "✉  " + correo;
        int correoX = (width - fmCorreo.stringWidth(textoCorreo)) / 2;
        g2.drawString(textoCorreo, correoX, correoY);

        g2.dispose();
    }
}
