package uts.academico.ui;

import javax.swing.*;
import java.awt.*;

/**
 * Componente visual que reproduce la barra de avance de créditos de la captura:
 * - Etiqueta superior del porcentaje (ej. "36.1%")
 * - Barra horizontal con bordes redondeados y relleno verde lima (#A3CF5B)
 * - Subtítulo inferior (ej. "Créditos Aprobados 39/108")
 */
public class BarraProgresoCreditos extends JPanel {

    private double porcentaje;
    private int creditosAprobados;
    private int creditosTotales;

    public BarraProgresoCreditos(double porcentaje, int creditosAprobados, int creditosTotales) {
        this.porcentaje = porcentaje;
        this.creditosAprobados = creditosAprobados;
        this.creditosTotales = creditosTotales;
        setPreferredSize(new Dimension(200, 60));
        setBackground(UITheme.COLOR_FONDO_OSCURO);
    }

    public void actualizar(double porcentaje, int creditosAprobados, int creditosTotales) {
        this.porcentaje = porcentaje;
        this.creditosAprobados = creditosAprobados;
        this.creditosTotales = creditosTotales;
        repaint();
    }

    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        Graphics2D g2 = (Graphics2D) g.create();
        g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);

        int w = getWidth();

        // 1. Porcentaje en texto blanco
        g2.setFont(new Font("Segoe UI", Font.BOLD, 15));
        g2.setColor(UITheme.COLOR_TEXTO_BLANCO);
        String txtPct = String.format("%.1f%%", porcentaje);
        FontMetrics fm = g2.getFontMetrics();
        int pctX = (w - fm.stringWidth(txtPct)) / 2;
        g2.drawString(txtPct, pctX, 16);

        // 2. Barra de progreso redondeada
        int barHeight = 12;
        int barY = 22;
        int barWidth = Math.max(120, w - 20);
        int barX = (w - barWidth) / 2;

        // Fondo oscuro de la barra
        g2.setColor(new Color(36, 40, 32));
        g2.fillRoundRect(barX, barY, barWidth, barHeight, 10, 10);
        g2.setColor(new Color(60, 70, 50));
        g2.drawRoundRect(barX, barY, barWidth, barHeight, 10, 10);

        // Relleno en color lima
        double clampPct = Math.min(100.0, Math.max(0.0, porcentaje));
        int fillWidth = (int) Math.round((clampPct / 100.0) * barWidth);
        if (fillWidth > 0) {
            g2.setColor(UITheme.COLOR_LIMA_ACCENT);
            g2.fillRoundRect(barX, barY, fillWidth, barHeight, 10, 10);
        }

        // 3. Subtítulo: Créditos Aprobados
        g2.setFont(UITheme.FONT_METRICA_LABEL);
        g2.setColor(UITheme.COLOR_TEXTO_GRIS);
        String txtCred = String.format("Créditos Aprobados %d/%d", creditosAprobados, creditosTotales);
        FontMetrics fmSub = g2.getFontMetrics();
        int subX = (w - fmSub.stringWidth(txtCred)) / 2;
        g2.drawString(txtCred, subX, 50);

        g2.dispose();
    }
}
