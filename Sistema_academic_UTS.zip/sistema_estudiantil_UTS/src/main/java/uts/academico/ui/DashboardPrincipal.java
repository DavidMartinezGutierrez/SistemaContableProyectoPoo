package uts.academico.ui;

import uts.academico.model.*;
import uts.academico.service.AcademicoService;
import uts.academico.service.AuthService;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.sql.SQLException;
import java.time.LocalDate;
import java.util.LinkedHashMap;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Dashboard Principal del Sistema Académico con navegación RBAC y tema oscuro.
 * Implementa:
 * - Perfil idéntico a la aplicación institucional UTS con datos ficticios.
 * - Grilla semanal de Horario-Materia por días y franjas/salones reales (UTS).
 * - Calificaciones con control de cortes y validación de triggers.
 * - Asistencias y Auditoría de base de datos.
 */
public class DashboardPrincipal extends JFrame {

    private final Usuario usuarioActual;
    private final AcademicoService academicoService;
    private final AuthService authService;

    // Componentes del Módulo Perfil
    private AvatarBannerPanel avatarBanner;
    private JLabel lblJornadaVal, lblSituacionVal, lblCategoriaVal;
    private JLabel lblPromedioVal, lblProgramaVal, lblSedeVal, lblPensumVal;
    private BarraProgresoCreditos barraProgreso;
    private JComboBox<EstudianteItem> cbEstudiantesPerfil;
    private int estudianteSeleccionadoId;

    // Tablas de Módulos
    private JTable tablaHorario, tablaNotas, tablaAsistencias, tablaAuditoria;
    private DefaultTableModel modeloHorario, modeloNotas, modeloAsistencias, modeloAuditoria;

    // Formulario de Calificaciones (Docente / Admin)
    private JTextField txtNotaMatriculaId, txtCorte1, txtCorte2, txtCorte3;

    // Formulario de Asistencia (Docente / Admin)
    private JComboBox<EstudianteItem> cbAsisEstudiante;
    private JComboBox<String> cbAsisGrupo;
    private JComboBox<String> cbAsisEstado;
    private JTextField txtAsisFecha, txtAsisObs;

    // Formulario Matrícula (Admin)
    private JComboBox<EstudianteItem> cbMatEstudiante;
    private JComboBox<String> cbMatGrupo;

    public DashboardPrincipal(Usuario usuario) {
        this.usuarioActual = usuario;
        this.academicoService = new AcademicoService();
        this.authService = AuthService.getInstancia();

        if (usuario instanceof Estudiante) {
            this.estudianteSeleccionadoId = usuario.getId();
        } else {
            this.estudianteSeleccionadoId = 4; // Andrés Felipe Vargas Rojas (ID 4) por defecto
        }

        setTitle("Sistema Académico UTS - " + usuario.getRol().getDescripcion() + ": " + usuario.getNombreCompleto());
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(1080, 750);
        setMinimumSize(new Dimension(940, 640));
        setLocationRelativeTo(null);

        initUI();
        cargarDatosIniciales();
    }

    private void initUI() {
        JPanel rootPanel = new JPanel(new BorderLayout());
        rootPanel.setBackground(UITheme.COLOR_FONDO_OSCURO);

        // =====================================================================
        // 1. BARRA SUPERIOR INSTITUCIONAL (VERDE OSCURO UTS)
        // =====================================================================
        JPanel topBar = new JPanel(new BorderLayout());
        topBar.setBackground(UITheme.COLOR_BARRA_SUPERIOR);
        topBar.setBorder(new EmptyBorder(10, 18, 10, 18));

        JPanel leftTop = new JPanel(new FlowLayout(FlowLayout.LEFT, 10, 0));
        leftTop.setOpaque(false);

        JLabel lblAppTitle = new JLabel("SISTEMA ACADÉMICO UTS  |  " + usuarioActual.getRol().name());
        lblAppTitle.setFont(UITheme.FONT_TITULO_MEDIO);
        lblAppTitle.setForeground(Color.WHITE);

        leftTop.add(lblAppTitle);

        JPanel rightTop = new JPanel(new FlowLayout(FlowLayout.RIGHT, 12, 0));
        rightTop.setOpaque(false);

        JLabel lblUserInfo = new JLabel(usuarioActual.getNombreCompleto());
        lblUserInfo.setFont(UITheme.FONT_TEXTO_BOLD);
        lblUserInfo.setForeground(UITheme.COLOR_LIMA_ACCENT);

        JButton btnLogout = UITheme.crearBoton("Cerrar Sesión", UITheme.COLOR_PELIGRO);
        btnLogout.setFont(UITheme.FONT_METRICA_LABEL);
        btnLogout.addActionListener(e -> cerrarSesion());

        rightTop.add(lblUserInfo);
        rightTop.add(btnLogout);

        topBar.add(leftTop, BorderLayout.WEST);
        topBar.add(rightTop, BorderLayout.EAST);
        rootPanel.add(topBar, BorderLayout.NORTH);

        // =====================================================================
        // 2. PANEL DE PESTAÑAS (MÓDULOS DEL SISTEMA RBAC)
        // =====================================================================
        JTabbedPane tabbedPane = new JTabbedPane();
        tabbedPane.setBackground(UITheme.COLOR_TARJETA);
        tabbedPane.setForeground(UITheme.COLOR_TEXTO_BLANCO);
        tabbedPane.setFont(UITheme.FONT_TEXTO_BOLD);

        // Pestaña 1: Perfil Académico
        tabbedPane.addTab("Perfil Académico", crearPanelPerfilEstudiante());

        // Pestaña 2: Horario de Clases Grilla Semanal UTS
        tabbedPane.addTab("Horario - Materia", crearPanelHorario());

        // Pestaña 3: Calificaciones por Cortes
        tabbedPane.addTab("Calificaciones", crearPanelCalificaciones());

        // Pestaña 4: Control de Asistencia
        tabbedPane.addTab("Asistencias", crearPanelAsistencias());

        // Pestaña 5: Administración y Auditoría (Solo Administrador)
        if (usuarioActual.getRol() == Rol.ADMIN) {
            tabbedPane.addTab("Gestión y Auditoría (Admin)", crearPanelAuditoriaYMatricula());
        }

        rootPanel.add(tabbedPane, BorderLayout.CENTER);
        setContentPane(rootPanel);
    }

    // =========================================================================
    // MÓDULO 1: PERFIL DEL ESTUDIANTE
    // =========================================================================
    private JComponent crearPanelPerfilEstudiante() {
        JPanel scrollContent = new JPanel();
        scrollContent.setLayout(new BoxLayout(scrollContent, BoxLayout.Y_AXIS));
        scrollContent.setBackground(UITheme.COLOR_FONDO_OSCURO);
        scrollContent.setBorder(new EmptyBorder(10, 20, 25, 20));

        // Selector para Docente o Administrador
        if (!(usuarioActual instanceof Estudiante)) {
            JPanel selectorPanel = new JPanel(new FlowLayout(FlowLayout.CENTER, 10, 8));
            selectorPanel.setBackground(UITheme.COLOR_TARJETA);
            selectorPanel.setMaximumSize(new Dimension(800, 48));

            JLabel lblSel = new JLabel("Seleccionar Estudiante a Consultar:");
            lblSel.setFont(UITheme.FONT_TEXTO_BOLD);
            lblSel.setForeground(UITheme.COLOR_LIMA_ACCENT);

            cbEstudiantesPerfil = new JComboBox<>();
            cbEstudiantesPerfil.setPreferredSize(new Dimension(340, 28));
            cbEstudiantesPerfil.addActionListener(e -> {
                EstudianteItem item = (EstudianteItem) cbEstudiantesPerfil.getSelectedItem();
                if (item != null) {
                    estudianteSeleccionadoId = item.id;
                    recargarPerfilEstudiante();
                    cargarHorario();
                }
            });

            selectorPanel.add(lblSel);
            selectorPanel.add(cbEstudiantesPerfil);
            scrollContent.add(selectorPanel);
            scrollContent.add(Box.createVerticalStrut(10));
        }

        // Título "Perfil"
        JPanel titlePanel = new JPanel(new FlowLayout(FlowLayout.CENTER));
        titlePanel.setBackground(UITheme.COLOR_FONDO_OSCURO);
        JLabel lblTituloPerfil = new JLabel("Perfil Académico");
        lblTituloPerfil.setFont(UITheme.FONT_TITULO_GRANDE);
        lblTituloPerfil.setForeground(UITheme.COLOR_TEXTO_BLANCO);
        titlePanel.add(lblTituloPerfil);
        scrollContent.add(titlePanel);

        // Banner Azul con Avatar Circular y Nombre
        String nomInicial = usuarioActual.getNombreCompleto();
        String corInicial = usuarioActual.getCorreoInstitucional();
        avatarBanner = new AvatarBannerPanel(nomInicial, corInicial);
        avatarBanner.setMaximumSize(new Dimension(800, 230));
        avatarBanner.setAlignmentX(Component.CENTER_ALIGNMENT);
        scrollContent.add(avatarBanner);

        scrollContent.add(Box.createVerticalStrut(15));

        // Contenedor de Métricas del Perfil
        JPanel metricasContainer = new JPanel();
        metricasContainer.setLayout(new BoxLayout(metricasContainer, BoxLayout.Y_AXIS));
        metricasContainer.setBackground(UITheme.COLOR_FONDO_OSCURO);
        metricasContainer.setMaximumSize(new Dimension(740, 400));
        metricasContainer.setAlignmentX(Component.CENTER_ALIGNMENT);

        // Fila 1: Tres Columnas (Jornada, Situación, Categoría)
        JPanel fila1 = new JPanel(new GridLayout(1, 3, 15, 0));
        fila1.setOpaque(false);

        lblJornadaVal = new JLabel("DIURNA", SwingConstants.CENTER);
        lblSituacionVal = new JLabel("ACTIVO", SwingConstants.CENTER);
        lblCategoriaVal = new JLabel("ANTIGUO", SwingConstants.CENTER);

        fila1.add(crearCajaDato(lblJornadaVal, "Jornada"));
        fila1.add(crearCajaDato(lblSituacionVal, "Situación"));
        fila1.add(crearCajaDato(lblCategoriaVal, "Categoría"));
        metricasContainer.add(fila1);

        metricasContainer.add(Box.createVerticalStrut(20));

        // Fila 2: Barra de Créditos Aprobados (50.0% 54/108) y Promedio Acumulado (3.84)
        JPanel fila2 = new JPanel(new GridLayout(1, 2, 25, 0));
        fila2.setOpaque(false);

        barraProgreso = new BarraProgresoCreditos(50.0, 54, 108);

        lblPromedioVal = new JLabel("3.84", SwingConstants.CENTER);
        JPanel pPromedio = crearCajaDato(lblPromedioVal, "Promedio Acumulado");

        fila2.add(barraProgreso);
        fila2.add(pPromedio);
        metricasContainer.add(fila2);

        metricasContainer.add(Box.createVerticalStrut(20));

        // Fila 3: Programa Académico
        lblProgramaVal = new JLabel("TECNOLOGIA EN DESARROLLO DE SISTEMAS INFORMATICOS", SwingConstants.CENTER);
        JPanel pPrograma = crearCajaDato(lblProgramaVal, "Programa");
        metricasContainer.add(pPrograma);

        metricasContainer.add(Box.createVerticalStrut(18));

        // Fila 4: Sede y Pensum (2 Columnas)
        JPanel fila4 = new JPanel(new GridLayout(1, 2, 20, 0));
        fila4.setOpaque(false);

        lblSedeVal = new JLabel("SEDE PRINCIPAL", SwingConstants.CENTER);
        lblPensumVal = new JLabel("TSI2019-2", SwingConstants.CENTER);

        fila4.add(crearCajaDato(lblSedeVal, "Sede"));
        fila4.add(crearCajaDato(lblPensumVal, "Pensum"));
        metricasContainer.add(fila4);

        metricasContainer.add(Box.createVerticalStrut(25));

        // Botón Recalcular Promedio y Avance (Invoca funciones PostgreSQL)
        JButton btnRecalcular = UITheme.crearBoton("🔄 Recalcular Promedio y Avance (PostgreSQL)", UITheme.COLOR_BOTON_PRIMARIO);
        btnRecalcular.setAlignmentX(Component.CENTER_ALIGNMENT);
        btnRecalcular.addActionListener(e -> ejecutarRecalculoFuncionesBD());
        metricasContainer.add(btnRecalcular);

        scrollContent.add(metricasContainer);

        JScrollPane scroll = new JScrollPane(scrollContent);
        scroll.setBorder(null);
        scroll.getVerticalScrollBar().setUnitIncrement(16);
        return scroll;
    }

    private JPanel crearCajaDato(JLabel lblValor, String etiqueta) {
        JPanel p = new JPanel();
        p.setLayout(new BoxLayout(p, BoxLayout.Y_AXIS));
        p.setBackground(UITheme.COLOR_FONDO_OSCURO);

        lblValor.setFont(UITheme.FONT_METRICA_VALOR);
        lblValor.setForeground(UITheme.COLOR_TEXTO_BLANCO);
        lblValor.setAlignmentX(Component.CENTER_ALIGNMENT);

        JLabel lblSub = new JLabel(etiqueta, SwingConstants.CENTER);
        lblSub.setFont(UITheme.FONT_METRICA_LABEL);
        lblSub.setForeground(UITheme.COLOR_TEXTO_GRIS);
        lblSub.setAlignmentX(Component.CENTER_ALIGNMENT);

        p.add(lblValor);
        p.add(Box.createVerticalStrut(4));
        p.add(lblSub);
        return p;
    }

    // =========================================================================
    // MÓDULO 2: HORARIO - MATERIA (GRILLA SEMANAL FIEL A LA PLATAFORMA UTS)
    // =========================================================================
    private JComponent crearPanelHorario() {
        JPanel p = new JPanel(new BorderLayout(10, 10));
        p.setBackground(UITheme.COLOR_FONDO_OSCURO);
        p.setBorder(new EmptyBorder(14, 18, 14, 18));

        // Encabezado institucional amarillo/mostaza tipo UTS
        JPanel bannerHorario = new JPanel(new BorderLayout());
        bannerHorario.setBackground(new Color(225, 175, 15)); // Amarillo institucional UTS
        bannerHorario.setBorder(new EmptyBorder(8, 14, 8, 14));

        JLabel lblTituloBanner = new JLabel("Horario - Materia", SwingConstants.CENTER);
        lblTituloBanner.setFont(new Font("Segoe UI", Font.BOLD, 14));
        lblTituloBanner.setForeground(new Color(25, 25, 25));

        JLabel lblLeyenda = new JLabel("RE ::: El grupo no tiene asignado recurso físico      DO ::: Docente Asignado", SwingConstants.CENTER);
        lblLeyenda.setFont(new Font("Segoe UI", Font.PLAIN, 11));
        lblLeyenda.setForeground(new Color(40, 40, 40));

        bannerHorario.add(lblTituloBanner, BorderLayout.NORTH);
        bannerHorario.add(lblLeyenda, BorderLayout.SOUTH);
        p.add(bannerHorario, BorderLayout.NORTH);

        // Tabla en Grilla Semanal: Materia | Lunes | Martes | Miércoles | Jueves | Viernes | Sábado
        String[] cols = {"Materia / Asignatura", "Lunes", "Martes", "Miércoles", "Jueves", "Viernes", "Sábado"};
        modeloHorario = new DefaultTableModel(cols, 0) {
            @Override public boolean isCellEditable(int r, int c) { return false; }
        };

        tablaHorario = new JTable(modeloHorario);
        UITheme.estilizarTabla(tablaHorario);
        tablaHorario.setRowHeight(58);

        // Ancho de columna de materia más amplio
        tablaHorario.getColumnModel().getColumn(0).setPreferredWidth(280);
        for (int i = 1; i <= 6; i++) {
            tablaHorario.getColumnModel().getColumn(i).setPreferredWidth(110);
        }

        // Renderizador para la columna 0: Materia / Asignatura -> ALINEADO A LA IZQUIERDA con sangría
        DefaultTableCellRenderer materiaRenderer = new DefaultTableCellRenderer();
        materiaRenderer.setHorizontalAlignment(JLabel.LEFT);
        materiaRenderer.setBackground(UITheme.COLOR_TARJETA);
        materiaRenderer.setForeground(UITheme.COLOR_TEXTO_BLANCO);
        materiaRenderer.setBorder(BorderFactory.createEmptyBorder(6, 14, 6, 8));
        tablaHorario.getColumnModel().getColumn(0).setCellRenderer(materiaRenderer);

        // Renderizador para las columnas de Días (1 a 6) -> CENTRADO
        DefaultTableCellRenderer dayRenderer = new DefaultTableCellRenderer();
        dayRenderer.setHorizontalAlignment(JLabel.CENTER);
        dayRenderer.setBackground(UITheme.COLOR_TARJETA);
        dayRenderer.setForeground(UITheme.COLOR_TEXTO_BLANCO);
        for (int i = 1; i <= 6; i++) {
            tablaHorario.getColumnModel().getColumn(i).setCellRenderer(dayRenderer);
        }

        JScrollPane scroll = new JScrollPane(tablaHorario);
        scroll.getViewport().setBackground(UITheme.COLOR_TARJETA);
        p.add(scroll, BorderLayout.CENTER);

        // Barra inferior con botón actualizar
        JPanel bottomBar = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        bottomBar.setOpaque(false);
        JButton btnRefrescar = UITheme.crearBoton("Actualizar Horario", UITheme.COLOR_BANNER_AZUL);
        btnRefrescar.addActionListener(e -> cargarHorario());
        bottomBar.add(btnRefrescar);
        p.add(bottomBar, BorderLayout.SOUTH);

        return p;
    }

    // =========================================================================
    // MÓDULO 3: CALIFICACIONES POR CORTES
    // =========================================================================
    private JComponent crearPanelCalificaciones() {
        JPanel p = new JPanel(new BorderLayout(12, 12));
        p.setBackground(UITheme.COLOR_FONDO_OSCURO);
        p.setBorder(new EmptyBorder(18, 20, 18, 20));

        JPanel headerPanel = new JPanel(new FlowLayout(FlowLayout.LEFT, 10, 0));
        headerPanel.setOpaque(false);
        JLabel lbl = new JLabel("Registro Oficial de Calificaciones (30% - 30% - 40%):");
        lbl.setFont(UITheme.FONT_TITULO_MEDIO);
        lbl.setForeground(UITheme.COLOR_TEXTO_BLANCO);

        JButton btnRefrescar = UITheme.crearBoton("Actualizar Notas", UITheme.COLOR_BANNER_AZUL);
        btnRefrescar.addActionListener(e -> cargarCalificaciones());

        headerPanel.add(lbl);
        headerPanel.add(btnRefrescar);
        p.add(headerPanel, BorderLayout.NORTH);

        String[] cols = {"ID Matrícula", "Estudiante", "Asignatura", "Grupo", "Corte 1 (30%)", "Corte 2 (30%)", "Corte 3 (40%)", "Definitiva", "Estado"};
        modeloNotas = new DefaultTableModel(cols, 0) {
            @Override public boolean isCellEditable(int r, int c) { return false; }
        };
        tablaNotas = new JTable(modeloNotas);
        UITheme.estilizarTabla(tablaNotas);

        tablaNotas.getSelectionModel().addListSelectionListener(e -> {
            int row = tablaNotas.getSelectedRow();
            if (row >= 0 && txtNotaMatriculaId != null) {
                txtNotaMatriculaId.setText(tablaNotas.getValueAt(row, 0).toString());
                Object c1 = tablaNotas.getValueAt(row, 4);
                Object c2 = tablaNotas.getValueAt(row, 5);
                Object c3 = tablaNotas.getValueAt(row, 6);
                txtCorte1.setText(c1 != null && !c1.equals("Pendiente") ? c1.toString() : "");
                txtCorte2.setText(c2 != null && !c2.equals("Pendiente") ? c2.toString() : "");
                txtCorte3.setText(c3 != null && !c3.equals("Pendiente") ? c3.toString() : "");
            }
        });

        JScrollPane scroll = new JScrollPane(tablaNotas);
        scroll.getViewport().setBackground(UITheme.COLOR_TARJETA);
        p.add(scroll, BorderLayout.CENTER);

        // Formulario de Edición (Docente y Admin)
        if (usuarioActual.getRol() == Rol.DOCENTE || usuarioActual.getRol() == Rol.ADMIN) {
            JPanel formPanel = new JPanel(new FlowLayout(FlowLayout.LEFT, 10, 10));
            formPanel.setBackground(UITheme.COLOR_TARJETA);
            formPanel.setBorder(BorderFactory.createTitledBorder(
                BorderFactory.createLineBorder(UITheme.COLOR_BORDE),
                "Editor de Notas (CALL sp_registrar_o_actualizar_nota)",
                0, 0, UITheme.FONT_TEXTO_BOLD, UITheme.COLOR_LIMA_ACCENT
            ));

            formPanel.add(new JLabel("ID Matrícula:"));
            txtNotaMatriculaId = UITheme.crearTextField();
            txtNotaMatriculaId.setPreferredSize(new Dimension(60, 28));
            formPanel.add(txtNotaMatriculaId);

            formPanel.add(new JLabel("Corte 1:"));
            txtCorte1 = UITheme.crearTextField();
            txtCorte1.setPreferredSize(new Dimension(50, 28));
            formPanel.add(txtCorte1);

            formPanel.add(new JLabel("Corte 2:"));
            txtCorte2 = UITheme.crearTextField();
            txtCorte2.setPreferredSize(new Dimension(50, 28));
            formPanel.add(txtCorte2);

            formPanel.add(new JLabel("Corte 3:"));
            txtCorte3 = UITheme.crearTextField();
            txtCorte3.setPreferredSize(new Dimension(50, 28));
            formPanel.add(txtCorte3);

            JButton btnGuardarNota = UITheme.crearBoton("💾 Guardar/Editar Nota", UITheme.COLOR_BOTON_PRIMARIO);
            btnGuardarNota.addActionListener(e -> ejecutarGuardarNota());
            formPanel.add(btnGuardarNota);

            p.add(formPanel, BorderLayout.SOUTH);
        }

        return p;
    }

    // =========================================================================
    // MÓDULO 4: ASISTENCIA
    // =========================================================================
    private JComponent crearPanelAsistencias() {
        JPanel p = new JPanel(new BorderLayout(12, 12));
        p.setBackground(UITheme.COLOR_FONDO_OSCURO);
        p.setBorder(new EmptyBorder(18, 20, 18, 20));

        JPanel top = new JPanel(new FlowLayout(FlowLayout.LEFT, 10, 0));
        top.setOpaque(false);
        JLabel lbl = new JLabel("Historial y Control de Asistencia:");
        lbl.setFont(UITheme.FONT_TITULO_MEDIO);
        lbl.setForeground(UITheme.COLOR_TEXTO_BLANCO);

        JButton btnRefrescar = UITheme.crearBoton("Actualizar Asistencias", UITheme.COLOR_BANNER_AZUL);
        btnRefrescar.addActionListener(e -> cargarAsistencias());

        top.add(lbl);
        top.add(btnRefrescar);

        if (usuarioActual instanceof Estudiante) {
            JButton btnConsultarPct = UITheme.crearBoton("Consolidado de Asistencia por Materia", UITheme.COLOR_BOTON_PRIMARIO);
            btnConsultarPct.addActionListener(e -> mostrarConsolidadoAsistencias());
            top.add(btnConsultarPct);
        }

        p.add(top, BorderLayout.NORTH);

        String[] cols = {"ID", "Estudiante", "Asignatura", "Fecha", "Estado", "Observaciones"};
        modeloAsistencias = new DefaultTableModel(cols, 0) {
            @Override public boolean isCellEditable(int r, int c) { return false; }
        };
        tablaAsistencias = new JTable(modeloAsistencias);
        UITheme.estilizarTabla(tablaAsistencias);
        tablaAsistencias.setRowHeight(30);

        // Anchos y alineaciones
        tablaAsistencias.getColumnModel().getColumn(0).setPreferredWidth(45);
        tablaAsistencias.getColumnModel().getColumn(1).setPreferredWidth(180);
        tablaAsistencias.getColumnModel().getColumn(2).setPreferredWidth(260);
        tablaAsistencias.getColumnModel().getColumn(3).setPreferredWidth(95);
        tablaAsistencias.getColumnModel().getColumn(4).setPreferredWidth(110);
        tablaAsistencias.getColumnModel().getColumn(5).setPreferredWidth(250);

        // Renderizador para Asignatura (Izquierda con margen)
        DefaultTableCellRenderer asigLeftRenderer = new DefaultTableCellRenderer();
        asigLeftRenderer.setHorizontalAlignment(JLabel.LEFT);
        asigLeftRenderer.setBackground(UITheme.COLOR_TARJETA);
        asigLeftRenderer.setForeground(UITheme.COLOR_TEXTO_BLANCO);
        asigLeftRenderer.setBorder(BorderFactory.createEmptyBorder(0, 10, 0, 0));
        tablaAsistencias.getColumnModel().getColumn(2).setCellRenderer(asigLeftRenderer);

        // Renderizador con color distintivo para Estado (PRESENTE, JUSTIFICADO, AUSENTE)
        DefaultTableCellRenderer estadoAsisRenderer = new DefaultTableCellRenderer() {
            @Override
            public Component getTableCellRendererComponent(JTable table, Object value, boolean isSelected, boolean hasFocus, int row, int column) {
                Component c = super.getTableCellRendererComponent(table, value, isSelected, hasFocus, row, column);
                setHorizontalAlignment(JLabel.CENTER);
                String val = value != null ? value.toString() : "";
                if ("PRESENTE".equalsIgnoreCase(val)) {
                    setForeground(new Color(163, 207, 91)); // Verde lima
                    setFont(UITheme.FONT_TEXTO_BOLD);
                } else if ("JUSTIFICADO".equalsIgnoreCase(val)) {
                    setForeground(new Color(100, 181, 246)); // Azul cielo
                    setFont(UITheme.FONT_TEXTO_BOLD);
                } else if ("AUSENTE".equalsIgnoreCase(val)) {
                    setForeground(new Color(255, 110, 110)); // Rojo alerta
                    setFont(UITheme.FONT_TEXTO_BOLD);
                } else {
                    setForeground(UITheme.COLOR_TEXTO_BLANCO);
                }
                return c;
            }
        };
        tablaAsistencias.getColumnModel().getColumn(4).setCellRenderer(estadoAsisRenderer);

        JScrollPane scroll = new JScrollPane(tablaAsistencias);
        scroll.getViewport().setBackground(UITheme.COLOR_TARJETA);
        p.add(scroll, BorderLayout.CENTER);

        // Formulario Registro Asistencia (Docente y Admin)
        if (usuarioActual.getRol() == Rol.DOCENTE || usuarioActual.getRol() == Rol.ADMIN) {
            JPanel formPanel = new JPanel(new FlowLayout(FlowLayout.LEFT, 10, 8));
            formPanel.setBackground(UITheme.COLOR_TARJETA);
            formPanel.setBorder(BorderFactory.createTitledBorder(
                BorderFactory.createLineBorder(UITheme.COLOR_BORDE),
                "Tomar Asistencia (CALL sp_registrar_asistencia)",
                0, 0, UITheme.FONT_TEXTO_BOLD, UITheme.COLOR_LIMA_ACCENT
            ));

            cbAsisEstudiante = new JComboBox<>();
            cbAsisEstudiante.setPreferredSize(new Dimension(190, 28));

            cbAsisGrupo = new JComboBox<>(new String[] {
                "1 - TSI301 Motores BD (B191)",
                "2 - TSI302 POO (B191)",
                "3 - TSI303 Sistemas Operativos (B191)",
                "4 - TSI304 Planeación (D191)",
                "5 - DCB010 Electromagnetismo (A251)",
                "6 - DDI009 Inglés I (B193)",
                "7 - DHI009 PNL Optativa II (B253)"
            });
            cbAsisGrupo.setPreferredSize(new Dimension(230, 28));

            txtAsisFecha = UITheme.crearTextField();
            txtAsisFecha.setText(LocalDate.now().toString());
            txtAsisFecha.setPreferredSize(new Dimension(90, 28));

            cbAsisEstado = new JComboBox<>(new String[] {"PRESENTE", "AUSENTE", "JUSTIFICADO"});
            cbAsisEstado.setPreferredSize(new Dimension(110, 28));

            txtAsisObs = UITheme.crearTextField();
            txtAsisObs.setPreferredSize(new Dimension(120, 28));
            txtAsisObs.setText("Clase regular");

            JButton btnGuardarAsis = UITheme.crearBoton("Registrar", UITheme.COLOR_BOTON_PRIMARIO);
            btnGuardarAsis.addActionListener(e -> ejecutarRegistrarAsistencia());

            formPanel.add(new JLabel("Estudiante:")); formPanel.add(cbAsisEstudiante);
            formPanel.add(new JLabel("Grupo:")); formPanel.add(cbAsisGrupo);
            formPanel.add(new JLabel("Fecha:")); formPanel.add(txtAsisFecha);
            formPanel.add(new JLabel("Estado:")); formPanel.add(cbAsisEstado);
            formPanel.add(new JLabel("Obs:")); formPanel.add(txtAsisObs);
            formPanel.add(btnGuardarAsis);

            p.add(formPanel, BorderLayout.SOUTH);
        }

        return p;
    }

    // =========================================================================
    // MÓDULO 5: GESTIÓN DE MATRÍCULAS Y BITÁCORA DE TRIGGERS (ADMIN)
    // =========================================================================
    private JComponent crearPanelAuditoriaYMatricula() {
        JPanel p = new JPanel(new BorderLayout(12, 12));
        p.setBackground(UITheme.COLOR_FONDO_OSCURO);
        p.setBorder(new EmptyBorder(18, 20, 18, 20));

        JPanel pMatricula = new JPanel(new FlowLayout(FlowLayout.LEFT, 12, 8));
        pMatricula.setBackground(UITheme.COLOR_TARJETA);
        pMatricula.setBorder(BorderFactory.createTitledBorder(
            BorderFactory.createLineBorder(UITheme.COLOR_BORDE),
            "Matricular Estudiante (CALL sp_matricular_estudiante)",
            0, 0, UITheme.FONT_TEXTO_BOLD, UITheme.COLOR_LIMA_ACCENT
        ));

        cbMatEstudiante = new JComboBox<>();
        cbMatEstudiante.setPreferredSize(new Dimension(220, 28));

        cbMatGrupo = new JComboBox<>(new String[] {
            "1 - TSI301 Motores BD (B191)",
            "2 - TSI302 POO (B191)",
            "3 - TSI303 Sistemas Operativos (B191)",
            "4 - TSI304 Planeación (D191)",
            "5 - DCB010 Electromagnetismo (A251)",
            "6 - DDI009 Inglés I (B193)",
            "7 - DHI009 PNL Optativa II (B253)",
            "8 - TSI305 Estructura de Datos (B191)"
        });
        cbMatGrupo.setPreferredSize(new Dimension(250, 28));

        JButton btnEjecutarMatricula = UITheme.crearBoton("Matricular Estudiante", UITheme.COLOR_BOTON_PRIMARIO);
        btnEjecutarMatricula.addActionListener(e -> ejecutarMatricula());

        pMatricula.add(new JLabel("Estudiante:")); pMatricula.add(cbMatEstudiante);
        pMatricula.add(new JLabel("Grupo a Inscribir:")); pMatricula.add(cbMatGrupo);
        pMatricula.add(btnEjecutarMatricula);

        p.add(pMatricula, BorderLayout.NORTH);

        JPanel pAuditTable = new JPanel(new BorderLayout(6, 6));
        pAuditTable.setOpaque(false);

        JPanel pAuditHeader = new JPanel(new FlowLayout(FlowLayout.LEFT, 10, 0));
        pAuditHeader.setOpaque(false);
        JLabel lblAuditTitle = new JLabel("Bitácora de Auditoría en Tiempo Real (Triggers PostgreSQL):");
        lblAuditTitle.setFont(UITheme.FONT_TEXTO_BOLD);
        lblAuditTitle.setForeground(UITheme.COLOR_TEXTO_BLANCO);

        JButton btnRefrescarAudit = UITheme.crearBoton("Refrescar Bitácora", UITheme.COLOR_BANNER_AZUL);
        btnRefrescarAudit.addActionListener(e -> cargarAuditoria());

        pAuditHeader.add(lblAuditTitle);
        pAuditHeader.add(btnRefrescarAudit);
        pAuditTable.add(pAuditHeader, BorderLayout.NORTH);

        String[] cols = {"ID", "Tabla Afectada", "Operación", "Reg ID", "Usuario DB", "Fecha / Hora", "Valores Nuevos (JSONB)"};
        modeloAuditoria = new DefaultTableModel(cols, 0) {
            @Override public boolean isCellEditable(int r, int c) { return false; }
        };
        tablaAuditoria = new JTable(modeloAuditoria);
        UITheme.estilizarTabla(tablaAuditoria);

        JScrollPane scroll = new JScrollPane(tablaAuditoria);
        scroll.getViewport().setBackground(UITheme.COLOR_TARJETA);
        pAuditTable.add(scroll, BorderLayout.CENTER);

        p.add(pAuditTable, BorderLayout.CENTER);
        return p;
    }

    // =========================================================================
    // ACCIONES DE NEGOCIO Y LLAMADAS A PROCEDIMIENTOS / FUNCIONES / TRIGGERS
    // =========================================================================

    /**
     * Muestra el resumen consolidado de asistencia por cada una de las materias
     * matriculadas por el estudiante con validación del 80% reglamentario UTS.
     */
    private void mostrarConsolidadoAsistencias() {
        try {
            List<String[]> resumen = academicoService.consultarResumenAsistencias(estudianteSeleccionadoId);
            if (resumen.isEmpty()) {
                JOptionPane.showMessageDialog(this, "No hay asignaturas o asistencias registradas para este estudiante.", "Información", JOptionPane.INFORMATION_MESSAGE);
                return;
            }

            String[] cols = {"Asignatura / Grupo", "Sesiones", "Asistidas", "Fallas", "% Asistencia", "Estado Reglamento UTS"};
            DefaultTableModel mod = new DefaultTableModel(cols, 0) {
                @Override public boolean isCellEditable(int r, int c) { return false; }
            };

            for (String[] fila : resumen) {
                mod.addRow(fila);
            }

            JTable tablaResumen = new JTable(mod);
            UITheme.estilizarTabla(tablaResumen);
            tablaResumen.setRowHeight(32);
            tablaResumen.getColumnModel().getColumn(0).setPreferredWidth(270);
            tablaResumen.getColumnModel().getColumn(1).setPreferredWidth(65);
            tablaResumen.getColumnModel().getColumn(2).setPreferredWidth(65);
            tablaResumen.getColumnModel().getColumn(3).setPreferredWidth(60);
            tablaResumen.getColumnModel().getColumn(4).setPreferredWidth(90);
            tablaResumen.getColumnModel().getColumn(5).setPreferredWidth(140);

            // Renderizador con color distintivo para el Estado
            DefaultTableCellRenderer estadoRenderer = new DefaultTableCellRenderer() {
                @Override
                public Component getTableCellRendererComponent(JTable table, Object value, boolean isSelected, boolean hasFocus, int row, int column) {
                    Component c = super.getTableCellRendererComponent(table, value, isSelected, hasFocus, row, column);
                    setHorizontalAlignment(JLabel.CENTER);
                    String val = value != null ? value.toString() : "";
                    if (val.contains("Riesgo")) {
                        setForeground(new Color(255, 110, 110)); // Rojo alerta
                        setFont(UITheme.FONT_TEXTO_BOLD);
                    } else {
                        setForeground(UITheme.COLOR_LIMA_ACCENT); // Verde normal
                        setFont(UITheme.FONT_TEXTO_BOLD);
                    }
                    return c;
                }
            };
            tablaResumen.getColumnModel().getColumn(5).setCellRenderer(estadoRenderer);

            JScrollPane sp = new JScrollPane(tablaResumen);
            sp.setPreferredSize(new Dimension(740, 260));

            JPanel dlgPanel = new JPanel(new BorderLayout(10, 10));
            dlgPanel.setBackground(UITheme.COLOR_FONDO_OSCURO);

            JLabel lblInfoReglamento = new JLabel("<html><b>Reglamento Estudiantil UTS:</b> Mínimo 80.0% de asistencia efectiva para aprobar la asignatura.</html>");
            lblInfoReglamento.setFont(UITheme.FONT_METRICA_LABEL);
            lblInfoReglamento.setForeground(UITheme.COLOR_TEXTO_GRIS);
            lblInfoReglamento.setBorder(new EmptyBorder(6, 4, 6, 4));

            dlgPanel.add(lblInfoReglamento, BorderLayout.NORTH);
            dlgPanel.add(sp, BorderLayout.CENTER);

            JOptionPane.showMessageDialog(this, dlgPanel, "Consolidado Oficial de Asistencias - UTS", JOptionPane.PLAIN_MESSAGE);
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(this, "Error al calcular el consolidado de asistencia: " + ex.getMessage(), "Error BD", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void ejecutarRecalculoFuncionesBD() {
        try {
            double nuevoPromedio = academicoService.recalcularPromedio(estudianteSeleccionadoId);
            double nuevoPctCreditos = academicoService.consultarPorcentajeCreditos(estudianteSeleccionadoId);

            lblPromedioVal.setText(String.format("%.2f", nuevoPromedio));
            barraProgreso.actualizar(nuevoPctCreditos, 54, 108);

            JOptionPane.showMessageDialog(this,
                String.format("Resultados obtenidos desde PostgreSQL:\n\n" +
                              "• fn_calcular_promedio_estudiante(%d) = %.2f\n" +
                              "• fn_porcentaje_creditos(%d) = %.2f%%",
                              estudianteSeleccionadoId, nuevoPromedio,
                              estudianteSeleccionadoId, nuevoPctCreditos),
                "Funciones PostgreSQL Ejecutadas con Éxito", JOptionPane.INFORMATION_MESSAGE);
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(this, "Error al invocar funciones: " + ex.getMessage(), "Error PostgreSQL", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void ejecutarGuardarNota() {
        try {
            String matStr = txtNotaMatriculaId.getText().trim();
            if (matStr.isEmpty()) {
                JOptionPane.showMessageDialog(this, "Seleccione una matrícula en la tabla.", "Validación", JOptionPane.WARNING_MESSAGE);
                return;
            }
            int matriculaId = Integer.parseInt(matStr);

            Double c1 = parseDoubleNullable(txtCorte1.getText().trim());
            Double c2 = parseDoubleNullable(txtCorte2.getText().trim());
            Double c3 = parseDoubleNullable(txtCorte3.getText().trim());

            academicoService.registrarCalificacion(matriculaId, c1, c2, c3);

            JOptionPane.showMessageDialog(this,
                "Calificación registrada exitosamente con CALL sp_registrar_o_actualizar_nota.\n" +
                "El Trigger trg_auditoria_calificaciones registró la operación en auditoría.",
                "Transacción Exitosa", JOptionPane.INFORMATION_MESSAGE);

            cargarCalificaciones();
            if (modeloAuditoria != null) cargarAuditoria();
            recargarPerfilEstudiante();
        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(this, "Formato numérico inválido en las calificaciones (use formato ej. 4.5).", "Error de Formato", JOptionPane.ERROR_MESSAGE);
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(this,
                "Excepción capturada del Motor de Base de Datos PostgreSQL:\n\n" + ex.getMessage(),
                "Validación de Trigger / Procedimiento Almacenado", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void ejecutarRegistrarAsistencia() {
        try {
            EstudianteItem estItem = (EstudianteItem) cbAsisEstudiante.getSelectedItem();
            if (estItem == null) return;

            String grupoStr = (String) cbAsisGrupo.getSelectedItem();
            int grupoId = Integer.parseInt(grupoStr.substring(0, grupoStr.indexOf(" -")));

            LocalDate fecha = LocalDate.parse(txtAsisFecha.getText().trim());
            String estado = (String) cbAsisEstado.getSelectedItem();
            String obs = txtAsisObs.getText().trim();

            academicoService.registrarAsistencia(estItem.id, grupoId, fecha, estado, obs);

            JOptionPane.showMessageDialog(this,
                "Asistencia registrada con CALL sp_registrar_asistencia.\n" +
                "El Trigger trg_auditoria_asistencias insertó la trazabilidad.",
                "Éxito", JOptionPane.INFORMATION_MESSAGE);

            cargarAsistencias();
            if (modeloAuditoria != null) cargarAuditoria();
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(this, "Fallo al registrar asistencia: " + ex.getMessage(), "Error BD", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void ejecutarMatricula() {
        try {
            EstudianteItem estItem = (EstudianteItem) cbMatEstudiante.getSelectedItem();
            if (estItem == null) return;

            String grupoStr = (String) cbMatGrupo.getSelectedItem();
            int grupoId = Integer.parseInt(grupoStr.substring(0, grupoStr.indexOf(" -")));

            academicoService.matricularEstudiante(estItem.id, grupoId);

            JOptionPane.showMessageDialog(this,
                "Estudiante matriculado con éxito mediante CALL sp_matricular_estudiante.",
                "Matrícula Confirmada", JOptionPane.INFORMATION_MESSAGE);

            cargarHorario();
            cargarCalificaciones();
            if (modeloAuditoria != null) cargarAuditoria();
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(this, "Validación de Matrícula PostgreSQL:\n" + ex.getMessage(), "Control Académico", JOptionPane.WARNING_MESSAGE);
        }
    }

    // =========================================================================
    // MÉTODOS DE CARGA DE DATOS DESDE POSTGRESQL
    // =========================================================================
    private void cargarDatosIniciales() {
        cargarEstudiantesEnCombos();
        recargarPerfilEstudiante();
        cargarHorario();
        cargarCalificaciones();
        cargarAsistencias();
        if (usuarioActual.getRol() == Rol.ADMIN) {
            cargarAuditoria();
        }
    }

    private void cargarEstudiantesEnCombos() {
        try {
            List<Estudiante> estudiantes = academicoService.listarEstudiantes();
            if (cbEstudiantesPerfil != null) cbEstudiantesPerfil.removeAllItems();
            if (cbAsisEstudiante != null) cbAsisEstudiante.removeAllItems();
            if (cbMatEstudiante != null) cbMatEstudiante.removeAllItems();

            for (Estudiante e : estudiantes) {
                EstudianteItem item = new EstudianteItem(e.getId(), e.getNombreCompleto(), e.getCorreoInstitucional());
                if (cbEstudiantesPerfil != null) cbEstudiantesPerfil.addItem(item);
                if (cbAsisEstudiante != null) cbAsisEstudiante.addItem(item);
                if (cbMatEstudiante != null) cbMatEstudiante.addItem(item);
            }
        } catch (SQLException e) {
            System.err.println("Error al cargar lista de estudiantes: " + e.getMessage());
        }
    }

    private void recargarPerfilEstudiante() {
        try {
            List<Estudiante> lista = academicoService.listarEstudiantes();
            Estudiante est = null;
            for (Estudiante e : lista) {
                if (e.getId() == estudianteSeleccionadoId) {
                    est = e;
                    break;
                }
            }

            if (est != null) {
                avatarBanner.actualizarDatos(est.getNombreCompleto(), est.getCorreoInstitucional());
                lblJornadaVal.setText(est.getJornada() != null ? est.getJornada() : "DIURNA");
                lblSituacionVal.setText(est.getSituacion() != null ? est.getSituacion() : "ACTIVO");
                lblCategoriaVal.setText(est.getCategoria() != null ? est.getCategoria() : "ANTIGUO");
                lblPromedioVal.setText(String.format("%.2f", est.getPromedioAcumulado()));
                lblProgramaVal.setText(est.getPrograma() != null ? est.getPrograma() : "TECNOLOGIA EN DESARROLLO DE SISTEMAS INFORMATICOS");
                lblSedeVal.setText(est.getSede() != null ? est.getSede() : "SEDE PRINCIPAL");
                lblPensumVal.setText(est.getPensum() != null ? est.getPensum() : "TSI2019-2");

                barraProgreso.actualizar(est.getPorcentajeAvance(), est.getCreditosAprobados(), est.getCreditosTotales());
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
    }

    /**
     * Construye la grilla semanal agrupada por materia, idéntica a la plataforma institucional UTS.
     */
    private void cargarHorario() {
        try {
            modeloHorario.setRowCount(0);
            List<Horario> horarios = academicoService.obtenerHorarioEstudiante(estudianteSeleccionadoId);

            // Agrupar horarios por materia y código de grupo
            Map<String, Map<String, String>> mapaHorarios = new LinkedHashMap<>();

            for (Horario h : horarios) {
                String claveMateria = String.format("<html><div style='text-align:left; padding-left:4px;'>" +
                    "<b style='font-size:12px; color:#A3CF5B;'>%s</b><br>" +
                    "<span style='color:#FFFFFF; font-weight:600;'>%s</span><br>" +
                    "<span style='color:#88C0D0; font-size:10px;'>Grupo: %s</span>" +
                    "</div></html>",
                    h.getAsignaturaCodigo() != null ? h.getAsignaturaCodigo() : "TSI",
                    h.getAsignaturaNombre(),
                    h.getCodigoGrupo());

                mapaHorarios.putIfAbsent(claveMateria, new HashMap<>());

                String dia = h.getDiaSemana() != null ? h.getDiaSemana().toUpperCase() : "";
                String celdaInfo = String.format("<html><center><b>%s</b><br><font color='#A3CF5B'>%s</font><br><font color='#888888'>DO</font></center></html>",
                    h.getFranjaFormateada(),
                    h.getAula());

                String existente = mapaHorarios.get(claveMateria).get(dia);
                if (existente != null && !existente.equals("-")) {
                    celdaInfo = existente + "<br>" + celdaInfo;
                }
                mapaHorarios.get(claveMateria).put(dia, celdaInfo);
            }

            for (Map.Entry<String, Map<String, String>> entry : mapaHorarios.entrySet()) {
                String materia = entry.getKey();
                Map<String, String> dias = entry.getValue();

                modeloHorario.addRow(new Object[] {
                    materia,
                    dias.getOrDefault("LUNES", "-"),
                    dias.getOrDefault("MARTES", "-"),
                    dias.getOrDefault("MIERCOLES", "-"),
                    dias.getOrDefault("JUEVES", "-"),
                    dias.getOrDefault("VIERNES", "-"),
                    dias.getOrDefault("SABADO", "-")
                });
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private void cargarCalificaciones() {
        try {
            modeloNotas.setRowCount(0);
            List<Calificacion> califs = academicoService.obtenerCalificacionesSegunRol();
            for (Calificacion c : califs) {
                modeloNotas.addRow(new Object[] {
                    c.getMatriculaId(),
                    c.getEstudianteNombre(),
                    c.getAsignaturaNombre(),
                    c.getCodigoGrupo(),
                    c.getCorte1() != null ? String.format("%.2f", c.getCorte1()) : "Pendiente",
                    c.getCorte2() != null ? String.format("%.2f", c.getCorte2()) : "Pendiente",
                    c.getCorte3() != null ? String.format("%.2f", c.getCorte3()) : "Pendiente",
                    c.getDefinitiva() != null ? String.format("%.2f", c.getDefinitiva()) : "En Curso",
                    c.getEstadoMatricula()
                });
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private void cargarAsistencias() {
        try {
            modeloAsistencias.setRowCount(0);
            List<Asistencia> asistencias = academicoService.obtenerAsistenciasSegunRol();
            for (Asistencia a : asistencias) {
                modeloAsistencias.addRow(new Object[] {
                    a.getId(),
                    a.getEstudianteNombre(),
                    a.getAsignaturaNombre(),
                    a.getFecha(),
                    a.getEstado(),
                    a.getObservaciones()
                });
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private void cargarAuditoria() {
        try {
            modeloAuditoria.setRowCount(0);
            List<Auditoria> list = academicoService.obtenerAuditoria();
            for (Auditoria a : list) {
                modeloAuditoria.addRow(new Object[] {
                    a.getId(),
                    a.getTablaAfectada(),
                    a.getOperacion(),
                    a.getRegistroId(),
                    a.getUsuarioDb(),
                    a.getFechaHora(),
                    a.getValoresNuevos() != null ? a.getValoresNuevos() : "DELETE"
                });
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private void cerrarSesion() {
        authService.logout();
        new LoginFrame().setVisible(true);
        dispose();
    }

    private Double parseDoubleNullable(String s) {
        if (s == null || s.trim().isEmpty()) return null;
        return Double.parseDouble(s.replace(',', '.'));
    }

    private static class EstudianteItem {
        final int id;
        final String nombre;
        final String correo;

        EstudianteItem(int id, String nombre, String correo) {
            this.id = id;
            this.nombre = nombre;
            this.correo = correo;
        }

        @Override
        public String toString() {
            return nombre + " (" + correo + ")";
        }
    }
}
