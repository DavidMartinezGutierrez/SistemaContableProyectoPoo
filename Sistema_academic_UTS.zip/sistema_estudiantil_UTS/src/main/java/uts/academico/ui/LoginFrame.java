package uts.academico.ui;

import uts.academico.model.Rol;
import uts.academico.model.Usuario;
import uts.academico.service.AuthService;
import uts.academico.util.ConexionBD;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;
import java.sql.SQLException;

/**
 * Ventana de inicio de sesión segura:
 * - Campos de correo y contraseña limpios por defecto (sin autocompletado).
 * - Selector visual de rol que solo indica el rol esperado sin rellenar credenciales.
 * - Conexión JDBC directa y autenticación contra PostgreSQL.
 */
public class LoginFrame extends JFrame {

    private JTextField txtCorreo;
    private JPasswordField txtPassword;
    private JButton btnLogin;
    private JLabel lblEstado;
    private JLabel lblRolIndicador;
    private Rol rolSeleccionado = Rol.ESTUDIANTE; // Por defecto estudiante

    private JButton btnRolAdmin;
    private JButton btnRolDocente;
    private JButton btnRolEstudiante;

    public LoginFrame() {
        setTitle("Acceso Institucional - Sistema Académico UTS");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(460, 580);
        setLocationRelativeTo(null);
        setResizable(false);
        initUI();
    }

    private void initUI() {
        JPanel mainPanel = new JPanel(new BorderLayout());
        mainPanel.setBackground(UITheme.COLOR_FONDO_OSCURO);

        // 1. Barra Superior Verde Oscura Institucional
        JPanel headerPanel = new JPanel(new FlowLayout(FlowLayout.CENTER, 10, 16));
        headerPanel.setBackground(UITheme.COLOR_BARRA_SUPERIOR);

        JLabel lblTitulo = new JLabel("UNIDADES TECNOLÓGICAS DE SANTANDER");
        lblTitulo.setFont(new Font("Segoe UI", Font.BOLD, 15));
        lblTitulo.setForeground(Color.WHITE);
        headerPanel.add(lblTitulo);

        mainPanel.add(headerPanel, BorderLayout.NORTH);

        // 2. Formulario Central
        JPanel formContainer = new JPanel();
        formContainer.setLayout(new BoxLayout(formContainer, BoxLayout.Y_AXIS));
        formContainer.setBackground(UITheme.COLOR_FONDO_OSCURO);
        formContainer.setBorder(new EmptyBorder(20, 40, 20, 40));

        // Subtítulo
        JLabel lblSub = new JLabel("Portal de Gestión Académica (RBAC)");
        lblSub.setFont(UITheme.FONT_TITULO_MEDIO);
        lblSub.setForeground(UITheme.COLOR_LIMA_ACCENT);
        lblSub.setAlignmentX(Component.CENTER_ALIGNMENT);
        formContainer.add(lblSub);

        formContainer.add(Box.createVerticalStrut(15));

        // Selector Visual de Rol (Sin autocompletar credenciales)
        JLabel lblSelecRol = new JLabel("Seleccione el Perfil de Acceso:");
        lblSelecRol.setFont(UITheme.FONT_METRICA_LABEL);
        lblSelecRol.setForeground(UITheme.COLOR_TEXTO_GRIS);
        lblSelecRol.setAlignmentX(Component.CENTER_ALIGNMENT);
        formContainer.add(lblSelecRol);

        formContainer.add(Box.createVerticalStrut(8));

        JPanel rolPanel = new JPanel(new GridLayout(1, 3, 8, 0));
        rolPanel.setBackground(UITheme.COLOR_FONDO_OSCURO);
        rolPanel.setMaximumSize(new Dimension(Integer.MAX_VALUE, 36));

        btnRolAdmin = UITheme.crearBoton("Admin", new Color(35, 45, 60));
        btnRolDocente = UITheme.crearBoton("Docente", new Color(35, 45, 60));
        btnRolEstudiante = UITheme.crearBoton("Estudiante", UITheme.COLOR_BOTON_PRIMARIO); // Inicialmente activo

        btnRolAdmin.setFont(UITheme.FONT_METRICA_LABEL);
        btnRolDocente.setFont(UITheme.FONT_METRICA_LABEL);
        btnRolEstudiante.setFont(UITheme.FONT_METRICA_LABEL);

        btnRolAdmin.addActionListener(e -> seleccionarRol(Rol.ADMIN, btnRolAdmin));
        btnRolDocente.addActionListener(e -> seleccionarRol(Rol.DOCENTE, btnRolDocente));
        btnRolEstudiante.addActionListener(e -> seleccionarRol(Rol.ESTUDIANTE, btnRolEstudiante));

        rolPanel.add(btnRolAdmin);
        rolPanel.add(btnRolDocente);
        rolPanel.add(btnRolEstudiante);
        formContainer.add(rolPanel);

        formContainer.add(Box.createVerticalStrut(10));

        // Indicador visual de rol activo
        lblRolIndicador = new JLabel("Iniciando como: Estudiante", SwingConstants.CENTER);
        lblRolIndicador.setFont(UITheme.FONT_METRICA_LABEL);
        lblRolIndicador.setForeground(UITheme.COLOR_LIMA_ACCENT);
        lblRolIndicador.setAlignmentX(Component.CENTER_ALIGNMENT);
        formContainer.add(lblRolIndicador);

        formContainer.add(Box.createVerticalStrut(18));

        // Campo Correo Institucional (Totalmente Vacío para que el usuario digite)
        JLabel lblCorreo = new JLabel("Correo Institucional:");
        lblCorreo.setFont(UITheme.FONT_TEXTO_BOLD);
        lblCorreo.setForeground(UITheme.COLOR_TEXTO_BLANCO);
        lblCorreo.setAlignmentX(Component.LEFT_ALIGNMENT);
        formContainer.add(lblCorreo);

        formContainer.add(Box.createVerticalStrut(6));

        txtCorreo = UITheme.crearTextField();
        txtCorreo.setText(""); // Vacío por seguridad
        txtCorreo.setToolTipText("Ejemplo: afvargasrojas@uts.edu.co");
        txtCorreo.setMaximumSize(new Dimension(Integer.MAX_VALUE, 36));
        txtCorreo.setAlignmentX(Component.LEFT_ALIGNMENT);
        formContainer.add(txtCorreo);

        formContainer.add(Box.createVerticalStrut(14));

        // Campo Contraseña (Totalmente Vacío)
        JLabel lblPass = new JLabel("Contraseña:");
        lblPass.setFont(UITheme.FONT_TEXTO_BOLD);
        lblPass.setForeground(UITheme.COLOR_TEXTO_BLANCO);
        lblPass.setAlignmentX(Component.LEFT_ALIGNMENT);
        formContainer.add(lblPass);

        formContainer.add(Box.createVerticalStrut(6));

        txtPassword = UITheme.crearPasswordField();
        txtPassword.setText(""); // Vacío por seguridad
        txtPassword.setMaximumSize(new Dimension(Integer.MAX_VALUE, 36));
        txtPassword.setAlignmentX(Component.LEFT_ALIGNMENT);
        formContainer.add(txtPassword);

        formContainer.add(Box.createVerticalStrut(20));

        // Botón Iniciar Sesión
        btnLogin = UITheme.crearBoton("INICIAR SESIÓN", UITheme.COLOR_BOTON_PRIMARIO);
        btnLogin.setMaximumSize(new Dimension(Integer.MAX_VALUE, 40));
        btnLogin.setAlignmentX(Component.LEFT_ALIGNMENT);
        btnLogin.addActionListener(e -> ejecutarLogin());
        formContainer.add(btnLogin);

        formContainer.add(Box.createVerticalStrut(12));

        // Estado / Mensaje
        lblEstado = new JLabel("Ingrese sus credenciales registradas en PostgreSQL");
        lblEstado.setFont(UITheme.FONT_METRICA_LABEL);
        lblEstado.setForeground(UITheme.COLOR_TEXTO_GRIS);
        lblEstado.setAlignmentX(Component.CENTER_ALIGNMENT);
        formContainer.add(lblEstado);

        formContainer.add(Box.createVerticalStrut(15));

        // Botón Configuración de Conexión a Base de Datos
        JButton btnConfigBD = new JButton("⚙ Configurar Conexión PostgreSQL...");
        btnConfigBD.setFont(UITheme.FONT_METRICA_LABEL);
        btnConfigBD.setForeground(UITheme.COLOR_LIMA_ACCENT);
        btnConfigBD.setBackground(UITheme.COLOR_FONDO_OSCURO);
        btnConfigBD.setBorder(null);
        btnConfigBD.setCursor(new Cursor(Cursor.HAND_CURSOR));
        btnConfigBD.setAlignmentX(Component.CENTER_ALIGNMENT);
        btnConfigBD.addActionListener(e -> mostrarDialogoConfigBD());
        formContainer.add(btnConfigBD);

        mainPanel.add(formContainer, BorderLayout.CENTER);

        getRootPane().setDefaultButton(btnLogin);
        setContentPane(mainPanel);
    }

    /**
     * Marca visualmente el rol seleccionado sin alterar ni rellenar los campos de texto.
     */
    private void seleccionarRol(Rol rol, JButton botonActivo) {
        this.rolSeleccionado = rol;
        lblRolIndicador.setText("Iniciando como: " + rol.getDescripcion());

        Color inactivo = new Color(35, 45, 60);
        btnRolAdmin.setBackground(inactivo);
        btnRolDocente.setBackground(inactivo);
        btnRolEstudiante.setBackground(inactivo);

        botonActivo.setBackground(UITheme.COLOR_BOTON_PRIMARIO);
    }

    private void ejecutarLogin() {
        String correo = txtCorreo.getText().trim();
        String pass = new String(txtPassword.getPassword());

        if (correo.isEmpty() || pass.isEmpty()) {
            JOptionPane.showMessageDialog(this, 
                "Por favor ingrese tanto el correo institucional como la contraseña.", 
                "Credenciales Requeridas", JOptionPane.WARNING_MESSAGE);
            return;
        }

        lblEstado.setText("Verificando credenciales en PostgreSQL...");
        lblEstado.setForeground(UITheme.COLOR_LIMA_ACCENT);

        SwingUtilities.invokeLater(() -> {
            try {
                Usuario usuario = AuthService.getInstancia().login(correo, pass);
                if (usuario != null) {
                    // Validar si el usuario autenticado coincide con el rol seleccionado
                    if (usuario.getRol() != rolSeleccionado) {
                        int respuesta = JOptionPane.showConfirmDialog(this,
                            String.format("El usuario autenticado posee rol de '%s', pero seleccionó '%s'.\n¿Desea ingresar con su rol asignado en la base de datos?",
                                          usuario.getRol().getDescripcion(), rolSeleccionado.getDescripcion()),
                            "Confirmación de Rol", JOptionPane.YES_NO_OPTION, JOptionPane.QUESTION_MESSAGE);

                        if (respuesta != JOptionPane.YES_OPTION) {
                            lblEstado.setText("Inicio de sesión cancelado.");
                            lblEstado.setForeground(UITheme.COLOR_TEXTO_GRIS);
                            return;
                        }
                    }

                    // Acceso concedido
                    DashboardPrincipal dashboard = new DashboardPrincipal(usuario);
                    dashboard.setVisible(true);
                    dispose();
                } else {
                    lblEstado.setText("Credenciales incorrectas o usuario inactivo.");
                    lblEstado.setForeground(new Color(255, 100, 100));
                    JOptionPane.showMessageDialog(this,
                        "El correo o la contraseña ingresados no coinciden en PostgreSQL.",
                        "Fallo de Autenticación", JOptionPane.ERROR_MESSAGE);
                }
            } catch (SQLException ex) {
                lblEstado.setText("Error al conectar con PostgreSQL.");
                lblEstado.setForeground(new Color(255, 100, 100));
                JOptionPane.showMessageDialog(this,
                    "No se pudo conectar a PostgreSQL:\n" + ex.getMessage() +
                    "\n\nRevise que el servicio de PostgreSQL esté iniciado y la BD 'uts_sistema_academico' exista.",
                    "Error de Conexión JDBC", JOptionPane.ERROR_MESSAGE);
            }
        });
    }

    private void mostrarDialogoConfigBD() {
        JPanel p = new JPanel(new GridLayout(5, 2, 8, 8));
        JTextField tfHost = new JTextField("localhost");
        JTextField tfPort = new JTextField("5432");
        JTextField tfDB = new JTextField(ConexionBD.getBaseDatos());
        JTextField tfUser = new JTextField(ConexionBD.getUsuario());
        JPasswordField tfPass = new JPasswordField("admin");

        p.add(new JLabel("Host:")); p.add(tfHost);
        p.add(new JLabel("Puerto:")); p.add(tfPort);
        p.add(new JLabel("Base de Datos:")); p.add(tfDB);
        p.add(new JLabel("Usuario PG:")); p.add(tfUser);
        p.add(new JLabel("Contraseña PG:")); p.add(tfPass);

        int opt = JOptionPane.showConfirmDialog(this, p, "Configurar Credenciales PostgreSQL", JOptionPane.OK_CANCEL_OPTION);
        if (opt == JOptionPane.OK_OPTION) {
            ConexionBD.configurar(
                tfHost.getText().trim(),
                tfPort.getText().trim(),
                tfDB.getText().trim(),
                tfUser.getText().trim(),
                new String(tfPass.getPassword())
            );
            lblEstado.setText("Configuración JDBC actualizada.");
            lblEstado.setForeground(UITheme.COLOR_LIMA_ACCENT);
        }
    }
}
