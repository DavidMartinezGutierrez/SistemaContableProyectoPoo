package uts.academico.ui;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.JTableHeader;
import java.awt.*;

/**
 * Paleta de colores, tipografía y estilos visuales modernos
 * inspirados en la interfaz oscura institucional de las UTS.
 */
public class UITheme {

    // Paleta de Colores
    public static final Color COLOR_BARRA_SUPERIOR = new Color(12, 56, 35);    // Verde Oscuro Institucional UTS (#0C3823)
    public static final Color COLOR_BANNER_AZUL    = new Color(34, 75, 115);   // Azul Acero de la Cabecera (#224B73)
    public static final Color COLOR_FONDO_OSCURO   = new Color(18, 18, 18);    // Fondo Principal (#121212)
    public static final Color COLOR_TARJETA        = new Color(28, 28, 28);    // Superficie de Tarjetas (#1C1C1C)
    public static final Color COLOR_BORDE          = new Color(45, 45, 45);    // Bordes sutiles (#2D2D2D)
    public static final Color COLOR_LIMA_ACCENT    = new Color(163, 207, 91);  // Verde Lima para Avance (#A3CF5B)
    public static final Color COLOR_TEXTO_BLANCO   = new Color(245, 245, 245); // Blanco principal
    public static final Color COLOR_TEXTO_GRIS     = new Color(160, 160, 160); // Gris etiquetas
    public static final Color COLOR_BOTON_PRIMARIO = new Color(16, 92, 50);    // Botón verde acción
    public static final Color COLOR_BOTON_HOVER    = new Color(24, 120, 68);
    public static final Color COLOR_PELIGRO        = new Color(180, 40, 40);

    // Tipografías
    public static final Font FONT_TITULO_GRANDE = new Font("Segoe UI", Font.BOLD, 22);
    public static final Font FONT_TITULO_MEDIO  = new Font("Segoe UI", Font.BOLD, 16);
    public static final Font FONT_METRICA_VALOR = new Font("Segoe UI", Font.BOLD, 18);
    public static final Font FONT_METRICA_LABEL = new Font("Segoe UI", Font.PLAIN, 12);
    public static final Font FONT_TEXTO_REGULAR = new Font("Segoe UI", Font.PLAIN, 13);
    public static final Font FONT_TEXTO_BOLD    = new Font("Segoe UI", Font.BOLD, 13);

    /**
     * Aplica estilo moderno a un botón Swing.
     */
    public static JButton crearBoton(String texto, Color colorFondo) {
        JButton btn = new JButton(texto);
        btn.setFont(FONT_TEXTO_BOLD);
        btn.setForeground(Color.WHITE);
        btn.setBackground(colorFondo != null ? colorFondo : COLOR_BOTON_PRIMARIO);
        btn.setFocusPainted(false);
        btn.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(btn.getBackground().darker(), 1),
            BorderFactory.createEmptyBorder(8, 16, 8, 16)
        ));
        btn.setCursor(new Cursor(Cursor.HAND_CURSOR));
        return btn;
    }

    /**
     * Aplica estilo moderno a un campo de texto en tema oscuro.
     */
    public static JTextField crearTextField() {
        JTextField tf = new JTextField();
        tf.setFont(FONT_TEXTO_REGULAR);
        tf.setForeground(COLOR_TEXTO_BLANCO);
        tf.setBackground(new Color(32, 32, 32));
        tf.setCaretColor(COLOR_LIMA_ACCENT);
        tf.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(COLOR_BORDE, 1),
            BorderFactory.createEmptyBorder(6, 10, 6, 10)
        ));
        return tf;
    }

    /**
     * Aplica estilo moderno a un campo de contraseña.
     */
    public static JPasswordField crearPasswordField() {
        JPasswordField pf = new JPasswordField();
        pf.setFont(FONT_TEXTO_REGULAR);
        pf.setForeground(COLOR_TEXTO_BLANCO);
        pf.setBackground(new Color(32, 32, 32));
        pf.setCaretColor(COLOR_LIMA_ACCENT);
        pf.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(COLOR_BORDE, 1),
            BorderFactory.createEmptyBorder(6, 10, 6, 10)
        ));
        return pf;
    }

    /**
     * Estiliza una tabla JTable para que coincida con el tema oscuro profesional.
     */
    public static void estilizarTabla(JTable tabla) {
        tabla.setFont(FONT_TEXTO_REGULAR);
        tabla.setBackground(COLOR_TARJETA);
        tabla.setForeground(COLOR_TEXTO_BLANCO);
        tabla.setRowHeight(28);
        tabla.setGridColor(COLOR_BORDE);
        tabla.setSelectionBackground(new Color(30, 65, 95));
        tabla.setSelectionForeground(Color.WHITE);

        JTableHeader header = tabla.getTableHeader();
        header.setFont(FONT_TEXTO_BOLD);
        header.setBackground(new Color(24, 24, 24));
        header.setForeground(COLOR_LIMA_ACCENT);
        header.setBorder(BorderFactory.createMatteBorder(0, 0, 1, 0, COLOR_BORDE));
        header.setPreferredSize(new Dimension(header.getWidth(), 32));

        DefaultTableCellRenderer centerRenderer = new DefaultTableCellRenderer();
        centerRenderer.setHorizontalAlignment(JLabel.CENTER);
        centerRenderer.setBackground(COLOR_TARJETA);
        centerRenderer.setForeground(COLOR_TEXTO_BLANCO);

        for (int i = 0; i < tabla.getColumnCount(); i++) {
            tabla.getColumnModel().getColumn(i).setCellRenderer(centerRenderer);
        }
    }

    /**
     * Panel con borde redondeado simulado para tarjetas métricas.
     */
    public static JPanel crearTarjetaMetrica(String valor, String label) {
        JPanel card = new JPanel();
        card.setLayout(new BoxLayout(card, BoxLayout.Y_AXIS));
        card.setBackground(COLOR_FONDO_OSCURO);
        card.setBorder(new EmptyBorder(8, 12, 8, 12));

        JLabel lblValor = new JLabel(valor, SwingConstants.CENTER);
        lblValor.setFont(FONT_METRICA_VALOR);
        lblValor.setForeground(COLOR_TEXTO_BLANCO);
        lblValor.setAlignmentX(Component.CENTER_ALIGNMENT);

        JLabel lblEtiqueta = new JLabel(label, SwingConstants.CENTER);
        lblEtiqueta.setFont(FONT_METRICA_LABEL);
        lblEtiqueta.setForeground(COLOR_TEXTO_GRIS);
        lblEtiqueta.setAlignmentX(Component.CENTER_ALIGNMENT);

        card.add(lblValor);
        card.add(Box.createVerticalStrut(4));
        card.add(lblEtiqueta);

        return card;
    }
}
