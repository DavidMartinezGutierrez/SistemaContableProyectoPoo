package uts.academico.util;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

/**
 * Gestor de Conexión JDBC a PostgreSQL.
 * Implementa el patrón Singleton y buenas prácticas de liberación de recursos
 * para proyectos de Motores de Bases de Datos y POO.
 */
public class ConexionBD {

    private static final String DRIVER = "org.postgresql.Driver";
    private static String host = "localhost";
    private static String puerto = "5432";
    private static String baseDatos = "uts_sistema_academico";
    private static String usuario = "postgres";
    private static String password = "admin"; // Modificar según la contraseña local de pgAdmin

    private static Connection conexionUnica = null;

    static {
        try {
            Class.forName(DRIVER);
        } catch (ClassNotFoundException e) {
            System.err.println("Error: Driver JDBC de PostgreSQL no encontrado en el classpath.");
            e.printStackTrace();
        }
    }

    private ConexionBD() {
        // Constructor privado para patrón Singleton / Utility
    }

    /**
     * Obtiene una conexión activa a la base de datos PostgreSQL.
     * Si la conexión actual está cerrada o nula, abre una nueva.
     *
     * @return Connection activa
     * @throws SQLException Si falla la conexión
     */
    public static synchronized Connection getConexion() throws SQLException {
        if (conexionUnica == null || conexionUnica.isClosed()) {
            String url = String.format("jdbc:postgresql://%s:%s/%s", host, puerto, baseDatos);
            conexionUnica = DriverManager.getConnection(url, usuario, password);
        }
        return conexionUnica;
    }

    /**
     * Permite reconfigurar las credenciales en tiempo de ejecución
     * (útil si el evaluador o estudiante usa otra contraseña en pgAdmin).
     */
    public static synchronized void configurar(String nuevoHost, String nuevoPuerto, String nuevaBD, String nuevoUser, String nuevoPass) {
        cerrarConexion();
        host = nuevoHost;
        puerto = nuevoPuerto;
        baseDatos = nuevaBD;
        usuario = nuevoUser;
        password = nuevoPass;
    }

    public static String getBaseDatos() { return baseDatos; }
    public static String getUsuario() { return usuario; }
    public static void setPassword(String pass) { password = pass; }

    /**
     * Cierra de forma segura un ResultSet.
     */
    public static void cerrar(ResultSet rs) {
        if (rs != null) {
            try {
                rs.close();
            } catch (SQLException e) {
                System.err.println("Advertencia al cerrar ResultSet: " + e.getMessage());
            }
        }
    }

    /**
     * Cierra de forma segura un Statement / PreparedStatement / CallableStatement.
     */
    public static void cerrar(Statement stmt) {
        if (stmt != null) {
            try {
                stmt.close();
            } catch (SQLException e) {
                System.err.println("Advertencia al cerrar Statement: " + e.getMessage());
            }
        }
    }

    /**
     * Cierra de forma segura una conexión puntual.
     */
    public static void cerrar(Connection conn) {
        if (conn != null) {
            try {
                if (!conn.isClosed()) {
                    conn.close();
                }
            } catch (SQLException e) {
                System.err.println("Advertencia al cerrar Connection: " + e.getMessage());
            }
        }
    }

    /**
     * Cierra Statement y ResultSet juntos.
     */
    public static void cerrar(Statement stmt, ResultSet rs) {
        cerrar(rs);
        cerrar(stmt);
    }

    /**
     * Cierra Connection, Statement y ResultSet juntos.
     */
    public static void cerrar(Connection conn, Statement stmt, ResultSet rs) {
        cerrar(rs);
        cerrar(stmt);
        cerrar(conn);
    }

    /**
     * Cierra la conexión singleton activa al terminar la sesión.
     */
    public static synchronized void cerrarConexion() {
        if (conexionUnica != null) {
            try {
                if (!conexionUnica.isClosed()) {
                    conexionUnica.close();
                }
            } catch (SQLException e) {
                System.err.println("Error al cerrar conexión global: " + e.getMessage());
            } finally {
                conexionUnica = null;
            }
        }
    }
}
